
// This may look like C code, but it is really -*- C++ -*-
/* 
Copyright (C) 1988 Free Software Foundation
    written by Doug Lea (dl@rocky.oswego.edu)

This file is part of the GNU C++ Library.  This library is free
software; you can redistribute it and/or modify it under the terms of
the GNU Library General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your
option) any later version.  This library is distributed in the hope
that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the GNU Library General Public License for more details.
You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the Free Software
Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
*/


#ifndef _physidTuplePtrCHMap_h
#ifdef __GNUG__
#pragma interface
#endif
#define _physidTuplePtrCHMap_h 1

#include "physid.TuplePtr.Map.h"

#ifndef _physidTuplePtrCHNode_h
#define _physidTuplePtrCHNode_h 1

struct physidTuplePtrCHNode
{
  physidTuplePtrCHNode*      tl;
  physid                hd;
  TuplePtr                cont;
                     physidTuplePtrCHNode();
                     physidTuplePtrCHNode(physid  h, TuplePtr  c, physidTuplePtrCHNode* t = 0);
                     ~physidTuplePtrCHNode();
};

inline physidTuplePtrCHNode::physidTuplePtrCHNode() {}

inline physidTuplePtrCHNode::physidTuplePtrCHNode(physid  h, TuplePtr  c, physidTuplePtrCHNode* t)
     : tl(t), hd(h), cont(c) {}

inline physidTuplePtrCHNode::~physidTuplePtrCHNode() {}

typedef physidTuplePtrCHNode* physidTuplePtrCHNodePtr;

#endif


class physidTuplePtrCHMap : public physidTuplePtrMap
{
protected:
  physidTuplePtrCHNode** tab;
  unsigned int   size;

public:
                physidTuplePtrCHMap(TuplePtr  dflt,unsigned int sz=DEFAULT_INITIAL_CAPACITY);
                physidTuplePtrCHMap(physidTuplePtrCHMap& a);
                ~physidTuplePtrCHMap();

  TuplePtr&          operator [] (physid  key);

  void          del(physid  key);

  Pix           first();
  void          next(Pix& i);
  physid&          key(Pix i);
  TuplePtr&          contents(Pix i);

  Pix           seek(physid  key);
  int           contains(physid  key);

  void          clear(); 
  int           OK();
};


inline physidTuplePtrCHMap::~physidTuplePtrCHMap()
{
  clear();
  delete tab;
}

inline int physidTuplePtrCHMap::contains(physid  key)
{
  return seek(key) != 0;
}

inline physid& physidTuplePtrCHMap::key(Pix p)
{
  if (p == 0) error("null Pix");
  return ((physidTuplePtrCHNode*)p)->hd;
}

inline TuplePtr& physidTuplePtrCHMap::contents(Pix p)
{
  if (p == 0) error("null Pix");
  return ((physidTuplePtrCHNode*)p)->cont;
}

#endif
