// This may look like C code, but it is really -*- C++ -*-
/* 
Copyright (C) 1988 Free Software Foundation
    written by Doug Lea (dl@rocky.oswego.edu)

This file is part of the GNU C++ Library.  This library is free
software; you can redistribute it and/or modify it under the terms of
the GNU Library General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your
option) any later version.  This library is distributed in the hope
that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the GNU Library General Public License for more details.
You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the Free Software
Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
*/


#ifndef _intTupleListAVLMap_h
#ifdef __GNUG__
#pragma interface
#endif
#define _intTupleListAVLMap_h 1

#include "int.TupleList.Map.h"

struct intTupleListAVLNode
{
  intTupleListAVLNode*      lt;
  intTupleListAVLNode*      rt;
  int                 item;
  TupleList                 cont;
  char                stat;
                      intTupleListAVLNode(int  h, TupleList& c, 
                                    intTupleListAVLNode* l=0, intTupleListAVLNode* r=0);
                      ~intTupleListAVLNode();
};

inline intTupleListAVLNode::intTupleListAVLNode(int  h, TupleList& c, 
                                    intTupleListAVLNode* l, intTupleListAVLNode* r)
     : lt(l), rt(r), item(h), cont(c), stat(0) {}

inline intTupleListAVLNode::~intTupleListAVLNode() {}

typedef intTupleListAVLNode* intTupleListAVLNodePtr;


class intTupleListAVLMap : public intTupleListMap
{
protected:
  intTupleListAVLNode*   root;

  intTupleListAVLNode*   leftmost();
  intTupleListAVLNode*   rightmost();
  intTupleListAVLNode*   pred(intTupleListAVLNode* t);
  intTupleListAVLNode*   succ(intTupleListAVLNode* t);
  void            _kill(intTupleListAVLNode* t);
  void            _add(intTupleListAVLNode*& t);
  void            _del(intTupleListAVLNode* p, intTupleListAVLNode*& t);

public:
                intTupleListAVLMap(TupleList& dflt);
                intTupleListAVLMap(intTupleListAVLMap& a);
                ~intTupleListAVLMap();

  TupleList&          operator [] (int  key);

  void          del(int  key);

  Pix           first();
  void          next(Pix& i);
  int&          key(Pix i);
  TupleList&          contents(Pix i);

  Pix           seek(int  key);
  int           contains(int  key);

  void          clear(); 

  Pix           last();
  void          prev(Pix& i);

  int           OK();
};

inline intTupleListAVLMap::~intTupleListAVLMap()
{
  _kill(root);
}

inline intTupleListAVLMap::intTupleListAVLMap(TupleList& dflt) :intTupleListMap(dflt)
{
  root = 0;
}

inline Pix intTupleListAVLMap::first()
{
  return Pix(leftmost());
}

inline Pix intTupleListAVLMap::last()
{
  return Pix(rightmost());
}

inline void intTupleListAVLMap::next(Pix& i)
{
  if (i != 0) i = Pix(succ((intTupleListAVLNode*)i));
}

inline void intTupleListAVLMap::prev(Pix& i)
{
  if (i != 0) i = Pix(pred((intTupleListAVLNode*)i));
}

inline int& intTupleListAVLMap::key(Pix i)
{
  if (i == 0) error("null Pix");
  return ((intTupleListAVLNode*)i)->item;
}

inline TupleList& intTupleListAVLMap::contents(Pix i)
{
  if (i == 0) error("null Pix");
  return ((intTupleListAVLNode*)i)->cont;
}

inline void intTupleListAVLMap::clear()
{
  _kill(root);
  count = 0;
  root = 0;
}

inline int intTupleListAVLMap::contains(int  key)
{
  return seek(key) != 0;
}

#endif
