// This may look like C code, but it is really -*- C++ -*-
/* 
Copyright (C) 1988 Free Software Foundation
    written by Doug Lea (dl@rocky.oswego.edu)

This file is part of the GNU C++ Library.  This library is free
software; you can redistribute it and/or modify it under the terms of
the GNU Library General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your
option) any later version.  This library is distributed in the hope
that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the GNU Library General Public License for more details.
You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the Free Software
Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifdef __GNUG__
#pragma implementation
#endif
#include "gid.TupleGroupP.CHMap.h"

// The nodes are linked together serially via a version
// of a trick used in some vtables: odd pointers are
// actually links to the next table entry. 
// Not terrible, but not wonderful either

static inline int goodCHptr(gidTupleGroupPCHNode* t)
{
  return ((((unsigned)t) & 1) == 0);
}

static inline gidTupleGroupPCHNode* index_to_CHptr(int i)
{
  return (gidTupleGroupPCHNode*)((i << 1) + 1);
}

static inline int CHptr_to_index(gidTupleGroupPCHNode* t)
{
  return ( ((unsigned) t) >> 1);
}

gidTupleGroupPCHMap::gidTupleGroupPCHMap(TupleGroupP  dflt, unsigned int sz)
     :gidTupleGroupPMap(dflt)
{
  tab = (gidTupleGroupPCHNode**)(new gidTupleGroupPCHNodePtr[size = sz]);
  for (unsigned int i = 0; i < size; ++i) tab[i] = index_to_CHptr(i+1);
  count = 0;
}

gidTupleGroupPCHMap::gidTupleGroupPCHMap(gidTupleGroupPCHMap& a) :gidTupleGroupPMap(a.def)
{
  tab = (gidTupleGroupPCHNode**)(new gidTupleGroupPCHNodePtr[size = a.size]);
  for (unsigned int i = 0; i < size; ++i) tab[i] = index_to_CHptr(i+1);
  count = 0;
  for (Pix p = a.first(); p; a.next(p)) (*this)[a.key(p)] = a.contents(p);
}


Pix gidTupleGroupPCHMap::seek(gid& key)
{
  unsigned int h = gidHASH(key) % size;

  for (gidTupleGroupPCHNode* t = tab[h]; goodCHptr(t); t = t->tl)
    if (gidEQ(key, t->hd))
      return Pix(t);

  return 0;
}


TupleGroupP& gidTupleGroupPCHMap::operator [](gid& item)
{
  unsigned int h = gidHASH(item) % size;

  gidTupleGroupPCHNode* t;
  for ( t = tab[h]; goodCHptr(t); t = t->tl)
    if (gidEQ(item, t->hd))
      return t->cont;

  t = new gidTupleGroupPCHNode(item, def, tab[h]);
  tab[h] = t;
  ++count;
  return t->cont;
}


void gidTupleGroupPCHMap::del(gid& key)
{
  unsigned int h = gidHASH(key) % size;

  gidTupleGroupPCHNode* t = tab[h]; 
  gidTupleGroupPCHNode* trail = t;
  while (goodCHptr(t))
  {
    if (gidEQ(key, t->hd))
    {
      if (trail == t)
        tab[h] = t->tl;
      else
        trail->tl = t->tl;
      delete t;
      --count;
      return;
    }
    trail = t;
    t = t->tl;
  }
}


void gidTupleGroupPCHMap::clear()
{
  for (unsigned int i = 0; i < size; ++i)
  {
    gidTupleGroupPCHNode* p = tab[i];
    tab[i] = index_to_CHptr(i+1);
    while (goodCHptr(p))
    {
      gidTupleGroupPCHNode* nxt = p->tl;
      delete(p);
      p = nxt;
    }
  }
  count = 0;
}

Pix gidTupleGroupPCHMap::first()
{
  for (unsigned int i = 0; i < size; ++i) if (goodCHptr(tab[i])) return Pix(tab[i]);
  return 0;
}

void gidTupleGroupPCHMap::next(Pix& p)
{
  gidTupleGroupPCHNode* t = ((gidTupleGroupPCHNode*)p)->tl;
  if (goodCHptr(t))
    p = Pix(t);
  else
  {
    for (unsigned int i = CHptr_to_index(t); i < size; ++i) 
    {
      if (goodCHptr(tab[i]))
      {
        p =  Pix(tab[i]);
        return;
      }
    }
    p = 0;
  }
}


int gidTupleGroupPCHMap::OK()
{
  int v = tab != 0;
  int n = 0;
  for (unsigned int i = 0; i < size; ++i)
  {
    gidTupleGroupPCHNode *p;
    for (p = tab[i]; goodCHptr(p); p = p->tl) ++n;
    v &= CHptr_to_index(p) == i + 1;
  }
  v &= count == n;
  if (!v) error("invariant failure");
  return v;
}
