// This may look like C code, but it is really -*- C++ -*-
/* 
Copyright (C) 1988 Free Software Foundation
    written by Doug Lea (dl@rocky.oswego.edu)

This file is part of the GNU C++ Library.  This library is free
software; you can redistribute it and/or modify it under the terms of
the GNU Library General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your
option) any later version.  This library is distributed in the hope
that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the GNU Library General Public License for more details.
You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the Free Software
Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
*/


#ifndef _gidTupleGroupPCHMap_h
#ifdef __GNUG__
#pragma interface
#endif
#define _gidTupleGroupPCHMap_h 1

#include "gid.TupleGroupP.Map.h"

#ifndef _gidTupleGroupPCHNode_h
#define _gidTupleGroupPCHNode_h 1

struct gidTupleGroupPCHNode
{
  gidTupleGroupPCHNode*      tl;
  gid                hd;
  TupleGroupP                cont;
                     gidTupleGroupPCHNode();
                     gidTupleGroupPCHNode(gid& h, TupleGroupP  c, gidTupleGroupPCHNode* t = 0);
                     ~gidTupleGroupPCHNode();
};

inline gidTupleGroupPCHNode::gidTupleGroupPCHNode() {}

inline gidTupleGroupPCHNode::gidTupleGroupPCHNode(gid& h, TupleGroupP  c, gidTupleGroupPCHNode* t)
     : tl(t), hd(h), cont(c) {}

inline gidTupleGroupPCHNode::~gidTupleGroupPCHNode() {}

typedef gidTupleGroupPCHNode* gidTupleGroupPCHNodePtr;

#endif


class gidTupleGroupPCHMap : public gidTupleGroupPMap
{
protected:
  gidTupleGroupPCHNode** tab;
  unsigned int   size;

public:
                gidTupleGroupPCHMap(TupleGroupP  dflt,unsigned int sz=DEFAULT_INITIAL_CAPACITY);
                gidTupleGroupPCHMap(gidTupleGroupPCHMap& a);
                ~gidTupleGroupPCHMap();

  TupleGroupP&          operator [] (gid& key);

  void          del(gid& key);

  Pix           first();
  void          next(Pix& i);
  gid&          key(Pix i);
  TupleGroupP&          contents(Pix i);

  Pix           seek(gid& key);
  int           contains(gid& key);

  void          clear(); 
  int           OK();
};


inline gidTupleGroupPCHMap::~gidTupleGroupPCHMap()
{
  clear();
  delete tab;
}

inline int gidTupleGroupPCHMap::contains(gid& key)
{
  return seek(key) != 0;
}

inline gid& gidTupleGroupPCHMap::key(Pix p)
{
  if (p == 0) error("null Pix");
  return ((gidTupleGroupPCHNode*)p)->hd;
}

inline TupleGroupP& gidTupleGroupPCHMap::contents(Pix p)
{
  if (p == 0) error("null Pix");
  return ((gidTupleGroupPCHNode*)p)->cont;
}

#endif
