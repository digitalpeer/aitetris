// This may look like C code, but it is really -*- C++ -*-
/* 
Copyright (C) 1988 Free Software Foundation
    written by Doug Lea (dl@rocky.oswego.edu)

This file is part of the GNU C++ Library.  This library is free
software; you can redistribute it and/or modify it under the terms of
the GNU Library General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your
option) any later version.  This library is distributed in the hope
that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the GNU Library General Public License for more details.
You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the Free Software
Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifdef __GNUG__
#pragma implementation
#endif
#include "int.TupleList.CHMap.h"


// The nodes are linked together serially via a version
// of a trick used in some vtables: odd pointers are
// actually links to the next table entry. 
// Not terrible, but not wonderful either

static inline int goodCHptr(intTupleListCHNode* t)
{
  return ((((unsigned)t) & 1) == 0);
}

static inline intTupleListCHNode* index_to_CHptr(int i)
{
  return (intTupleListCHNode*)((i << 1) + 1);
}

static inline int CHptr_to_index(intTupleListCHNode* t)
{
  return ( ((unsigned) t) >> 1);
}

intTupleListCHMap::intTupleListCHMap(TupleList& dflt, unsigned int sz)
     :intTupleListMap(dflt)
{
  tab = (intTupleListCHNode**)(new intTupleListCHNodePtr[size = sz]);
  for (unsigned int i = 0; i < size; ++i) tab[i] = index_to_CHptr(i+1);
  count = 0;
}

intTupleListCHMap::intTupleListCHMap(intTupleListCHMap& a) :intTupleListMap(a.def)
{
  tab = (intTupleListCHNode**)(new intTupleListCHNodePtr[size = a.size]);
  for (unsigned int i = 0; i < size; ++i) tab[i] = index_to_CHptr(i+1);
  count = 0;
  for (Pix p = a.first(); p; a.next(p)) (*this)[a.key(p)] = a.contents(p);
}


Pix intTupleListCHMap::seek(int  key)
{
  unsigned int h = intHASH(key) % size;

  for (intTupleListCHNode* t = tab[h]; goodCHptr(t); t = t->tl)
    if (intEQ(key, t->hd))
      return Pix(t);

  return 0;
}


TupleList& intTupleListCHMap::operator [](int  item)
{
  unsigned int h = intHASH(item) % size;

  intTupleListCHNode* t;
  for ( t = tab[h]; goodCHptr(t); t = t->tl)
    if (intEQ(item, t->hd))
      return t->cont;

  t = new intTupleListCHNode(item, def, tab[h]);
  tab[h] = t;
  ++count;
  return t->cont;
}


void intTupleListCHMap::del(int  key)
{
  unsigned int h = intHASH(key) % size;

  intTupleListCHNode* t = tab[h]; 
  intTupleListCHNode* trail = t;
  while (goodCHptr(t))
  {
    if (intEQ(key, t->hd))
    {
      if (trail == t)
        tab[h] = t->tl;
      else
        trail->tl = t->tl;
      delete t;
      --count;
      return;
    }
    trail = t;
    t = t->tl;
  }
}


void intTupleListCHMap::clear()
{
  for (unsigned int i = 0; i < size; ++i)
  {
    intTupleListCHNode* p = tab[i];
    tab[i] = index_to_CHptr(i+1);
    while (goodCHptr(p))
    {
      intTupleListCHNode* nxt = p->tl;
      delete(p);
      p = nxt;
    }
  }
  count = 0;
}

Pix intTupleListCHMap::first()
{
  for (unsigned int i = 0; i < size; ++i) if (goodCHptr(tab[i])) return Pix(tab[i]);
  return 0;
}

void intTupleListCHMap::next(Pix& p)
{
  intTupleListCHNode* t = ((intTupleListCHNode*)p)->tl;
  if (goodCHptr(t))
    p = Pix(t);
  else
  {
    for (unsigned int i = CHptr_to_index(t); i < size; ++i) 
    {
      if (goodCHptr(tab[i]))
      {
        p =  Pix(tab[i]);
        return;
      }
    }
    p = 0;
  }
}


int intTupleListCHMap::OK()
{
  int v = tab != 0;
  int n = 0;
  for (unsigned int i = 0; i < size; ++i)
  {
    intTupleListCHNode* p;
    for ( p = tab[i]; goodCHptr(p); p = p->tl) ++n;
    v &= CHptr_to_index(p) == i + 1;
  }
  v &= count == n;
  if (!v) error("invariant failure");
  return v;
}
