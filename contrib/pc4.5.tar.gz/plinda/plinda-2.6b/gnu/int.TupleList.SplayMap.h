// This may look like C code, but it is really -*- C++ -*-
/* 
Copyright (C) 1988 Free Software Foundation
    written by Doug Lea (dl@rocky.oswego.edu)

This file is part of the GNU C++ Library.  This library is free
software; you can redistribute it and/or modify it under the terms of
the GNU Library General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your
option) any later version.  This library is distributed in the hope
that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the GNU Library General Public License for more details.
You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the Free Software
Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
*/


#ifndef _intTupleListSplayMap_h
#ifdef __GNUG__
#pragma interface
#endif
#define _intTupleListSplayMap_h 1

#include "int.TupleList.Map.h"

#ifndef _intTupleListSplayNode
#define _intTupleListSplayNode 1

struct intTupleListSplayNode
{
  intTupleListSplayNode*   lt;
  intTupleListSplayNode*   rt;
  intTupleListSplayNode*   par;
  int                item;
  TupleList                cont;
                     intTupleListSplayNode(int  h, TupleList& c, 
                                     intTupleListSplayNode* l=0, 
                                     intTupleListSplayNode* r=0);
                  ~intTupleListSplayNode();
};


inline intTupleListSplayNode::intTupleListSplayNode(int  h, TupleList& c, 
                                        intTupleListSplayNode* l, 
                                        intTupleListSplayNode* r)
     :lt(l), rt(r), par(0), item(h), cont(c)  {}

inline intTupleListSplayNode::~intTupleListSplayNode() {}

typedef intTupleListSplayNode* intTupleListSplayNodePtr;

#endif

class intTupleListSplayMap : public intTupleListMap
{
protected:
  intTupleListSplayNode*   root;

  intTupleListSplayNode*   leftmost();
  intTupleListSplayNode*   rightmost();
  intTupleListSplayNode*   pred(intTupleListSplayNode* t);
  intTupleListSplayNode*   succ(intTupleListSplayNode* t);
  void               _kill(intTupleListSplayNode* t);
  intTupleListSplayNode*   _copy(intTupleListSplayNode* t);

public:
               intTupleListSplayMap(TupleList& dflt);
               intTupleListSplayMap(intTupleListSplayMap& a);
               ~intTupleListSplayMap();

  TupleList&          operator [] (int  key);

  void          del(int  key);

  Pix           first();
  void          next(Pix& i);
  int&          key(Pix i);
  TupleList&          contents(Pix i);

  Pix           seek(int  key);
  int           contains(int  key);

  void          clear(); 

  Pix           last();
  void          prev(Pix& i);

  int           OK();
};


inline intTupleListSplayMap::~intTupleListSplayMap()
{
  _kill(root);
}

inline intTupleListSplayMap::intTupleListSplayMap(TupleList& dflt) :intTupleListMap(dflt)
{
  root = 0;
}

inline intTupleListSplayMap::intTupleListSplayMap(intTupleListSplayMap& b) :intTupleListMap(b.def)
{
  count = b.count;
  root = _copy(b.root);
}

inline Pix intTupleListSplayMap::first()
{
  return Pix(leftmost());
}

inline Pix intTupleListSplayMap::last()
{
  return Pix(rightmost());
}

inline void intTupleListSplayMap::next(Pix& i)
{
  if (i != 0) i = Pix(succ((intTupleListSplayNode*)i));
}

inline void intTupleListSplayMap::prev(Pix& i)
{
  if (i != 0) i = Pix(pred((intTupleListSplayNode*)i));
}

inline int& intTupleListSplayMap::key (Pix i)
{
  if (i == 0) error("null Pix");
  return ((intTupleListSplayNode*)i)->item;
}

inline TupleList& intTupleListSplayMap::contents (Pix i)
{
  if (i == 0) error("null Pix");
  return ((intTupleListSplayNode*)i)->cont;
}

inline void intTupleListSplayMap::clear()
{
  _kill(root);
  count = 0;
  root = 0;
}

inline int intTupleListSplayMap::contains(int  key)
{
  return seek(key) != 0;
}

#endif
