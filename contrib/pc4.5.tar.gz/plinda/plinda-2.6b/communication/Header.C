#include "Header.h"


static inline void reverse (int &word)
{
  assert(sizeof(int) == 4);
  int x = word;
  swab((char*)&word,((char*)&word)+2,2);
  swab(((char*)&x)+2,(char*)&word,2);
}


static inline void reverse (unsigned int &word)
{
  assert(sizeof(int) == 4);
  int x = word;
  swab((char*)&word,((char*)&word)+2,2);
  swab(((char*)&x)+2,(char*)&word,2);
}
 
void Header::reverseEndian(Header &h)
{
  reverse(h.myProcessId_);
  reverse(h.transientId_);
  //reverse(h.ipAddress_);
  reverse(h.tupleLength_);
  reverse(h.portNumber_);
  switch(h.type_) {
  case SEND_CLIENT_MESSAGE:
    reverse(h.data.c.lineNum);
    reverse(h.data.c.g.low);
    reverse(h.data.c.g.high);
    break;
  case SEND_MONITOR_MESSAGE:
    reverse(h.data.m.paramValue);
    reverse(h.data.m.paramNum);
    reverse(h.data.m.processId);
    break;
  case SEND_DAEMON_MESSAGE:
    reverse(h.data.d.sequenceNum);
    reverse(h.data.d.idleTime);
    reverse(h.data.d.processId);
    break;
  }
}



