// This may look like C code, but it is really -*- C++ -*-
//
// File:     ConnectionListener.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu

// C or C++ header files
#include <stdio.h>
#if !defined(alpha) & 0
#include <sys/types.h>
#include <sys/socket.h>
#endif
// ACE header files
#include "INET_Addr.h"
#include "Reactor.h"

// PLinda header files
#include "ConnectionListener.h"
#include "ServerCommLink.h"
#include "ClientProcess.h"
#include "MonitorProcess.h"
#include "ProcessManager.h"
#include "ObjectSpace.h"

#ifdef _OUTLINE_
#define inline
#include "ConnectionListener.iC"
#endif

int 
ConnectionListener::handle_input(int ) {
#ifdef PL_DEBUG_COMM
  ::printf("client connection request.\n");
#endif
  // New connection, so new CommLink.
  ServerCommLink* comm_link = new ServerCommLink(peer_type());

  if(listener().accept(comm_link->TCPIP_link()) == -1) {
#ifdef PL_DEBUG_COMM
    ::perror("Listener::handle_input, accept");
#endif
    return 0;
  } else {
    // now, the TCPIP link is opened.
    comm_link->set_link_open();
  }

  Header header;
  if(comm_link->receive(header) == -1) {
     delete comm_link;
     return 0;
  }

  // comm_link->process_id(message.process_id());
  // comm_link->OS_pid(message.OS_pid());
   
    procid proc_id = header.myProcessId(); 
    comm_link->process_id(proc_id);

    if (proc_id==MONITOR_PROCID){
        if ((ObjectSpace::monitor).comm_link() != 0){
	    if((ObjectSpace::monitor).comm_link()->broken()) { 
	       delete (ObjectSpace::monitor).comm_link();
	       (ObjectSpace::monitor).comm_link(0);
	    } else {
	       // SHOULD BE CHANGED.
	       (ObjectSpace::monitor).comm_link()->shutdown();
	       delete (ObjectSpace::monitor).comm_link();
	       (ObjectSpace::monitor).comm_link(0);
	    }
	} 

	if ((ObjectSpace::monitor).comm_link() != 0){
	    // process already has a ServerCommLink.;
	    Header reply;
	    reply.type(Header::INFORM_ERROR);
	    comm_link->send(reply);
	    delete comm_link;
	    return 0;
	} else {
	    // associate this ServerCommLink with this process.
	    (ObjectSpace::monitor).comm_link(comm_link);
	    comm_link->owner(&(ObjectSpace::monitor));
	}
    }
    else {
	Process* proc;
	proc = ObjectSpace::proc_mgr.find_process(header.myProcessId());
	if(proc == 0) {
#ifdef PL_DEBUG_COMM
	    ::printf("E: received a connection request with unknown process id.\n");
#endif
	    Header reply;
	    header.type(Header::INFORM_ERROR);
	    comm_link->send(reply);
	    delete comm_link;
	    return 0;
	 }
	// Process* proc = new Process(message.process_id());
	// ObjectSpace::process_mgr.append(proc);

	if(proc->comm_link() != 0) {
	    // process already has a ServerCommLink.;
	    Header reply;
	    reply.type(Header::INFORM_ERROR);
	    comm_link->send(reply);
	    delete comm_link;
	    return 0;
	} else {
	    // associate this ServerCommLink with this process.;
	    proc->comm_link(comm_link);
	    comm_link->owner(proc);
	}

	if(proc->temp_link_flag()) {
	    // this process wants to use a temporary connection explicitly,;
	    // so, we honor it.;
	    comm_link->status(CommLink::FIXED_TEMPORARY);
	}
    }

    // comm_link has a TCP/IP link to a client process now.;
  if(comm_link->establish_link(header) == -1) {
#ifdef PL_DEBUG_COMM
     ::printf("ConnectionListener::handle_input, establish_link\n");
#endif
     comm_link->shutdown();
     return 0;
  }

#ifdef PL_DEBUG_COMM
    ::printf("Process %ld on %s is \"%s\"-connected to the server\n", 
	     comm_link->process_id(), 
	     comm_link->peer_hostname(),
	     (comm_link->dedicated() ? "dedicatedly" : "temporarily"));
#endif

    return 0;
}


