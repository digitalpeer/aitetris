// This may look like C code, but it is really -*- C++ -*-
//
// File:     Header.h
// Created:  
// Author:   Peter Wyckoff
// Mail:     wyckoff@cs.nyu.edu
//
#ifndef _HEADER_H_
#define _HEADER_H_

#include "plinda_requests.h"
#include "ErrorType.h"
#include "plinda_ids.h"
#include "stdio.h"
class Tuple;
class Header;
struct HeaderAndTuple {
   Tuple *tuple;
   Header *header;
};

class Header {
public:
  enum HeaderType { 
    INVALID_HEADER = -1,
    NO_MESSAGE = 0,
    INFORM_ERROR = 1,
    CHECK_FAILURE = 2,
    REQUEST_LINK = 3, 
    ACKNOWLEDGE_DEDICATED = 4,
    ACKNOWLEDGE_TEMPORARY = 5, 
    SWITCH_TO_DEDICATED = 7,
    SWITCH_TO_TEMPORARY = 8,
    REFUSE_REQUEST = 9,
    ACCEPT_REQUEST = 10,
    SEND_CLIENT_MESSAGE = 11,
    SEND_DAEMON_MESSAGE = 12,
    SEND_MONITOR_MESSAGE = 13
    };
  enum FT_ModeType { INVALID_FT = 0, NO_FT = 1 , GLOBAL_FT = 2, 
		     PRIVATE_FT = 3, REPLAY_FT = 4};  
  enum { HEADER_STRLEN = 10 };

private:
  struct ClientData {
    unsigned char clientRequest; 
    int lineNum;      //  used by client and monitor
    char fileName[HEADER_STRLEN]; 
    unsigned char ftMode; // for PROC_START
    char restartFlag;     // for PROC_START
    gid g;            // used by client for create group and in and out
    char synchronyType;  // for INP/IN and RD/RDP
    char xstart;
 };
  struct DaemonData {
     unsigned char daemonMsgType;
     int sequenceNum; 
     char interactive;
     int idleTime ;   
     int processId; // for daemon and monitor
 };
  struct MonitorData {
    unsigned char monitorMsgType; 
    int paramValue;  
    int paramNum;     
    int processId; // for daemon and monitor
 };
  unsigned char type_;   
  int myProcessId_; 
  int transientId_;  
  int  portNumber_;
  unsigned int   ipAddress_;  
  int tupleLength_;   
  ErrorType status_;  
  union {
     ClientData c;
     MonitorData m;
     DaemonData d;
  } data;

  const bool daemon() const { return type_ == SEND_DAEMON_MESSAGE; }
  const bool monitor() const { return type_ == SEND_MONITOR_MESSAGE; }
  const bool client() const { return type_ == SEND_CLIENT_MESSAGE; }
public:
  static void reverseEndian(Header &h);

  // **************functions for everybody
  void init() {
     type_ = (unsigned char)-1;
     myProcessId_ = 0;
     transientId_ = -1;
     portNumber_ = 0;
     ipAddress_ = 0;
     tupleLength_ = 0; // this must be done!!!
     status_ = E_INV_MESSAGE; // this should probably be done
  }
  void reset() { init(); }
  Header(void) { init(); }
  Header(HeaderType t) { init(); type_ = t; }
  ~Header(void) { }
  HeaderType type(void) const { return (HeaderType)type_;}
  void type(HeaderType t) { type_ = (unsigned char)t; }
  int myProcessId() const { return myProcessId_; }
  void myProcessId(int p ) { myProcessId_ = p; }
  int transientId() const { return transientId_; }
  void transientId(int ti) { transientId_ = ti; }
  unsigned short portNumber(void) const { return (unsigned short)portNumber_ ; }
  void portNumber(unsigned  short p ) { portNumber_ = (int)p ; }
  long ipAddress(void) const { return (long)ipAddress_ ; }
  void ipAddress(long a) { ipAddress_ = (unsigned int)a ; }
  int tupleLength(void) const { return tupleLength_; }
  void tupleLength(int l) { tupleLength_ = l; }
  ErrorType status() const { return status_; }
  void status(ErrorType et) { status_ = et; }

  // *************** the client data access functions
  ClientRequest clientRequest(void) const { 
     assert(client());return (ClientRequest)data.c.clientRequest;}
  void clientRequest(ClientRequest t) { 
     status_ = NO_ERROR;
     type_ = SEND_CLIENT_MESSAGE;
     data.c.clientRequest = (unsigned char)t; }
  FT_ModeType ftMode() const { assert(client());
			       return (FT_ModeType)data.c.ftMode; }
  void  ftMode(FT_ModeType m) { assert(client()); data.c.ftMode = (unsigned char)m;} 
  void g(gid g) { assert(client()); data.c.g = g; }
  gid g() const { assert(client());return data.c.g; }
  void lineNum(int n) { assert(client());data.c.lineNum = n; }
  int lineNum() const { assert(client());return data.c.lineNum; }
  const char *fileName() const { assert(client()) ;
				 return data.c.fileName;}
  void fileName(char *name) { 
     assert(client()) ;
     memcpy(data.c.fileName,name,HEADER_STRLEN -1);
     // Do we need to worry that the above could cause a segmentation fault?
     data.c.fileName[HEADER_STRLEN-1] = 0;
   }

  int restartFlag() const { assert(client()); return data.c.restartFlag; }
  void restartFlag(int i) { assert(client()); data.c.restartFlag = i; }

  int xstart() const { assert(client()); return data.c.xstart; }
  void xstart(int i) { assert(client() ); data.c.xstart = i; }

  int synchronyType() const { assert(client()); return data.c.synchronyType; }
  void synchronyType(int i) { assert(client()); data.c.synchronyType = i; }
  
  // end of stuff for client

  // ************* stuff for the daemon
  unsigned char daemonMsgType() const { assert(daemon());
					return data.d.daemonMsgType; }
  void daemonMsgType(unsigned char dmt) { 
     status_ = NO_ERROR;
     type_ = SEND_DAEMON_MESSAGE;
     data.d.daemonMsgType = dmt; 
  }
  int sequenceNum() const { assert(daemon());return data.d.sequenceNum; }
  void sequenceNum(int sn) { assert(daemon());data.d.sequenceNum = sn; }

  char interactive() const { assert(daemon());return data.d.interactive; }
  void interactive(char i) { assert(daemon());data.d.interactive = i; }
  int idleTime() const { assert(daemon());return data.d.idleTime; }
  void idleTime(int it) { assert(daemon());data.d.idleTime = it; }

  int processId() const { if(daemon())
			       return data.d.processId; 
			     assert(monitor());
			     return data.m.processId; }

  void processId(int p ) {if(daemon())
			       data.d.processId = p; 
			     else {
				assert(monitor());
				data.m.processId = p; 
			     }
			  }

  // end stuff for the daemon

  // ************* stuff for the monitor
  unsigned char monitorMsgType() const { assert(monitor());
					 return data.m.monitorMsgType; }
  void monitorMsgType(unsigned char dmt) { 
     status_ = NO_ERROR;
     type_ = SEND_MONITOR_MESSAGE;
     data.m.monitorMsgType = dmt; }
  int paramNum() const {  assert(monitor());return data.m.paramNum; }
  void paramNum(int i) {  assert(monitor());data.m.paramNum = i; }
  int paramValue() const {  assert(monitor());return data.m.paramValue; }
  void paramValue(int p) {  assert(monitor());data.m.paramValue = p; }

  bool controlMessage() const { 
     return tupleLength_ == 0; } // add more criteria later
  bool empty() { return true; } // fix this
  
};


#endif 

