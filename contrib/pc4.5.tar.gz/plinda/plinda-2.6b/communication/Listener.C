// This may look like C code, but it is really -*- C++ -*-
//
// File:     Listener.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu

// C or C++ header files
#include <stdio.h>
#if !defined(alpha) & 0
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    // for IPPROTO_TCP
#include <netinet/tcp.h>   // for TCP_NODELAY
#else
#include "sysincludes.h"
#endif
// ACE header files
#include "INET_Addr.h"
#include "UNIX_Addr.h"

// PLinda header files
#include "Listener.h"
#include "CommLink.h"

#ifdef _OUTLINE_
#define inline
#include "Listener.iC"
#endif

Listener::Listener(const INET_Addr& addr) 
: l_peer_type(CommLink::REMOTE_HOST) {
  l_port_number = 0;
  l_ip_address = 0;
  open(addr);
}

Listener::Listener(const UNIX_Addr& addr) 
: l_peer_type(CommLink::LOCAL_HOST) {
  l_port_number = 0;
  l_ip_address = 0;
  open(addr);
}

// 
int
Listener::open(const INET_Addr& addr) {
  struct hostent* hp;

  // open a socket for remote connection requests.
  if(l_listener.open(addr, 1, -1, PF_INET) == -1) {
#ifdef PL_DEBUG
    ::perror("Listener::open(const INET_Addr&)");
#endif
    return -1;
  }

  // get the port number
  {
    INET_Addr local_addr;
    if(l_listener.get_local_addr(local_addr) == -1) {
       cerr << "Bad thing in listener.C(" << __LINE__ << "," <<
	 __FILE__ << endl << ::flush;
#ifdef PL_DEBUG
      ::perror("Listener::open(const INET_Addr&)");
#endif
      return -1;
    }
//    l_port_number = local_addr.get_port_number();
    l_port_number = local_addr.get_port_number();
  }

  {
    char hname[1000];
    ::gethostname(hname,1000);
    hp = ::gethostbyname((char*)hname);
    assert(hp != 0);
    l_ip_address = *((long*)(hp->h_addr_list[0]));
  }

  { 
    int len = ::strlen(hp->h_name)+1;
    l_hostname = new char[len];
    ::memcpy((void*)l_hostname, hp->h_name, len); 
  }
  
  return 0;
}

int
Listener::open(const UNIX_Addr& addr) {
  // open a socket for remote connection requests.
  if(l_listener.open(addr, 1, -1, PF_UNIX) == -1) {
#ifdef PL_DEBUG
    ::perror("Listener::open(const UNIX_Addr&)");
#endif
    return -1;
  }
  return 0;
}




