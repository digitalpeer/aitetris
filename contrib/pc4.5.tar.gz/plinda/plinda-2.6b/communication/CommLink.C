// This may look like C code, but it is really -*- C++ -*-
//
// File:     CommLink.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//
#include <stdio.h>
#if !defined(alpha) & 0
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    // for IPPROTO_TCP
#include <netinet/tcp.h>   // for TCP_NODELAY
#include <netdb.h>         // for gethostent
#endif
// C or C++ header files
#include <assert.h>

// PLinda headers
#include "CommLink.h"
#include "Header.h"

#ifdef _OUTLINE_
#define inline
#include "CommLink.iC"
#endif


CommLink::CommLink(PeerType ptype) {
  x_peer_type = ptype;
  x_status = UNCONNECTED;
  x_done_flag = 0;

  x_local_hostname = 0;
  x_local_ip_address = 0;
  x_local_port_number = 0;

  x_peer_hostname = 0;
  x_peer_address = 0;

  x_TCPIP_flag = 0;
}

CommLink::~CommLink() {
  if(link_open()) {
    close_TCPIP_link();
  }
  delete (Addr*)x_peer_address;
  delete[] x_local_hostname;
  delete[] x_peer_hostname;
}


const char*
CommLink::peer_hostname(void) {
  if(x_peer_hostname != 0) {
    return x_peer_hostname;
  }

  assert(peer_address() != 0);
  const Addr* p_addr = peer_address();
  if(p_addr->get_type() == AF_UNIX) {
    // derived classes of class CommLink should set the local host name
    // at object construction time.
    assert(x_local_hostname != 0);
    int len = ::strlen(x_local_hostname)+1;
    x_peer_hostname = new char[len];
    ::memcpy((void*)x_peer_hostname, x_local_hostname, len);
  } else {
    // remote host
    const char* hn = ((INET_Addr*)p_addr)->get_host_name();
    int len = ::strlen(hn)+1;
    x_peer_hostname = new char[len]; 
    ::memcpy((void*)x_peer_hostname, hn, len);
  }
  return x_peer_hostname;
}


int
CommLink::receive_message(int need_to_convert,const SOCK_Stream& link, 
			  Header &header, Tuple *&tuple)
{

  int rbytes;
  // Receive a header first. It contains the size of the body.
  rbytes = link.recv_n((void*)&header, sizeof(Header));
  if(need_to_convert)   {
    Header::reverseEndian(header);
  }
  header.portNumber(ntohs(header.portNumber()));
  if(rbytes == -1 || rbytes == 0) {
    return -1;
 }
  if(rbytes != sizeof(Header)) {
    cerr << "BAD did not recv correct number of bytes. Got " << 
      rbytes << " bytes\n" << flush;
    return -1;
  }

  if(header.tupleLength() > 0) {
     char *tempBuf = new char[header.tupleLength()];
#ifdef alpha
     char *restOfTuple = (char*)((long)tempBuf + sizeof(Header));
#else
     char *restOfTuple = (char*)((int)tempBuf + sizeof(Header));
#endif
     rbytes = link.recv_n((void*)restOfTuple, 
			  header.tupleLength()- sizeof(Header));
     if(rbytes == -1 || rbytes == 0) {
	return -1;
 }
     if(rbytes != (int)(header.tupleLength() - sizeof(Header))) {
	cerr << "BAD. Did not read correct number of bytes:"  <<
	  rbytes << " bytes were read\n"<<  flush;
	return -1;
     }
     tuple = (Tuple*)tempBuf;
     if(need_to_convert) {
       Tuple::reverseEndian(tuple,-1);
     }
     else
       tuple->updatePointers();
     assert(tuple->valid());
     assert(tuple->length() == header.tupleLength());
     return 1;
   } else {
     tuple = NULL;
     return 1;
   }
  assert(0);
  return -1;
}

int 
CommLink::send_message(int need_to_convert,const SOCK_Stream& link, 
		       Header &header,const Tuple *tuple)
{

  header.myProcessId(x_process_id);
  header.ipAddress(x_local_ip_address);
  header.portNumber(htons(x_local_port_number));
  int rbytes;
  if(!tuple) {
    if(need_to_convert)  {
      Header::reverseEndian(header);
    }
      rbytes = link.send_n(&header,sizeof(Header));
      if(rbytes != sizeof(Header)) 
	return -1;
      assert(header.tupleLength() == 0);
      return 1;
  }
  assert(tuple->valid());
  assert(header.tupleLength() == tuple->length());
  const int SendLength = header.tupleLength();
  if(need_to_convert) {
    header.portNumber(htons(header.portNumber()));
    Header::reverseEndian(header);
    }
  ((Tuple *)tuple)->setHeader(header);
  if(need_to_convert) {
    Tuple::reverseEndian((Tuple*)tuple,1);
  }
  rbytes = link.send_n(tuple, SendLength);
  if(need_to_convert) {
    Tuple::reverseEndian((Tuple*)tuple,0);
    // put back the way it was!!
  }
  if(rbytes != SendLength)
    return -1;
  assert(tuple->valid());
  return 1;
}

int
CommLink::open_TCPIP_link(int tries, const Addr* address) {
  assert(link_closed());

  if(address == 0) {
    address = peer_address();
  } 
  
  int fails = 0;
  while(fails < tries) {
    if(TCPIP_link().open(*address, protocol_family()) == -1) {
#ifdef PL_DEBGU_COMM
      ::printf("CommLink::open_TCPIP_link, open failed.\n");
#endif
    } else {
      set_link_open();
      return 0;
    }
    ++fails;
  }
  return -1;
}

int
CommLink::close_TCPIP_link() {
  assert(link_open());
  TCPIP_link().close();
  set_link_closed();
  return 0;
}
