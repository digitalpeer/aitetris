// This may look like C code, but it is really -*- C++ -*-
//
// File:     ConnectionListener.h
// Created:  
// Author:   Karp Joo Jeong 
// Mail:     jeong@cs.nyu.edu

#ifndef _CONNECTION_LISTENER_H_
#define _CONNECTION_LISTENER_H_

// C or C++ header files
#include <sys/types.h>

// ACE header files
#include "Event_Handler.h"

// PLinda header files
#include "CommLink.h"
#include "Listener.h"

class ConnectionListener : public Listener, public Event_Handler {
 public:
  ConnectionListener(CommLink::PeerType =CommLink::REMOTE_HOST);
  ConnectionListener(const INET_Addr&);
  ConnectionListener(const UNIX_Addr&);

  virtual int get_fd (void) const;
  virtual int handle_input(int);
};

#ifndef _OUTLINE_
#include "ConnectionListener.iC"
#endif

#endif // _CONNECTION_LISTENER_H_
