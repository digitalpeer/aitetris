// This may look like C code, but it is really -*- C++ -*-
//
// File:     Listener.h
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu

#ifndef _LISTENER_H_
#define _LISTENER_H_

// C++ or C headerfiles
#include <sys/types.h>

// ACE header files
#include "INET_Addr.h"
#include "UNIX_Addr.h"
#include "SOCK_Listener.h"

// PLinda header files
#include "CommLink.h"

class Listener {
public:
  Listener(CommLink::PeerType);
  Listener(const INET_Addr&);
  Listener(const UNIX_Addr&);
  int open(const INET_Addr&);
  int open(const UNIX_Addr&);

  unsigned  short port_number(void) const;
  long ip_address(void) const;
  const char* hostname(void) const;
  CommLink::PeerType peer_type(void) const;
protected:
  void port_number(unsigned  short);
  void ip_address(long);
  const SOCK_Listener& listener(void) const;
private:
  const CommLink::PeerType l_peer_type;

  unsigned    short l_port_number;
  long l_ip_address;
  const char* l_hostname;

  SOCK_Listener l_listener;
};

#ifndef _OUTLINE_
#include "Listener.iC"
#endif

#endif // _LISTENER_H_
