// This may look like C code, but it is really -*- C++ -*-
//
// File:        CommLink.h
// Description:  
// Created:  
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//
#ifndef _COMM_LINK_H_
#define _COMM_LINK_H_

// ACE include files
#include "Addr.h"
#include "UNIX_Addr.h"
#include "INET_Addr.h"
#include "SOCK_Stream.h"

// PLinda include files
#include "plinda_ids.h"
#include "Header.h"
#include "Tuple.h"


class CommLink {
public:
  enum PeerType {
    REMOTE_HOST = 1,
    LOCAL_HOST = 2
    };

  enum StatusType {
    UNCONNECTED = 0,
    DEDICATED = 1,
    TEMPORARY = 2,
    FIXED_TEMPORARY = 3,  // yes, broken and ugly word.
    BROKEN = 4
    };

  // currently, we do not care about local hosts 
  // because current tcp/ip implementations figure it out. 
  CommLink(PeerType =REMOTE_HOST);
  virtual ~CommLink(void);
  PeerType peer_type(void) const;
  StatusType status(void) const;
  void status(StatusType);

  // identifier
  procid process_id(void) const;
  void process_id(procid);
  
  // the address of the peer CommLink
  // when this CommLink has a temporary connection,
  // it needs to connect to the peer CommLink 
  // each time it sends a message.
  const Addr* peer_address(void) const;
  const char* peer_hostname(void);

  // address information about the local host
  unsigned short local_port_number(void) const;
  long local_ip_address(void) const;
  const char* local_hostname(void) const;

  // this link is done.
  // this function must be called before shutting down this link;
  // otherwise, the action is treated as failure.
  void set_done(void);

  // predicate member functions to check the status of the link
  int unconnected(void) const;
  int temporary(void) const;
  int fixed_temporary(void) const;
  int dedicated(void) const;
  int broken(void) const;
  int done(void) const;


  // member functions to send and receive CommLinkMessage objects.
  static int receive_message(int,const SOCK_Stream&, Header &, Tuple *&);
	

  static int receive_message(int ntc,const SOCK_Stream& s, Header &h) {
     Tuple *t = NULL;
     int ret = receive_message(ntc,s,h,t);
     assert(t == NULL);
     return ret;
  }     
  int send_message(int need_to_convert,const SOCK_Stream&, 
		   Header &header,const Tuple *tuple = NULL);
  SOCK_Stream& TCPIP_link(void);

  int open_TCPIP_link(int =1, const Addr* =0);
  int close_TCPIP_link(void);
  void set_link_open(void);
  void set_link_closed(void);
protected:
  void peer_type(PeerType);
  int protocol_family(void) const;

  void local_port_number(unsigned short);
  void local_ip_address(long);
  void local_hostname(const char*);

  // address of the listener that a peer CommLink needs to connect to
  // when the peer communicates with this CommLink in the temporary mode.
  void peer_address(const Addr*);

  int link_open(void) const;
  int link_closed(void) const;
  int TCPIP_fd(void) const;
private:
  PeerType 	x_peer_type;
  StatusType 	x_status;
  int		x_done_flag;
  procid 	x_process_id;

  long 		x_local_ip_address; 
  unsigned short x_local_port_number; 
  char* 	x_local_hostname;

  const Addr* 	x_peer_address;
  char* 	x_peer_hostname;

  int 		x_TCPIP_flag;
  SOCK_Stream 	x_TCPIP_link;
};

#ifndef _OUTLINE_
#include "CommLink.iC"
#endif

#endif // _COMM_LINK_H_





