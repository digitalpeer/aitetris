
// This may look like C code, but it is really -*- C++ -*-
//
// File:     ServerCommLink.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//
#include <stdio.h>
#include <stream.h>
#if !defined(alpha) & 0
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    // for IPPROTO_TCP
#include <netinet/tcp.h>   // for TCP_NODELAY
#include <netdb.h>         // for gethostent
#endif
// C or C++ header files
#include <assert.h>

// ACE header files
#include "Reactor.h"

// PLinda headers
#include "Header.h"
#include "CommLink.h"
#include "ServerCommLink.h"
#include "ConnectionListener.h"
#include "MessageListener.h"
#include "ObjectSpace.h"
#include "Process.h"
#include "Scheduler.h"
#include "plinda_requests.h"

#ifdef _OUTLINE_
#define inline
#include "ServerCommLink.iC"
#endif

unsigned  short 	ServerCommLink::occupied_connections;
unsigned  short 	ServerCommLink::maximum_connections;

ServerCommLink::ServerCommLink(PeerType ptype) : CommLink(ptype) {
  // do not know its owner yet.
  s_owner = 0;

  // Not all ServerCommLink objects need to share the same message listener,
  // currently, they do.
  local_port_number(ObjectSpace::mssg_lsner.port_number());
  local_ip_address(ObjectSpace::mssg_lsner.ip_address());
}

ServerCommLink::ServerCommLink(PeerType ptype,
			       unsigned  short port,
                               long ip) : CommLink(ptype) {
  s_owner = 0;

  // This creator is intended to allow ServerCommLink 
  // to decide among multiple choices
  local_port_number(port);
  local_ip_address(ip);
}

ServerCommLink::~ServerCommLink(void) {
  // close down everything.
  shutdown();
}


void
ServerCommLink::initialize(int max_conns) {
  maximum_connections = max_conns;
  occupied_connections = 0;
}


// TCPIP_link should already have been established.
// Here, we decide which type of connection will be used,
// temporary or dedicated.
int 
ServerCommLink::establish_link(const Header &header) {
  if(!unconnected() && !fixed_temporary()) {
    // 
     Header h(Header::INFORM_ERROR);
     send_message(TCPIP_link(), h);
     close_TCPIP_link();
     return -1;
  }
  
  // some checkup
  assert(header.type() == Header::REQUEST_LINK);
  assert(process_id() == header.myProcessId());

  // record the address of the peer.
  if(peer_type() == REMOTE_HOST) {
    const INET_Addr* client_addr = new INET_Addr(header.portNumber(),
						 header.ipAddress());
    peer_address(client_addr);
  } else {
    const UNIX_Addr* client_addr = new UNIX_Addr(form("SOCKET.%d",process_id()));
    peer_address(client_addr);
  }

  // it is possible to decide a ServerCommLink to have a temporary connection
  // regardless of how many processes are around. For example, temporary
  // connections are always used for daemon processes. In that case,
  // when ServerCommLink is created, its status is set to TEMPORARY.
  if(!fixed_temporary() && dedicated_available()) {
    // allocate a dedicated connection to this link.
    Header reply(Header::ACKNOWLEDGE_DEDICATED);
    if(send_message(TCPIP_link(), reply) == -1) {
#if PL_DEBUG_COMM
      ::printf("ServerCommLink::establish_link(D), send failed.\n");
#endif
      shutdown();
      return -1;
    }
    setup_dedicated();
  } else {
    Header reply(Header::ACKNOWLEDGE_TEMPORARY);
    if(send_message(TCPIP_link(), reply) == -1) {
#if PL_DEBUG_COMM
      ::printf("ServerCommLink::establish_link(T), send failed.\n");
#endif
      shutdown();
      return -1;
    }
    // at the beginning, no need for this.
    // setup_temporary();

    // this is a temporary connection and so we re-open SOCK_Stream each time.
    close_TCPIP_link();
  }
  return 0;
} // establish_link
  
int
ServerCommLink::handle_input(int ) {
  // this link should have a dedicated link.

  assert(dedicated());
  
  Header *header = new Header;
  Tuple *t = NULL;

#ifndef NDEBUG
    fd_set rdset;
    struct timeval timeout;

    timeout.tv_sec = 0;
    timeout.tv_usec = 0;

    int link_fd = TCPIP_link().get_fd();

  FD_ZERO(&rdset);
  if(link_fd != -1) FD_SET(link_fd, &rdset);

  int num = ::select(::getdtablesize(), (fd_set*)&rdset, (fd_set*)NULL, 
		       (fd_set*)NULL, &timeout);
  if(num !=1) {
     cout << "Plinda error, trying to do a recv with nothing there\n" << flush;
     cout << "Num = " << num << endl << flush;
     delete header;
     shutdown();
     return -1;
  }
#endif  
  if(receive_message(TCPIP_link(), *header, t) == -1) {
#ifdef PL_DEBUG_COMM
       cerr << "TCPIP Link died on the server side " <<
	 " for procid " << process_id() << endl << flush;
#endif
    delete header;
    shutdown();
    return -1;
  }
  // we may need to do something for control messages.
  // now, we assume that no control message will be received.
  if(header->type() != Header::SEND_CLIENT_MESSAGE &&
     header->type() != Header::SEND_MONITOR_MESSAGE &&
     header->type() != Header::SEND_DAEMON_MESSAGE) {
    delete header;
    shutdown();
    return -1;
  }
  
  // pass this message to the process.
  owner().enqueue_request(header,t);
  return 0;
}
void
ServerCommLink::handle_input(Header* header,Tuple *tuple) {
  // this should be a termporary link. 
  // otherwise, we just ignore it because this was sent 
  // before connection was switched to dedicated.
  if(!temporary()) {
    assert(header);
    delete header;
    if(tuple) Tuple::destroy(tuple);
    return ;
  }

  // we may need to do something for control messages.
  // now, we assume that no control message will be received.  
  if(header->type() != Header::SEND_CLIENT_MESSAGE &&
     header->type() != Header::SEND_MONITOR_MESSAGE &&
     header->type() != Header::SEND_DAEMON_MESSAGE) {
    shutdown();
    delete header;
    return ;
  }

  // pass this message to the process.
  owner().enqueue_request(header,tuple);
  return ;
}

int
ServerCommLink::receive(Header &h,Tuple *&t) {
   // monitor client fns calls this
  return receive_message(TCPIP_link(), h, t);
}

int
ServerCommLink::send(Header &header, const Tuple *tuple) {
     if(temporary() && !fixed_temporary()) {
    if(dedicated_available()) {
      // we switch to the dedicated connection mode
      if(switch_to_dedicated_link() == -1) {
        shutdown();
        return -1;
      } 
    }
  }
  
  // open a temporary link if necessary.
  if(temporary()) {
    if(open_TCPIP_link() == -1) {
      shutdown();
      return -1;
    }
  }
   if(send_message(TCPIP_link(), header, tuple) == -1) {
     shutdown();
     return -1;
   }
     if(temporary()) {
       close_TCPIP_link();
     }
     return 1;
}
  
int
ServerCommLink::switch_to_dedicated_link() {
  assert(temporary());
      
  open_TCPIP_link();
  Header header;
  header.type(Header::SWITCH_TO_DEDICATED);
  if(send_message(TCPIP_link(), header) == -1) {
#ifdef PL_DEBUG_COMM
    ::printf("ServerCommLink::switch_to_dedicated_link(T), send failed\n");
#endif
    shutdown();
    return -1;
  } else {
#ifdef PL_DEBUG_COMM
    ::printf("Process %ld acquired a dedicated link.\n", process_id());
#endif
  }
  setup_dedicated();
  
  return 0;
}

int
ServerCommLink::switch_to_temporary_link() {
  assert(dedicated());
 
  Header header(Header::SWITCH_TO_TEMPORARY);
  if(send_message(TCPIP_link(), header) == -1) {
#ifdef PL_DEBUG_COMM
    ::printf("ServerCommLink::switch_to_temporary_link(T), send failed\n");
#endif
    shutdown();
    return -1;
  } else {
#ifdef PL_DEBUG_COMM
    ::printf("Process %ld released a dedicated link.\n", process_id());
#endif
  }
  close_TCPIP_link();
  setup_temporary();

  return 0;
}

void
ServerCommLink::setup_dedicated(void) {
  assert(!dedicated());
  acquire_connection();
  ObjectSpace::comm_mgr.register_handler(this, Event_Handler::READ_MASK);
  status(DEDICATED);
}

void
ServerCommLink::setup_temporary(void) {
  if(dedicated()) {
    release_connection();
    ObjectSpace::comm_mgr.remove_handler(this, Event_Handler::READ_MASK);
  }
  status(TEMPORARY);
}

void 
ServerCommLink::shutdown(void) {
  if(broken()) {
    return;
  }

  if(s_owner != 0) {
    if(done()) {
      if(owner().completed()) {
        ::printf("*** process %ld has terminated. ***\n", owner().identifier());
      } else {
        ::printf("*** error in process %ld: %s. ***\n", 
	         owner().identifier(), (owner().error()).message());
      }
    } else {
      if(!owner().about_to_end()) {
        ::printf("*** process %ld has failed. ***\n", owner().identifier());

        // force the schedure to activate failure detection.
        ObjectSpace::scheduler.detect_failure();
      } 
    }
  }

  if(dedicated()) {
    // first, need to release the dedicated link 
    // so that another ServerCommLink can use it.
    setup_temporary();
  }

  if(link_open()) {
    close_TCPIP_link();
  }
  // set the status to be broken.
  status(BROKEN);
}

// Detect process failiures by sending dummy messages periodically.
// the TCP/IP protocol will detect such failures.
// Right now, we send a control message to a client.
int
ServerCommLink::check_failure() {
  if(broken()) {
    // failure has already been detected.
    return -1;
  }

  // open a temporary link if necessary.
  if(temporary()) {
    if(open_TCPIP_link() == -1) {
      shutdown();
      return -1;
    }
  }

  Header header;
  header.type(Header::CHECK_FAILURE);
  if(send_message(TCPIP_link(), header) == -1) {
    shutdown();
    return -1;
  }

  if(temporary()) {
    close_TCPIP_link();
  }
  
  return 1;
}









