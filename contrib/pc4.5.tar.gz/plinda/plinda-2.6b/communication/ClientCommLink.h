// This may look like C code, but it is really -*- C++ -*-
//
// File:     ClientCommLink.h
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//
#ifndef _CLIENT_COMM_LINK_H_
#define _CLIENT_COMM_LINK_H_

// ACE headers
#include "Addr.h"
#include "SOCK_Listener.h"
#include "SOCK_Stream.h"

// PLinda header files
#include "plinda_ids.h"
#include "CommLink.h"
#include "Header.h"

const int DEFAULT_NUM_TRIES = 3;

class ClientCommLink : public CommLink {
public:
  // Constructors
  ClientCommLink(int tries =DEFAULT_NUM_TRIES);
  ClientCommLink(procid pid, unsigned short server_port, 
		 const char* server_host,
		 int tries =DEFAULT_NUM_TRIES);
  ClientCommLink(procid pid, unsigned short server_port, long server_ip,
		 int tries =DEFAULT_NUM_TRIES);

  // Initialize the communication link 
  int initialize(procid pid, unsigned short server_port, 
		 const char* server_host,int need_to_convert);
  int initialize(procid pid, unsigned short server_port, long server_ip,
		 int need_to_convert);


  // set up a connection link which may be temporary or dedicated.
  int request_link(void);

  // close sockets
  void close(void);

  // blocking send and receive functions
  int receive(Header&,Tuple*&);
  int send(Header&,const Tuple *);
  int send(Header& h) {
     Tuple *t = NULL; 
     int sbytes = send(h,t); 
     assert(t == NULL); 
     return sbytes;
  }
  
  // nonblocking receive function.
  int async_receive(Header &,Tuple *&, int=0);

  // enable SIGIO
  int sigio_flag(void) const;
  int enable_sigio(void);
  int disable_sigio(void);

  // signal catcher
  static void sigio_catcher(int);

  // for now, just call ::exit.
  void fail(void);
private:
  int x_need_to_convert;
  // control messages such as SWITCH_TO_DEDICATED or CHECK_FAILURE 
  // are processed.
  int handle_control_message(const Header&);

  // the address of the server's Connection Listener. 
  void server_address(const Addr*);
  const Addr* server_address(void) const;

  // local listener.
  const SOCK_Listener& listener(void) const;

  // Connection request might fail 
  // when there are a large number of processes attempting to connect.
  // Then, it is required to retry, but there should be a limit 
  // to the number of retries.
  int num_tries() const;

  ////////////////////////////////////////////////////////////
  // private data members
  ////////////////////////////////////////////////////////////
  const Addr* c_server_address;

  // how many times do we retry to connect to the server ?
  int c_num_tries;

  // SIGIO interrupt flag
  static int c_sigio_flag;

  // listener for a temporary connection.
  SOCK_Listener c_listener;
};

#ifndef _OUTLINE_
#include "ClientCommLink.iC"
#endif

#endif // _CLIENT_COMM_LINK_H_

