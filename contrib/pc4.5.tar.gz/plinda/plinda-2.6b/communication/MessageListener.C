// This may look like C code, but it is really -*- C++ -*-
//
// File:     MessageListener.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu

#include <stdio.h>
#if !defined(alpha) & 0
#include <sys/types.h>
#include <sys/socket.h>
#endif
// ACE header files
#include "INET_Addr.h"

// PLinda header files
#include "MessageListener.h"
#include "CommLink.h"
#include "ServerCommLink.h"
#include "ClientProcess.h"
#include "ProcessManager.h"
#include "ObjectSpace.h"

#ifdef _OUTLINE_
#define inline
#include "MessageListener.iC"
#endif

int 
MessageListener::handle_input(int) {


#ifdef PL_DEBUG_COMM
  ::printf("received a request via a temporary link\n");
#endif

  if(listener().accept(TCPIP_link()) == -1) {
#ifdef PL_DEBUG_COMM
    ::perror("MessageListener::handle_input, accept");
#endif
    return 0;
  }

  Header *header = new Header;
  Tuple *tuple = NULL;
  int rbytes = CommLink::receive_message(0,TCPIP_link(), *header, tuple);

  if(rbytes == 0 || rbytes == -1) {
#ifdef PL_DEBUG_COMM
    ::perror("MessageListener::handle_input, accept");
#endif
    delete header;
    TCPIP_link().close();
    return 0;
  }
#ifdef PL_DEBUG_COMM
  ::printf("received a request from process %ld via a temporary link\n",
	   header->myProcessId()); 
#endif
  Process* proc;
  proc = ObjectSpace::proc_mgr.find_process(header->myProcessId());
  if(proc == 0) {
#ifdef PL_DEBUG_COMM
    ::printf("MessageListener::unknown pid %ld\n",header->myProcessId());
    fflush(stdout);
#endif
    TCPIP_link().close();
    delete header;
    return 0;
  }
  ServerCommLink* comm_link = proc->comm_link();
  comm_link->handle_input(header,tuple);

  TCPIP_link().close();
  return 0;
}
