// This may look like C code, but it is really -*- C++ -*-
//
// File:     ClientCommLink.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//
#include <stdio.h>
#include <stream.h>
#if !defined(alpha) & 0
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    // for IPPROTO_TCP
#include <netinet/tcp.h>   // for TCP_NODELAY
#include <netdb.h>         // for gethostent
#endif
// C or C++ header files
#include <assert.h>

// PLinda headers
#include "CommLink.h"
#include "ClientCommLink.h"
#include "C_Interface.h"
#include "Header.h"

class Tuple;

#ifdef _OUTLINE_
#define inline
#include "ClientCommLink.iC"
#endif

int ClientCommLink::c_sigio_flag = 0;

ClientCommLink::ClientCommLink(int tries) {
  c_num_tries = tries;
}

ClientCommLink::ClientCommLink(procid pid,
			       unsigned short server_port,
			       const char* server_host, 
			       int tries) {
  c_num_tries = tries;
  c_sigio_flag = 0;
  // first get info about the server
  struct hostent* hp = ::gethostbyname((char*)server_host);
  assert(hp != 0);
  long server_ip = *((long*)(hp->h_addr_list[0]));
  initialize(pid, server_port, server_ip,0);
}

ClientCommLink::ClientCommLink(procid pid,
			       unsigned short server_port,
			       long server_ip,
			       int tries) {
  c_num_tries = tries;
  c_sigio_flag = 0;

  initialize(pid, server_port, server_ip,0);
}

int
ClientCommLink::initialize(procid pid,
			   unsigned short server_port,
			   const char* server_host,int need_to_convert) {
  // first get info about the server
  struct hostent* hp = ::gethostbyname((char*)server_host);
  assert(hp != 0);
  long server_ip = *((long*)(hp->h_addr_list[0]));
  return initialize(pid, server_port, server_ip,need_to_convert);
}

void
ClientCommLink::close(void) {
  if(!link_closed()) {
    close_TCPIP_link();
  }
  c_listener.close();
}


int
ClientCommLink::initialize(procid pid,
			   unsigned short server_port,
			   long server_ip,int need_to_convert) {
  x_need_to_convert = need_to_convert;
  // if server is the other endian from us then every
  // communication we need to reverse the byte ordering of all
  // ints.
  process_id(pid);
  char h_name[1000];
  ::gethostname(h_name, 1000);
  struct hostent* hp = ::gethostbyname((char*)h_name);
  assert(hp != 0);
  long local_ip = *((long*)(hp->h_addr_list[0]));

//  For now, we do not care about IPC because TCP/IP is smart
//  enough not to go out to a network in case of local communication.
//  if(local_ip == server_ip) {
//    peer_type(LOCAL_HOST);
//    UNIX_Addr* addr = new UNIX_Addr(form("SOCKET.dedicated"));
//    server_address(addr);
//    if(listener().open(UNIX_Addr(form("SOCKET.%d", process_id())), 
//		  1, -1, protocol_family()) == -1) {
//      status(BROKEN);
//    }
//    local_port_number(0);
//    local_ip_address(0);
//  } else {

  peer_type(REMOTE_HOST);


  INET_Addr* addr = new INET_Addr(server_port, server_ip);
  server_address(addr);
    if(c_listener.open(INET_Addr((unsigned short)0), 1, -1, protocol_family()) == -1) {
      status(BROKEN);
      return -1;
    }
    INET_Addr temp;
    c_listener.get_local_addr(temp);
    local_port_number((temp.get_port_number()));
    local_ip_address(local_ip);

//  }

  return 0;
}

int
ClientCommLink::request_link() {
  if(open_TCPIP_link(num_tries(), server_address()) == -1) { 
#ifdef PL_DEBUG_COMM
    ::perror("ClientCommLink::request_link\n");
#endif // PL_DEBUG
    status(BROKEN);
    return -1;
  }

  // receive a control message from a client 
  // which should be a connection request.
  // the control message does not carry any contents.

  Header request(Header::REQUEST_LINK);
  if(send_message(x_need_to_convert,TCPIP_link(), request) == -1) {
    status(BROKEN);
    return -1;
  }
  Header reply;
  if(CommLink::receive_message(x_need_to_convert,TCPIP_link(), reply) == -1) {
    status(BROKEN);
    return -1;
  }
  assert(reply.controlMessage());
  if(reply.type() == Header::ACKNOWLEDGE_DEDICATED) {
    status(DEDICATED);

#ifdef PL_DEBUG_COMM
    ::printf("Process %ld obtained a dedicated link.\n", process_id());
#endif

  } else {
    if(reply.type() == Header::ACKNOWLEDGE_TEMPORARY) {
      status(TEMPORARY);
      close_TCPIP_link();

#ifdef PL_DEBUG_COMM
    ::printf("Process %ld obtained a temporary link.\n", process_id());
#endif

    } else {
#ifdef PL_DEBUG_COMM
      cerr << "PLbad message type recvd: " << reply.type() << endl << flush;
      // unexpected message type.
#endif
      status(BROKEN);
      return -1;
    }
  }

  // information about the local and peer ends for later communication.
  // The ServerCommLink constructor also collects information 
  // the local end.
  if(peer_type() == REMOTE_HOST) {
    const INET_Addr* server_addr = new INET_Addr(reply.portNumber(), 
						 reply.ipAddress());
    peer_address(server_addr);
  } else {
    const UNIX_Addr* server_addr = new UNIX_Addr("SOCKET.temporary");
    peer_address(server_addr);
  }
  return 0; 
} // request_link


int
ClientCommLink::receive(Header &message, Tuple *&tuple) {
  // already failed ?
  assert(tuple == 0);
  assert(message.empty());
  if(broken()) {
#ifdef PL_DEBUG_COMM
    cerr << "ClientCommLink TCPIP link is broken\n" << flush;
#endif
    return -1;
  }

  while(1) {

    // temporary connection  ------------------------------------
    if(temporary()) {

#ifdef PL_DEBUG_COMM
      ::printf("Process %ld waits for a reply via a temporary link.\n",
	       process_id());
#endif

      if(c_listener.accept(TCPIP_link()) == -1) {
#ifdef PL_DEBUG_COMM
	cerr << "ClientCommLink didn't accept on the listener\n" << flush;
#endif
	status(BROKEN);
	return -1;
      } else {
	set_link_open();
      }

#ifdef PL_DEBUG_COMM
      ::printf("Process %ld accepted a temporary link request.\n",
	       process_id());
#endif
    }

    // read a message ------------------------------------------
    if(receive_message(x_need_to_convert,TCPIP_link(), message, tuple) == -1) {
#ifdef PL_DEBUG_COMM
       cerr << "TCPIP Link died on client procid " << process_id() << 
	 endl << flush;
#endif
      status(BROKEN);
      return -1;
    } 

    // temporary connection  ------------------------------------
    if(temporary()) {
      close_TCPIP_link();
    }

    if(message.type() == Header::SEND_CLIENT_MESSAGE ||
       message.type() == Header::SEND_MONITOR_MESSAGE ||
       message.type() == Header::SEND_DAEMON_MESSAGE) {
      break;
    }
    assert(message.controlMessage());
    // handle control messages ------------------------------------------
    if(handle_control_message(message) == -1) {
      status(BROKEN);
      return -1;
    } 

  } // while --- we do not exit this loop until receive a message.

  return 1;
}

int
ClientCommLink::send(Header& message, const Tuple *tuple) {

  // already failed ?
  if(broken()) {
    return -1;
  }

  int rbytes;

  // temporary connection  ------------------------------------
  if(temporary()) {
    if(open_TCPIP_link(num_tries()) == -1) {
      status(BROKEN);
      return -1;
    }
  }
  // send a message ------------------------------------------
  if((rbytes = send_message(x_need_to_convert,TCPIP_link(), message,tuple)) == -1) {
    status(BROKEN);
    return -1;
  }
  // temporary connection  ------------------------------------
  if(temporary()) {
    close_TCPIP_link();
  }
  return rbytes;
}
  
int
ClientCommLink::handle_control_message(const Header& message) {
  switch(message.type()) {

  case Header::SWITCH_TO_DEDICATED:
#ifdef PL_DEBUG_COMM
    ::printf("Process %ld received SWITCH_TO_DEDICATED.\n", process_id());
#endif   
    status(DEDICATED);
    break;

  case Header::SEND_CLIENT_MESSAGE:
    break;
  case Header::SEND_DAEMON_MESSAGE:
    break;
  case Header::SEND_MONITOR_MESSAGE:
    break;

  case Header::CHECK_FAILURE:
#ifdef PL_DEBUG_COMM
    ::printf("Process %ld received CHECK FAILURE message.\n", process_id());
#endif   
    break;

  default:
#ifdef PL_DEBUG_COMM
    cerr << "ClientCommLink got a bad control message\n" << flush;
#endif
    status(BROKEN);
    return -1;
  }

  return 0;
}
  
#ifdef hpux
extern "C" int getrlimit(int, struct rlimit *);

int getdtablesize(void) {
     struct rlimit *rlp;
     getrlimit(RLIMIT_NOFILE, rlp);
     return(rlp->rlim_cur);
}
#endif
 



int
ClientCommLink::async_receive(Header& message, Tuple *&tuple,int timeout_sec) {
  // already failed ?
  if(broken()) {
    return -1;
  }
  { // ----------------------------------------------------------------
    fd_set rdset;
    struct timeval timeout;

    timeout.tv_sec = timeout_sec ;
    timeout.tv_usec = 0;

    int link_fd = TCPIP_link().get_fd();
    int listener_fd = c_listener.get_fd();
    INET_Addr temp;
    c_listener.get_local_addr(temp);
    FD_ZERO(&rdset);
    if(link_fd != -1) FD_SET(link_fd, &rdset);
    if(listener_fd != -1) FD_SET(listener_fd, &rdset);

    int num = ::select(::getdtablesize(), &rdset, NULL, NULL, &timeout);
    if(num == 0) return 0;
    else if(num == -1) return -2; 
  } // -----------------------------------------------------------


  // temporary connection  ------------------------------------
  if(temporary()) {

#ifdef PL_DEBUG_COMM
    ::printf("Process %ld waits for a reply via a temporary link.\n",
	     process_id());
#endif

    if(c_listener.accept(TCPIP_link()) == -1) {
      status(BROKEN);
      return -1;
    } else {
      set_link_open();
    }

#ifdef PL_DEBUG_COMM
    ::printf("Process %ld accepted a temporary link request.\n",
	     process_id());
#endif
  }

  // read a message ------------------------------------------
  if(receive_message(x_need_to_convert,TCPIP_link(), message, tuple) == -1) {
    status(BROKEN);
    return -1;
  } 

  // temporary connection  ------------------------------------
  if(temporary()) {
    close_TCPIP_link();
  }

    if(message.type() == Header::SEND_CLIENT_MESSAGE ||
       message.type() == Header::SEND_MONITOR_MESSAGE ||
       message.type() == Header::SEND_DAEMON_MESSAGE) {
      return 1;
   }
  
  // handle control messages ------------------------------------------
  if(handle_control_message(message) == -1) {
    status(BROKEN);
    return -1;
  } 
  return 0;
}


int
ClientCommLink::enable_sigio(void) {
  assert(status() == DEDICATED || status() == TEMPORARY);
  assert(c_sigio_flag == 0);
  if(status() == DEDICATED) {
    TCPIP_link().enable(SIGIO);
  } else {
    c_listener.enable(SIGIO);
  }
  ::signal(SIGIO, ClientCommLink::sigio_catcher);
  c_sigio_flag = 1;
  return 1;
}


int
ClientCommLink::disable_sigio(void) {
  assert(status() == DEDICATED || status() == TEMPORARY);
  assert(c_sigio_flag == 1);
  if(status() == DEDICATED) {
    TCPIP_link().disable(SIGIO);
  } else {
    c_listener.disable(SIGIO);
  }
  c_sigio_flag = 0;
  return 1;
}


void
ClientCommLink::sigio_catcher(int sig) {
  (void)sig; // keep compiler quiet
}


  





