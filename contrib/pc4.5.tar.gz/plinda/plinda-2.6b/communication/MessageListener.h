// This may look like C code, but it is really -*- C++ -*-
//
// File:     MessageListener.h
// Created:  
// Author:   Karp Joo Jeong 
// Mail:     jeong@cs.nyu.edu

#ifndef _MESSAGE_LISTENER_H_
#define _MESSAGE_LISTENER_H_

#include <sys/types.h>

// ACE header files
#include "Event_Handler.h"

// PLinda header files
#include "CommLink.h"
#include "Listener.h"

class MessageListener : public Listener, public Event_Handler {
public:
  MessageListener(CommLink::PeerType =CommLink::REMOTE_HOST);
  MessageListener(const INET_Addr&);
  MessageListener(const UNIX_Addr&);

  virtual int get_fd (void) const;
  virtual int handle_input(int);

  SOCK_Stream& TCPIP_link(void);
private:
  SOCK_Stream m_TCPIP_link;
};

#ifndef _OUTLINE_
#include "MessageListener.iC"
#endif

#endif // _MESSAGE_LISTENER_H_
