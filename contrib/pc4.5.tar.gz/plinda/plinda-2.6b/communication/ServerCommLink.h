// This may look like C code, but it is really -*- C++ -*-
//
// File:     ServerCommLink.h
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//
#ifndef _SERVER_COMM_LINK_H_
#define _SERVER_COMM_LINK_H_

// ACE headers
#include "Addr.h"
#include "SOCK_Stream.h"
#include "Event_Handler.h"

// PLinda header files
#include "CommLink.h"
class Process;

class ServerCommLink : public CommLink, public Event_Handler {
public:
  // Constructors
  ServerCommLink(PeerType ptype);
  ServerCommLink(PeerType ptype, unsigned  short listener_port, long local_ip);
  virtual ~ServerCommLink(void);

  // ----------------------------------------------------------------
  // initialize
  // ----------------------------------------------------------------

  static void initialize(int max_conns); 


  // ----------------------------------------------------------------
  // ServerCommLink is supposed to serve a process. 
  // ----------------------------------------------------------------
  Process& owner(void) const;
  void owner(Process*);


  // ----------------------------------------------------------------
  // When a client process sets up a communication link to the server,
  // it calls the ConnectionListener and the ConnectionListener
  // creates a ServerCommLink object and calls the establish_link
  // member function of the object.
  // ----------------------------------------------------------------
  int establish_link(const Header&);


  // ----------------------------------------------------------------
  // Functions for dedicated connection 
  // called by the communication manager.
  // ----------------------------------------------------------------
  virtual int get_fd(void) const;
  virtual int handle_input(int);

  // ----------------------------------------------------------------
  // Those client processes that do not have dedicated connection
  // send messages to the MessageListener. The MessageListerner
  // delivers(multiplexes) them to processes where the messages 
  // are destinated. 
  // ----------------------------------------------------------------
  void handle_input(Header*,Tuple *);

  // send and receive functions
  // The communication manager ensures that, when receive is called, 
  // there must be a message in the ServerCommLink. 
  int send(Header &, const Tuple * );
  int send(Header& h) { 
     Tuple *t = NULL; 
     int sbytes = send(h,t); 
     assert(t == NULL); 
     return sbytes;
  }
  int receive(Header &, Tuple *&  );
  int receive(Header &h) { 
     Tuple *t = NULL; 
     int rbytes = receive(h,t); 
     assert(!t);
     return rbytes;
  }

  // check if the client process failed. 
  int check_failure(void);
  void shutdown(void);


  // -----------------------------------------------------------------
  // Maximu connections
  // -----------------------------------------------------------------
  
  static void acquire_connection(void);
  static void release_connection(void);

private:
  static unsigned  short maximum_connections;
  static unsigned  short occupied_connections;

  void setup_dedicated(void);
  void setup_temporary(void);
  int dedicated_available(void) const;

  // Request the peer processs to switch 
  // between the dedicated and temporary connection modes.
  int switch_to_dedicated_link();
  int switch_to_temporary_link();

  // process that owns this ServerCommLink
  Process* s_owner;
};

#ifndef _OUTLINE_
#include "ServerCommLink.iC"
#endif

#endif // _SERVER_COMM_LINK_H_
