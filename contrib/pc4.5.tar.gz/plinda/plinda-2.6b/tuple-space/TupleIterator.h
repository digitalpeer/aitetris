
#ifndef _TupleIterator_h_
#define _TupleIterator_h_

#include <Pix.h>

#include "PatternNode.h"

class Storage;
class Tuple;

class TupleIterator {

  public:
    
    TupleIterator(){ clear(); }
    TupleIterator(PatternNodeList* plist){ clear(); pattern_list = plist; }
    ~TupleIterator(){ clear(); }


    Tuple*     first(void);
    Tuple*     next(void);
    void       clear();
    void       init(PatternNodeList* plist){ clear(); pattern_list = plist; }

  private:

    PatternNodeList*   pattern_list;
    Storage*           cur_store;
    Tuple*             cur_tuple;
    Pix                pos_in_pat_list;
    Pix                pos_in_store_hdr;

};


#endif   /* _TupleIterator_h_ */
