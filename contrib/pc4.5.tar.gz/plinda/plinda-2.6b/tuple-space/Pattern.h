#ifndef _Pattern_H_
#define _Pattern_H_ 1

#define MAXTUPLEFIELDSDIV2 10
// the above should be half the number of tuple fields allowed 
// So for 20 fields it will be 10

#include <stream.h>
#include <stdio.h>
#include <assert.h>

class Pattern {
   friend class CheckPoint;
   friend class TupleGroup;
   friend class PatternNode;
   friend class Tuple;
   friend ostream &operator<<(ostream &os, const Pattern &pa) ;
 public:
   const bool operator!=(const Pattern &o) const {
      assert(valid && o.valid);
      return memcmp(pat,o.pat, MAXTUPLEFIELDSDIV2);
   }
   const bool operator==(const Pattern &o) const { return ! operator!=(o); }
 private:
   char valid;
   unsigned char pat[MAXTUPLEFIELDSDIV2];
   void init() { valid = false;
		 for(int i = 0 ; i < MAXTUPLEFIELDSDIV2 ; i ++)
		   pat[i] = 0; 
	      }
   Pattern() { init();  }
};



#endif


