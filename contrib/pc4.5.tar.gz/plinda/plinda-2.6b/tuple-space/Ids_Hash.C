


#ifndef _Ids_Hash_C_
#define _Ids_Hash_C_

#include "plinda_ids.h"

unsigned int gidhash(gid& g){ return g.hash(); }
unsigned int physidhash(physid& h){ return h.hash(); }

#endif  // _Ids_Hash_C_
