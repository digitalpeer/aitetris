
#ifndef  _Storage_H_
#define  _Storage_H_ 1

#include "Tuple.h"

class Storage {

 public:
  virtual TupleList&  operator [] (int key) = 0;
  virtual Pix         first() = 0;
  virtual int&        key(Pix i) = 0;
  virtual TupleList&  contents(Pix i) = 0;
  virtual Pix         seek(int key) = 0;
  virtual int         contains(int key) = 0;
  virtual int         OK() = 0;

  virtual void        del(int key) = 0;
  virtual void        next(Pix& i) = 0;
  virtual void        clear() = 0;

};


#endif  /* _Storage_H_ */

