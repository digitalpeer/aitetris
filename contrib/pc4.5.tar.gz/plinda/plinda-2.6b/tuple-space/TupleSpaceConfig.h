



// This may look like C code, but it is really -*- C++ -*-
//
// File:        TupleSpaceConfig.h


#ifndef _TupleSpaceConfig_H_
#define _TupleSpaceConfig_H_ 1

#include <stream.h>
#include <sys/types.h>
#include <Pix.h>
#include "plinda_ids.h"

#define  PL_TRUE   1
#define  PL_FALSE  0

const int PL_UN_LOCK = 0;
const int PL_DEFAULT_LK = 0;

const int PL_LOCK_INP = 1;
const int PL_LOCK_RDP = 2;

const int PL_DEFAULT_HASHTAB_SZ = 100;
const int PL_DEFAULT_STORE_SZ = 200;
const int PL_DEFAULT_KEYFLD_IDX = 0;



#ifndef _STORE_CONSTS_
#define _STORE_CONSTS_ 1

#define PL_CHAINED_HASH_STORE  1
#define PL_AVL_TREE_STORE 2
#define PL_SPLAY_TREE_STORE 3
#define PL_LIST_STORE 4
// Currently List Store does not work
#define PL_DEFAULT_STORE 1
// PL_DEFAULT_STORE = PL_CHAINED_HASH_STORE

#endif // _STORE_CONSTS_


const int PL_LOW_RANGE = 0;
const int PL_HIGH_RANGE = 1;
const int PL_RANDOM_NO = 317;

#endif // _TupleSpaceConfig_H_
