
#ifndef _AVLTree_H_
#define _AVLTree_H_ 1

#include "int.TupleList.AVLMap.h"
#include "Storage.h"

class AVLTree : public Storage {

 public:

  AVLTree(TupleList& dflt) : avl_tree(dflt) {}
  //~AVLTree(){ avl_tree.~intTupleListAVLMap(); }

  TupleList&  operator [] (int key){ return (avl_tree.operator[](key)); }
  void        del(int key){ avl_tree.del(key); }
  Pix         first(){ return (avl_tree.first()) ; }
  void        next(Pix& i){ avl_tree.next(i); }
  int&        key(Pix i){ return (avl_tree.key(i)) ; }
  TupleList&  contents(Pix i){ return (avl_tree.contents(i)); }
  Pix         seek(int key){ return (avl_tree.seek(key)); }
  int         contains(int key){ return (avl_tree.contains(key)); }
  void        clear(){ avl_tree.clear(); }
  int         OK(){ return (avl_tree.OK()); }
  void        destroy(){ avl_tree.~intTupleListAVLMap(); }

 private:
  intTupleListAVLMap  avl_tree;

};

#endif   // _AVLTree_H_




