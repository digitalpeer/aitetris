#include "TupleField.h"
#include <assert.h>


#ifdef _OUTLINE_
#define inline
#include "TupleField.iC"
#endif



static inline void reverse (int &word)
{
  assert(sizeof(int) == 4);
  int x = word;
  swab((char*)&word,((char*)&word)+2,2);
  swab(((char*)&x)+2,(char*)&word,2);
}


static inline void reverse (unsigned int &word)
{
  assert(sizeof(int) == 4);
  int x = word;
  swab((char*)&word,((char*)&word)+2,2);
  swab(((char*)&x)+2,(char*)&word,2);
}

static void reverseAll(int *array,int totLength)
{
  const int num = totLength/sizeof(int);
  int temp;
  assert(num*sizeof(int) == totLength);
  for(int i = 0 ; i < num ; i++) {
    memcpy(&temp,&array[i],sizeof(int));
    reverse(temp);
    memcpy(&array[i],&temp,sizeof(int));
  }
}

void *TupleField::reverseEndian(TupleField &tf,int isMyEndianNow,
			       void *nextArrayLoc)
{

  assert(tf.valid);
  if(tf.isAFormal) {
    reverse(tf.totalSize);
    return nextArrayLoc;
  }
  if(! isMyEndianNow) {
    reverse(tf.totalSize);
    if(tf.isArray || tf.myBasicType == PLstruct) {
      tf.data.array = nextArrayLoc;
      nextArrayLoc += tf.totalSize;
    }
  }

  switch(tf.myBasicType) {
  case PLlong:
    if(sizeof(long) == sizeof(int)) {
      cerr << "********** PLinda  error: cannot use heterogeneous when " <<
	" you have longs in your program, aborting!!!\n" << flush;
      ::exit(1);
    }
    if(tf.isArray) 
      reverseAll((int*)tf.data.array,tf.totalSize);
    else
      reverse((int&)tf.data.Long);
    break;
 case PLphysid:
    if(tf.isArray)
      reverseAll((int*)tf.data.array,tf.totalSize);
    else {
      reverse(tf.data.PhysId.low);
      reverse(tf.data.PhysId.high);
    }
    break;
  case PLgid:
    if(tf.isArray)
      reverseAll((int*)tf.data.array,tf.totalSize);
    else {
      reverse(tf.data.Gid.low);
      reverse(tf.data.Gid.high);
    }
    break;
  case PLint:
    if(tf.isArray) {
      reverseAll((int*)tf.data.array,tf.totalSize);
    }
    else  {
      reverse(tf.data.Int);
    }
    break;
  case PLfloat:
    if(tf.isArray)
      reverseAll((int*)tf.data.array,tf.totalSize);
    else  {
     reverse((int&)(tf.data.Float));
    }
    break;
  case PLdouble:
    if(tf.isArray)
      reverseAll((int*)tf.data.array,tf.totalSize);
    else  {
     int *temp = (int*)&(tf.data.Double);
     reverse(temp[0]);
     reverse(temp[1]);
    }
    break;
  case PLchar:
  case PLstruct:
    break;
  default:
    assert(0);
  }
  if(isMyEndianNow)
    reverse(tf.totalSize);
    return nextArrayLoc;
}
  
void TupleField::pattern(unsigned char &patField,int lowerOrUpper) const
{
  const int ArrayPattern = 8;
  assert(lowerOrUpper == 0 || lowerOrUpper == 1);
  unsigned char myPat = (unsigned char)myBasicType;
  assert(myPat < 8 ); // can only represent 8 types
  if(isArray)
    myPat += ArrayPattern;
  assert(myPat <= 15);
  if(lowerOrUpper == 1) { // upper part
    myPat = myPat << 4;
    if(isArray)
      assert(myPat >= 128);
  }
  patField += myPat;
}

const int BasicTypeSize[] =
{ PL_INT_SZ, PL_CHAR_SZ, PL_GID_SZ, PL_LONG_SZ, PL_PHYSID_SZ, PL_FLOAT_SZ,
  PL_DOUBLE_SZ };

void TupleField::initialize(BasicTypes bt, bool isA, int howMany) 
{

  assert((int)bt < 7 && (int)bt >= 0);
  assert(!valid);
  // for actuals
  assert(isA ==true  || howMany == 1);
#ifndef NDEBUG
  if(howMany < 0) {
     cerr << "User error: the size of an array must be positive\n";
     cerr << "you have specified an array of length " << howMany << endl;
     cerr << "Fatal error....\n" << flush;
     ::exit(1);
  }
#endif
  memset(&data,0,sizeof(BasicData));
  valid = 1;
  myBasicType = bt; 
  isArray = isA;
  totalSize = BasicTypeSize[(int)bt] * howMany;
  isAFormal = 0;
}


void TupleField::initializeStruct(bool isA, int structSize,int howMany) 
{
  assert(isA || howMany == 1);
  assert(!valid);
  // for actuals
  assert(structSize >= 0);
#ifndef NDEBUG
  if(howMany < 0) {
     cerr << "User error: the size of an array must be positive\n";
     cerr << "you have specified an array of length " << howMany << endl;
     cerr << "Fatal error....\n" << flush;
     ::exit(1);
  }
#endif
  memset(&data,0,sizeof(BasicData));
  valid = 1;
  myBasicType = TupleField::PLstruct; 
  isArray = isA;
  totalSize = structSize * howMany;
  isAFormal = 0;
}

void TupleField::bindFormals(TupleField &other) 
{
  assert(valid);
  assert(other.valid);
  assert(isArray == other.isArray && myBasicType == other.myBasicType);
  if(isActual()) 
    return;

  assert(other.isActual());
#ifndef NDEBUG
  if(!isArray && myBasicType == TupleField::PLstruct &&
     totalSize != other.totalSize) {
     cerr << "PLinda user error: trying to match two structs of different" <<
       " sizes one = " << totalSize << " the other = " << other.totalSize <<
	 endl << flush;
     ::exit(1);
  }
//  assert(isArray || totalSize == other.totalSize);
#endif
  assert(isArray || myBasicType == PLstruct ||
	 (int)totalSize == BasicTypeSize[myBasicType]);
#ifndef NDEBUG
  if(totalSize < other.totalSize) {
    cerr << "Warning, a formal size seems to be smaller than the" <<
      "corresponding actual it matched in tuple space" << endl <<
	"formal size = " << totalSize << " the actual size = " <<
	  other.totalSize << endl <<
	    "It is likely  this will cause a segmentation fault\n" << flush;
  }
#endif
  if(isArray ||  myBasicType == PLstruct)
    memcpy(data.array,other.data.array,other.totalSize);
  else
    memcpy(data.array,&(other.data),other.totalSize);
}

static void printFormal(ostream &os, char *type, bool array)
{
  os << type;
  if(array)
    os << " array formal";
  else
    os << " formal";
  os << flush;
}
ostream& operator<<(ostream& os, const TupleField& t) 
{
  // When accessing the array fields, must use memcpy since they
  // may be aligned incorrectly due to char array etc being in front
  // of them.
  // Currently this code also memcpys for scalars but it need not

  os << "(" << flush;
  assert(t.valid);

  switch(t.myBasicType) {
  case TupleField::PLint:
    if(t.isFormal()) 
      printFormal(os,"integer",t.isArray);
    else if(t.isArray) {
      for(unsigned i = 0 ; i < t.totalSize/sizeof(int) ; i++) {
	int temp;
	memcpy(&temp, t.data.array + i * sizeof(int), sizeof(int));
	os << temp << " " << flush;
      }
    }
    else {
      int temp;
      memcpy(&temp, &t.data.Int, sizeof(int));
      os << temp  << flush;
    }
    break;
  case TupleField::PLgid:
    if(t.isFormal())
      printFormal(os,"gid",t.isArray);
    else if(t.isArray)
      for(unsigned i = 0 ; i < t.totalSize/sizeof(gid) ; i ++) {
	gid g;
	memcpy(&g, t.data.array + i * sizeof(gid) , sizeof(gid));
	os << g << " "  << flush;
      }
    else {
      gid g;
      memcpy(&g, &t.data.Gid, sizeof(gid));
      os << g << flush;
    }
    break;
  case TupleField::PLchar:
    if(t.isFormal())
      printFormal(os,"Char",t.isArray);
    else if(t.isArray)
      for(unsigned i = 0 ; i < t.totalSize/sizeof(char) ; i++) {
	char c;
	memcpy(&c, t.data.array + i * sizeof(char), sizeof(char));
	os << c  << flush;
      }
    else {
      char c;
      memcpy(&c, &t.data.Char, sizeof(char));
      os << c  << flush;
    }
    break;
  case TupleField::PLlong:
    if(t.isFormal())
      printFormal(os,"Long",t.isArray);
    else if(t.isArray)
      for(unsigned i = 0 ; i < t.totalSize/sizeof(long); i++) {
	long l;
	memcpy(&l, t.data.array + i * sizeof(long) , sizeof(long));
	os << l << " "  << flush;
      }
    else {
      long l;
      memcpy(&l, &t.data.Long, sizeof(long));
      os << l  << flush;
    }
    break;
  case TupleField::PLphysid:
    if(t.isFormal())
      printFormal(os,"Physid",t.isArray);
    else if(t.isArray)
      for(unsigned i = 0 ; i < t.totalSize/sizeof(physid) ; i++) {
	physid p;
	memcpy(&p, t.data.array + i * sizeof(physid), sizeof(physid));
	os << p << flush;
      }
    else {
      physid p;
      memcpy(&p, &t.data.PhysId, sizeof(physid));
      os << p  << flush;
    }
    break;
  case TupleField::PLfloat:
    if(t.isFormal())
      printFormal(os,"Float",t.isArray);
    else if(t.isArray)
      for(unsigned i = 0 ; i < t.totalSize/sizeof(float) ; i++) {
	float f;
	memcpy(&f, t.data.array + i * sizeof(float), sizeof(float));
	os << f << " "   << flush;
      }
    else {
      float f;
      memcpy(&f, &t.data.Float, sizeof(float));
      os << f  << flush;
    }
    break;
  case TupleField::PLstruct:
    if(t.isFormal())
      printFormal(os,"Struct",t.isArray);
    else {
       os << "Struct actual";
    }
    break;
  case TupleField::PLdouble:
    if(t.isFormal())
      printFormal(os,"Double",t.isArray);
    else if(t.isArray)
      for(unsigned i = 0 ; i < t.totalSize/sizeof(double) ; i++) {
	double d;
	memcpy(&d, t.data.array + i * sizeof(double), sizeof(double));
	os << d << flush;
      }
    else {
      double d;
      memcpy(&d, &t.data.Double, sizeof(double));
      os << d  << flush;
    }
    break;

  default:
    cerr << "Trying to print strange tuple field type it is " << flush <<
      t.myBasicType << endl << flush;
  }
  os << ")" << flush;
  return os;
}






