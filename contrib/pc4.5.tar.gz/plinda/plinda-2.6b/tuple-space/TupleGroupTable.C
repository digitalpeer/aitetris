
/*---------------------------------------------------------------------------

                              TupleGroupTable.C

 --------------------------------------------------------------------------*/

#include <stream.h>
#include <assert.h>
#include <unistd.h>


#include "TupleGroup.h"
#include "physid.Pix.CHMap.h"

#include "TupleGroupTable.h"

/*__________________________________________________________________________*/

TupleGroup* 
TupleGroupTable::open(const gid& g) {
    TupleGroup*  cur;

    if (g==zero_gid) return 0;
    cur = opened_groups[g];
    if (cur==0){
	cur = new TupleGroup;
	cur->update_group_id(g);
	cur->open_group();
	opened_groups[g] = cur;
    }
    return cur;

}
/*__________________________________________________________________________*/

int 
TupleGroupTable::close(const gid& g) {
    TupleGroup*  cur;

    if (g==zero_gid) return 0;
    cur = opened_groups[g];
    if (cur==0) return 0;
    if ((cur->refcount()) >1) {
	cerr << "group being referred to by others. cannot shutown\n";
	return 0;
    }
    cur->shut_down_group();
    delete cur;
    opened_groups[g] = 0;

    return 1;
}
 
/*__________________________________________________________________________*/

TupleGroup* 
TupleGroupTable::create_group(char transient_flag,char store_type,
					  const gid& g = zero_gid){
    TupleGroup*  cur;
    
    if(g == zero_gid){
	cur = new TupleGroup;
	opened_groups[++system_next_gid] = cur;
	cur->update_group_id(system_next_gid);
	cur->update_store_type(store_type);
	cur->update_life_time(transient_flag);
	cur->init_group();
    }
    else {
	cur = open(g);
    }

    return cur;
  
}
/*__________________________________________________________________________*/

TupleGroup* 
TupleGroupTable::link(const gid& g) {

    TupleGroup* cur;

    cur = opened_groups[g];
    if(cur == 0) return 0; //this group is not yet opened.
    else  cur->incr_refcount();

    return cur;
}

void 
TupleGroupTable::unlink(const gid& g) {
    TupleGroup*  cur;

    cur = opened_groups[g];
    assert(cur!=0);
    cur->decr_refcount();
    if(cur->refcount() == 0) { 
	// no client is refering to this group
	cur->shut_down_group();
	delete cur;
	opened_groups[g] = 0;
    }
}    
/*__________________________________________________________________________*/
void 
TupleGroupTable::print() const {
    
    TupleGroup* cur;
}
/*__________________________________________________________________________*/




