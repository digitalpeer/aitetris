
#ifndef _gidTupleGroupMap_H_
#define _gidTupleGroupMap_H_ 1

#include "gid.TupleGroupP.CHMap.h"

typedef gidTupleGroupPCHMap  gidTupleGroupMap;

#endif  // _gidTupleGroupMap_H_
