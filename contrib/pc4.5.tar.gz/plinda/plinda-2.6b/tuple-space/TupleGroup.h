

#ifndef _TupleGroup_H_
#define _TupleGroup_H_  1


#include <Pix.h>
#ifdef __GNUG__
#include <fstream.h>
#include "Machine.h"
#endif
#include "plinda_ids.h"

#include "RequestNode.h"
#include "TupleHandle.h"
#include "Pattern.h"
#include "PatternNode.h"

#include "physid.TuplePtr.CHMap.h"
#include "Process.h"

#include "TupleHandleIterator.h"
#include "TupleIterator.h"
#include "CheckPoint.h"
#include "ErrorType.h"


class Transaction;
class Tuple;


/*--------------------------TupleGroup----------------------------------*/

class TupleGroup {
  
  public:

    TupleGroup();
    TupleGroup(int  gtyp, int styp);
    ~TupleGroup();

    const gid& get_grpid(void) { return group_id; }

    static const gid& get_last_gid(void) { return system_next_gid; }
    static const gid& get_next_gid(void) { return ++system_next_gid; }
    static void set_last_gid(const gid& lgid) { system_next_gid = lgid; }

    static const physid& get_last_physid(void) { return system_next_physid; }
    static const physid& get_next_physid(void) { return ++system_next_physid; }
    static void  set_last_physid(const physid& lph) { system_next_physid = lph; }
    ErrorType insert_tuple(TupleHandle& tuple_handle,Tuple* incoming, 
			   const physid& ph = zero_physid);
    ErrorType retrieve_tuple(TupleHandle& tuple_handle, Tuple *wantIt,
			     Tuple::OpType opType,
			     const physid& ph= zero_physid);

    // creation and destruction in a transactional manner;
    void commit_creation(void);
    void abort_creation(void);
    void commit_destruction(void);
    void abort_destruction(void);

    // tuple space access request handling ;
    Tuple *delete_tuple(const physid&);
    Pix       block_request(Process*, Transaction*, Tuple*, Tuple::OpType);
    void      delete_blocked_request(Process*, Pix);
    int       release_blocked_requests(TupleHandle& t);
 
    // methods for tuplegroup checkpointing;
    ErrorType  checkpoint_group(void);
    ErrorType  load_checkpoint(void);
    void       largest_tuple_size(int);    // Karp: largest tuple 
    int        largest_tuple_size(void);    // Karp: largest tuple 

    void       incr_refcount();
    void       decr_refcount();
    physid     reserve_physid(int n);

    // used to cycle through all the tuples of a tuple group;
    void       iterator(TupleHandleIterator&);
    void       iterator(TupleIterator&);
    
    // used in TupleGroupTable -- should be removed later on..;
    void  shut_down_group(){}
    void  init_group(){}
    void  update_group_id(const gid& g){ group_id = g; }
    void  update_store_type(int s){ store_type = s; }
    void  update_life_time(int l){ transient_flag = l; }
    int   refcount(){ return ref_count; }
    void  open_group(){}
    void  group_name(const char* name);
    const char* group_name(void) const { return grp_name; }
    
    // for debugging purposes...;
    ErrorType  dump(ofstream&) ;
    long  num_tuples(void);
    long  memory_used(void) ;


  private:

    static 	gid    	system_next_gid;
    static 	physid  system_next_physid;

    char*      grp_name;            // name for this group.
    gid        group_id;
    int        store_type;          // storage data str to use(hash/list...);
    int	       largest_tuple_sz;    // Karp: largest tuple size
    int        transient_flag;      // transient/persistent tuple_group;
    int        ref_count;           // # of processs referring this group.;

    physidTuplePtrCHMap     physid_tuple_map;    // for fast access based on physid ;
    PatternNodeList         pattern_list;        // each pattn => 1 pattern ;
    RequestNodeList         blkd_request_list;   // see RequestNode.h for descrn;
    
    Pix  matching_pattern_node(const Pattern &);

};

/*-----------------------------------------------------------------------*/


typedef TupleGroup*  TupleGroupP;


 
#ifndef _OUTLINE_
#include "TupleGroup.iC"
#endif // _OUTLINE_



#endif // _TupleGroup_H_
