
#include "TupleIterator.h"
#include "Storage.h"
#include "Tuple.h"



void
TupleIterator::clear(){
    pos_in_pat_list = 0; pos_in_store_hdr = 0; 
    pattern_list = 0; cur_tuple = 0;
}

/*------------------------------------------------------------------------------*/

Tuple*
TupleIterator::first(void){

    if (pattern_list == 0) 
      return NULL;
    cur_store = NULL;
    pos_in_pat_list = pattern_list->first();
    do {
      if (pos_in_pat_list == 0 ) 
	return NULL;
      cur_store = (*pattern_list)(pos_in_pat_list)->store();
      if(cur_store->first() == 0) {
	pattern_list->next(pos_in_pat_list);
	cur_store = NULL;
      }
    } while(cur_store == NULL);
    pos_in_store_hdr = cur_store->first();
    assert(pos_in_store_hdr);
    cur_tuple = cur_store->contents(pos_in_store_hdr);
    return cur_tuple;

}
/*------------------------------------------------------------------------------*/
Tuple*
TupleIterator::next(void){

    Tuple* next_tuple;
    
    if ((pattern_list==0) || (cur_tuple==0)) return (Tuple*)0;
    
    next_tuple = cur_tuple->next();
    assert(cur_store);
    assert(pos_in_store_hdr);
    if (next_tuple == (cur_store->contents(pos_in_store_hdr))){
	/* next tuple is same as first one with in the list
	   of tuples with same key */
	/* go to next in store hdr (go to next key list)*/
	cur_store->next(pos_in_store_hdr);
	if (pos_in_store_hdr == 0){
	    /* no more diff. keys */
	    /* go to next store */
	  pattern_list->next(pos_in_pat_list);
	  do {
	    if (pos_in_pat_list==0) 
	      return cur_tuple = NULL;
	    cur_store = (*pattern_list)(pos_in_pat_list)->store();
	    if(cur_store->first() == 0) {
	      pattern_list->next(pos_in_pat_list);
	      cur_store = NULL;
	    }
	  } while(cur_store == NULL);
	  /* next store */
	  //	  cur_store = (*pattern_list)(pos_in_pat_list)->store();
	  /* first list in the store */
	  pos_in_store_hdr = cur_store->first();
	    /* first tuple in the store */
	  assert(pos_in_store_hdr);
	  cur_tuple = cur_store->contents(pos_in_store_hdr);
	  return cur_tuple;
	}
	/* next list of tuples with a diff key */
	cur_tuple = cur_store->contents(pos_in_store_hdr);
	return cur_tuple;
    }
    cur_tuple = next_tuple;
    return cur_tuple;

}
/*------------------------------------------------------------------------------*/







