#ifndef _Tuple_H_
#define _Tuple_H_ 1

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stream.h>
#include <DLList.h>
#include <fstream.h>

#include "plinda_ids.h"
#include "TupleSpaceConfig.h"
#include "Key.h"
#include "String.h"
#include "TupleField.h"
#include "Pattern.h"
#include "Header.h"


class Tuple;

class ExtraTupleInfo {
  friend class Tuple;
  char readers_;  // when a rd or an in access the tuple
  char inned_;
  physid p;
  Tuple *next_;
  Tuple *prev_;
  char numFieldsInitialized;
  unsigned nextArrayLocation;

  ExtraTupleInfo() {
    p = zero_physid;
    next_ = prev_ = NULL;
    readers_ = inned_ = 0;
    numFieldsInitialized = 0;
    nextArrayLocation = 0;
  }

};

class Tuple {
 public:
   void setHeader(const Header &h) { ___header = h; }
   // only called by ComLink::send_message
   friend ostream& operator<<(ostream& os, const Tuple& T);   
   static void reverseEndian(Tuple *t,int isMyEndianNow);
 public:
   gid group() const { return myGroup; }
   void group(const gid &g) { myGroup = g; }

   // for actuals
   
   void setActual(const int fieldNum,const TupleField::BasicTypes bt, 
		  const int x);
   void setActual(const int fieldNum, const TupleField::BasicTypes bt, 
		  const char x);
   void setActual(const int fieldNum,const TupleField::BasicTypes bt, 
		  const gid x);
   void setActual(const int fieldNum, const TupleField::BasicTypes bt, 
		  const long x);
   void setActual(const int fieldNum, const TupleField::BasicTypes bt, 
		  const physid x);
   void setActual(const int fieldNum,const TupleField::BasicTypes bt, 
		  const float x);
   void setActual(const int fieldNum,const TupleField::BasicTypes bt, 
		  const double x);
   void setActual(const int fieldNum, const TupleField::BasicTypes bt, 
		  const void *x,const int structSize);

   // for array actuals
   void setActual(const int fieldNum,const TupleField::BasicTypes bt,
		  const int *x,const int howMany);
   void setActual(const int fieldNum,const TupleField::BasicTypes bt,
		  const char *x,const int howMany);
   void setActual(const int fieldNum,const TupleField::BasicTypes bt,
		  const gid *x, const int howMany);
   void setActual(int fieldNum,const TupleField::BasicTypes bt,const long *x,
		  const int howMany);
   void setActual(const int fieldNum,const TupleField::BasicTypes bt,
		  const float *x, const int howMany);
   void setActual(const int fieldNum,const TupleField::BasicTypes bt,
		  const double *x,const int howMany);
   void setActual(const int fieldNum,const TupleField::BasicTypes bt,
		  const void *x,const int structSize,const int howMany);


   // for formals
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt, int *x);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,char *x);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,gid *x);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,long *x);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,
		  physid *x);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,float *x);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,
		  double *x);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt, void *x,
		  const int structSize);

   // for array formals
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,int *x,
		  const int howMany);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,gid *x,
		  const int howMany);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,long *x,
		  const int howMany);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,char *x,
		  const int howMany);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,float *x,
		  const int howMany);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,double *x,
		  const int howMany);
   void setFormal(const int fieldNum,const TupleField::BasicTypes bt,void *x,
		  const int structSize,const int howMany);


   // Note, there are no set functions for arrays of physid since only the
   // kernel uses physids in tuples and it doesn't need arrays.

   // the read functions are used by the PLinda kernel for when it
   // needs to read fields of system tuples
   void read(const int fieldNum, TupleField::BasicTypes, int &x) const ;
   void read(const int fieldNum, const TupleField::BasicTypes,char &x) const ;
   void read(const int fieldNum, const TupleField::BasicTypes,long &x) const ;
   void read(const int fieldNum, const TupleField::BasicTypes,gid &x) const ;
   void read(const int fieldNum, const TupleField::BasicTypes,physid &x) const;

   void read(const int fieldNum, const TupleField::BasicTypes,int *x,
	     const int maxLength)const ;
   void read(const int fieldNum, const TupleField::BasicTypes,char *x,
	     const int maxLength)const;
   // the above are used to fill up exieting memory.
   //  ones below will do a new themselves.
   void read(const int fieldNum, const TupleField::BasicTypes,int *&x)const;
   void read(const int fieldNum, const TupleField::BasicTypes,char *&x)const;
   char valid() const;

   int readLength(const int fieldNum) const{ 
      assert(valid());
      return fields(fieldNum).totalSize ;
   }
   String printit() const { return "Tuple"; }

   enum OpType { IN, RD, OUT, EVAL, XCOMMIT } ;
   OpType opType() const { return (OpType)myOpType; }
   void opType(OpType o) { myOpType = (char)o; }
 public:
   bool allActuals() const;
   void dump(ofstream &ds) { assert(0); ds << "Tuple"; }
   Key key() const ;
   Tuple() {}
   ~Tuple() { assert(0);}   // should be calling Tuple::destroy
   bool operator!=(const Tuple &other) const;
   int length() const { return totLength;  }
   bool operator==(const Tuple &other) const ;
   static Tuple *create(unsigned numFields, unsigned totArrayLength) ;
   static Tuple *copy(Tuple *) ;
   static void destroy(Tuple *t) {
     assert(t->eti);
     delete t->eti;
      char *junk = (char*)t;
      delete[] junk;
   }
   void updatePointers();
   void bindFormals(Tuple &other);
   void incrementReaders() { assert(eti); eti->readers_++; }
   void decrementReaders() { assert(eti); eti->readers_--; }
   char readers() const { assert(eti); return eti->readers_; }
   void setInned() { assert(eti); eti->inned_ = 1; }
   void unsetInned() { assert(eti); eti->inned_ = 0; }
   char inned() const { assert(eti); return eti->inned_; }
   int numOfFields() const { return numFields; } 
    // used by MonitorProcess to make sure tuple is valid
   const Pattern pattern();
   char *innerTuples() {
      // called by ClientProcess::enqeue_request to get a pointer
      // into the third field which is flattened tuples.
      assert(numOfFields() == 3);
      assert(fields(0).myBasicType == TupleField::PLint &&
	     fields(0).isArray == false && fields(0).isActual());
      assert(fields(1).myBasicType == TupleField::PLint &&
	     fields(1).isArray == true && fields(1).isActual());
      assert(fields(2).myBasicType == TupleField::PLchar &&
	     fields(2).isArray == true && fields(2).isActual());
      return (char*)fields(2).data.array;
   }

  physid identifier()const { assert(eti); return eti->p; }
  void identifier(const physid& ph){ assert(eti); eti->p = ph; }
  Tuple*  next(void){ assert(eti); return eti->next_; }
  Tuple*  prev(void){ assert(eti); return eti->prev_; }
  void    next(Tuple * t){ assert(eti); eti->next_ = t; }
  void    prev(Tuple * t){ assert(eti); eti->prev_ = t; }
 private:
   void *allocateArray(unsigned size);
   TupleField &fields(char index) const {
      assert(index < numFields);
#ifndef alpha
      TupleField *mine = (TupleField*)((int)this + sizeof(Tuple));
#else
      TupleField *mine = (TupleField*)((long)this + sizeof(Tuple));
#endif
      return mine[index];
   }
 private:
  Header ___header;
  char myOpType;
  char numFields;
  Pattern patternType;
  unsigned totLength;
  gid myGroup;
  ExtraTupleInfo *eti;
#ifndef alpha
  void *ExtraTupleInfoPadding;
#endif
};




typedef   Tuple*   TupleList;
typedef   Tuple*   TuplePtr;


#ifndef _OUTLINE_
#include "Tuple.iC"
#endif // _OUTLINE_

#endif	
