


#include "PatternNode.h"
#include "ChainedHash.h"
#include "AVLTree.h"
#include "SplayTree.h"
//#include "ListStore.h" This file is broken see the plinda-2.1b files
// for a copy of this code


#ifdef _OUTLINE_
#define inline
#include "PatternNode.iC"
#endif

unsigned int pnodehash(PatternNode* p){ return p->num_tuples(); }
 
PatternNode::PatternNode(const Pattern &pa, int number_tuples, 
			 int store_type, int key_fld){

  Tuple* t = 0;

  pattern_ = pa; 
  switch (store_type){
  case PL_CHAINED_HASH_STORE: 
    store_ = new ChainedHash(t, PL_DEFAULT_STORE_SZ);
    break;
  case PL_AVL_TREE_STORE: 
    store_ = new AVLTree(t);
    break;
  case PL_SPLAY_TREE_STORE:  
    store_ = new SplayTree(t);
    break;
  case PL_LIST_STORE:  
    cerr << "List store is not currently supported\n" << flush;
    assert(0);
//    store_ = new ListStore;
//    break; 
  default : 
    break;
  }
  key_fld_ = key_fld;
  num_tuples_ = number_tuples;
  store_type_ = store_type;
//  modified_ = PL_FALSE;  
  mem_used_ = 0;
}


/*-----------------------------------------------------------------*/
String
PatternNode::print(void) {

    String S;
    
//    S = (String)(pattern_); Peter fix this
    S += " StoreType = ";
    S += dec(store_type_);
    S += " NumTuples = " ;
    S += dec(num_tuples_);
    return S;
}
/*-----------------------------------------------------------------*/
ErrorType
PatternNode::dump(ofstream& ds){
  /* format of dump --
     pattern
     store_type num_tuples mem_used
     Tuples :
        -
	-
	*/
  ds << "##################################################\n";
  ds << "Pattern = " <<  pattern_ ; 
  ds  << "\n" << flush;

  switch (store_type_){
  case PL_CHAINED_HASH_STORE: 
    ds << "Store type = Chained Hash Table.\n" << flush;
    break;
  case PL_AVL_TREE_STORE: 
  case PL_SPLAY_TREE_STORE:  
    ds << "Store type = Balanced Tree.\n" << flush;
    break;
  case PL_LIST_STORE:  
    ds << "Store type = Linked List.\n" << flush;
    break; 
  default : 
    ds <<  "Store type = ??.\n" << flush;
    break;
  }
  ds << "Num tuples = " << num_tuples_ << 
    "   Mem used = " << mem_used_ << "\n";
  ds << "------------------ Tuples -----------------------\n" ;

  if (num_tuples_==0) return NO_ERROR;

  {
    Tuple* t; 
    Key first_k, k = -1;
    
    first_key(k);
    first_k = k;
    while(1){
      first_match(k,t);
      if (t!=0) 
	t->dump(ds);
      ds << "\n\n" << flush;
      while(t!=0){
	next_match(t);
	if (t!=0) t->dump(ds); ds << "\n\n" << flush;
      }
      next_key(k);
      if (k==first_k || k==-1) break;
    }
  }
  ds << "-----------------------------------------------\n" << flush;
  return NO_ERROR;

}
/*-----------------------------------------------------------------*/
