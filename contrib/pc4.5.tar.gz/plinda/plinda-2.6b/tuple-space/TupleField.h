#ifndef _TupleField_H_
#define _TupleField_H_ 1

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stream.h>
#include "plinda_ids.h"
#include "TupleSpaceConfig.h"
#include <fstream.h>
#include "Machine.h"

class Tuple;

// This is the class of the Fields of a Tuple, almost all of it is
// private since Tuple class will do all the manipulation of these
// fields.

class TupleField {
   friend ostream& operator<<(ostream& os, const TupleField& t) ;
   friend ostream& operator<<(ostream& os, const Tuple& t);
   friend class Tuple;
 public:
   static void *reverseEndian(TupleField&,int isMyEndianNow,void *nextArrayLoc);
   enum BasicTypes { PLint = 0 , PLchar = 1, PLgid  =2 , PLlong = 3, 
		       PLphysid = 4, PLfloat = 5, PLdouble= 6, PLstruct = 7 };
 private:
   TupleField(): valid(0) { }
   bool isFormal() const { assert(valid); return isAFormal; }
   bool isActual() const { return !isFormal(); }
   bool operator==(const TupleField &other) const ;
   bool operator!=(const TupleField &other) const ;
   void pattern(unsigned char &patField,int lowerOrUpper) const;
   void bindFormals(TupleField &other) ;
   void initialize(BasicTypes bt, bool isA, int howMany = 1);
   void initializeStruct(bool isA,int structSize,int howMany=1);

 private:
   union BasicData{
      long Long;
      physid PhysId;
      gid Gid;
      int Int;
      float Float;
      double Double;
      char Char;
      void *array;
   } data;
   char myBasicType;
   char isArray;
   char valid;
   char isAFormal;
   unsigned totalSize; // size of basic type * numElements
   // Do not change this things data unless you are very careful, all
   // the fields must have correct alignment.
};


#ifndef _OUTLINE_
#include "TupleField.iC"
#endif // _OUTLINE_

#endif

