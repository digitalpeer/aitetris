
#ifndef _PatternNode_H_
#define _PatternNode_H_ 1

#include <fstream.h>
#include <Pix.h>
#include <DLList.h>
//#include "pl_string.h"
#include "String.h"
#include "TupleSpaceConfig.h"
#include "plinda_ids.h"
#include "ErrorType.h"
#include "Key.h"
#include "Pattern.h"


class Storage;
class Tuple;


class PatternNode {
  
public:


  PatternNode(const Pattern &pa,int num_tuples, int store_type, int key_fld=0);
  
  ~PatternNode();

  void clear()  ;
  String  print(void);
  ErrorType dump(ofstream&);

  Storage*  store() const { return store_; }
  const Pattern  &pattern() const { return pattern_; }
  int       num_tuples() const { return num_tuples_; }
  void      num_tuples(int num) { num_tuples_ = num; }
  long      mem_used(void) const { return mem_used_; }
//  int       changed() const { return modified_; }
//  void      mark_changed(){ modified_ = PL_TRUE; }
//  void      mark_unchanged(){ modified_ = PL_FALSE; }

  /* functions for actual insertion and deletion of tuples */
  Tuple*   add_tuple(Tuple* t, Key k);
  Tuple*   del_tuple(Tuple* t, Key key);


  /* searching for tuples with matching keys. */
  /* return pointers fro tuples with the key specified */
  Tuple*   first_match(Key &key, Tuple* (&t));
  Tuple*   next_match(Tuple* (&t));
  void     first_key(Key& k) const;
  void     next_key(Key& k) const;

private:
  Pattern pattern_;
  Storage*  store_;
  int       store_type_;
  int       num_tuples_;
  long      mem_used_;
  int       key_fld_;
//  int       modified_;   /* set when tuple added/deleted. 
//			    reset when blkd_reqs released */
  
};

typedef PatternNode*    PatternNodePtr;
typedef DLList<PatternNode*> PatternNodeList;

extern unsigned int pnodehash(PatternNode* p);

 
#ifndef _OUTLINE_
#include "PatternNode.iC"
#endif // _OUTLINE_


#endif  // _PatternNode_H_

     
