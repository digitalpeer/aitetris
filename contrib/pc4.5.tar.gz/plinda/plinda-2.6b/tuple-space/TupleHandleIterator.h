
#ifndef _TupleHandleIterator_h_
#define _TupleHandleIterator_h_

#include <Pix.h>
#include "TupleHandle.h"
#include "PatternNode.h"
#include "Storage.h"

class TupleGroup;

class TupleHandleIterator {

  public:
    
    TupleHandleIterator(){ clear(); }
    ~TupleHandleIterator(){ clear(); }

    void    clear();
    void    init(TupleGroup*, PatternNodeList*);
    void    first(TupleHandle&);
    void    next(TupleHandle&);


  private:

    /* should be able to load tuple_pix, pat_pix, tup_grp and key
       into the handle */

    Pix               pos_in_pat_list;
    Pix               pos_in_store_hdr;
    Key               cur_key;
    Storage*          cur_store;
    Tuple*            cur_tuple;
    TupleGroup*       tup_grp;
    PatternNodeList*  pattern_list;


};


#endif   /* _TupleHandleIterator_h_ */
