
#ifndef _ChainedHash_H_
#define _ChainedHash_H_ 1

#include "int.TupleList.CHMap.h"
#include "Storage.h"

class ChainedHash : public Storage {
  
 public:
  
  ChainedHash(TupleList& dflt,unsigned int sz = DEFAULT_INITIAL_CAPACITY) :
    chtable(dflt,sz) {}
  //  ~ChainedHash(){ chtable.~intTupleListCHMap(); }

  TupleList&  operator [] (int key){ return (chtable.operator[](key)); }
  void        del(int key){ chtable.del(key); }
  Pix         first(){ return (chtable.first()) ; }
  void        next(Pix& i){ chtable.next(i); }
  int&        key(Pix i){ return (chtable.key(i)) ; }
  TupleList&  contents(Pix i){ return (chtable.contents(i)); }
  Pix         seek(int key){ return (chtable.seek(key)); }
  int         contains(int key){ return (chtable.contains(key)); }
  void        clear(){ chtable.clear(); }
  int         OK(){ return (chtable.OK()); }
  void        destroy(){ chtable.~intTupleListCHMap(); }

 private:
  intTupleListCHMap  chtable;

};

#endif   // _ChainedHash_H_




