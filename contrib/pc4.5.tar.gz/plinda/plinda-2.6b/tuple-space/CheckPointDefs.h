
#ifndef _CheckPointDefs_H_
#define _CheckPointDefs_H_

#include "ErrorType.h"

#define WRITE_CHKPT               2
#define READ_CHKPT                4
#define LEFT_DIR                  8
#define RIGHT_DIR                 16
#define PL_DEFAULT_CHKPT_BUFSZ    5120


#include <sys/file.h>

#include "C_Interface.h"

#endif  // _CheckPointDefs_H_
