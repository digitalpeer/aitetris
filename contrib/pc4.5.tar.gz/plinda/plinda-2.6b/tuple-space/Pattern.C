#include "Pattern.h"

ostream &operator<<(ostream &os, const Pattern &pa) {
   for(int i = 0 ; i < MAXTUPLEFIELDSDIV2; i++)
     os << pa.pat[i];
   return os;
}
