
#ifndef _RequestNode_H_
#define _RequestNode_H_ 1

#include "plinda_ids.h"
#include <DLList.h>
#include "Tuple.h"


class Process;
class Transaction;

 /* all blocked requests are stored in the format below :
    when a tuple space request is made, the parameters of
    the query are : the transaction to which the request 
    belongs, the process which invoked the request (so that
    later when the request can be satisfied, that process
    can be notified), the io_pattern which describes the 
    tuple which should match, the lock which specifies how the
    tuple is to be allowed to be accessed by others. */

typedef struct request_node {

   Process*              process;
   Transaction*          transaction;
   Tuple*                wantIt;
 Tuple::OpType   opType;
   // physid       ph_id;

} RequestNode;

typedef DLList<RequestNode> RequestNodeList;

#endif  // _RequestNode_H_
