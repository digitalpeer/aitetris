
//#include <io.h>
#include <fstream.h>
#include <fcntl.h>

#include "C_Interface.h"
#include "ErrorType.h"
#include "Transaction.h"
#include "TupleGroup.h"

#include "Tuple.h"
#include "Storage.h"
#include "Process.h"

#include "TupleHandle.h"
#include "ObjectSpace.h"

#include <assert.h>

#define PL_TRANSIENT  1

#ifdef _OUTLINE_
#define inline
#include "TupleGroup.iC"
#endif

/*--------------------------TupleGroup----------------------------------*/

gid	TupleGroup::system_next_gid;
physid	TupleGroup::system_next_physid;

TupleGroup::TupleGroup() : physid_tuple_map((Tuple*)0,
					    PL_DEFAULT_HASHTAB_SZ){
    transient_flag = PL_TRANSIENT;
    store_type     = PL_DEFAULT_STORE;
    group_id       = zero_gid;
    largest_tuple_sz = 0;
    ref_count      = 0;
    grp_name       = 0;
}

TupleGroup::TupleGroup(int group_type, int st_typ)
: physid_tuple_map((Tuple*)0,PL_DEFAULT_HASHTAB_SZ) {
    transient_flag = group_type;
    store_type     = st_typ;
    group_id       = zero_gid;
    largest_tuple_sz = 0;
    ref_count      = 0;
    grp_name       = 0;
}

TupleGroup::~TupleGroup(){
    physid_tuple_map.clear();
    if (grp_name != 0) delete [] grp_name;
}

/*---------------------------------------------------------------------
  delete a tuple given the tuple identifier
  ----------------------------------------------------------------------*/
Tuple *TupleGroup::delete_tuple(const physid& ph)
{

    Tuple*       tuple;
    Pix          pat_pix;

    PatternNode* pnode;
#ifndef NDEBUG
    if (ph == zero_physid || (ph >system_next_physid)) 	{
       cerr << "PLinda Internal error: deleting tuple with zero physid\n" << flush;
       return NULL;
    }
#endif
    tuple = physid_tuple_map[ph];
#ifndef NDEBUG
    if (tuple==0)  {
       cerr << "PLinda internal error: in delete tuplethe physid map didn't have the tuple\n" << flush;
      return NULL;
    }
#endif
    // get tuple identifier and delete entry from physid_tuple_map;
    physid_tuple_map.del(ph);

    const Pattern pat = tuple->pattern();
    pat_pix = matching_pattern_node(pat);

#ifndef NDEBUG
    if (pat_pix==0)  {
       cerr << "PLinda internal error: got an empty pattern in delete tuple\n" << flush;
      return NULL;
    }
#endif
    // delete tuple from the data structure ;
    pnode = pattern_list(pat_pix);
    pnode->del_tuple(tuple, tuple->key());

#ifdef DONT_KEEP_PATTERNS
    // if there are no more tuples in the pattern nodes store ;
    // destroy it. ;
    // But this is stupid since we may want it right away
    if (pnode->num_tuples()==0){
	pnode->clear();
	pattern_list.del(pat_pix);
	delete pnode;
    }
#endif
    /* leave the job of actually destroying the tuple to the caller*/
    /* this way we just removed the tuple from the tuple group and */
    /* not actually destroyed it. The caller might decide to do    */
    /* something with the tuple */

    return tuple;
}

// tuple access methods : new version;
/*---------------------------------------------------------------------*/
ErrorType 
TupleGroup::insert_tuple(TupleHandle& tuple_handle, 
			 Tuple* incoming, 
			 const physid& ph){
    Pix           pat_node_pix;
    PatternNode  *tmp_pat_node;
    Key           key;

    /* if a pid is specified then this must be less than the greatest;
       physid the server knows about. */
#ifndef NDEBUG
    if(ph != zero_physid && ph > system_next_physid)
	return E_INV_PHYSID;
#endif
    // locate the pattern which matches the one in incoming IO_pattern;
    pat_node_pix = matching_pattern_node(incoming->pattern());
    
    if (pat_node_pix==0){   
	/* pattern which matches with io's pattern not present  */
	/* the second parameter to the patternNode constructor is */
	/* the number of tuples (which should be zero) */
	tmp_pat_node = new PatternNode(incoming->pattern(), 0, store_type,0); 
	pat_node_pix = pattern_list.append(tmp_pat_node);
    }
    else{
	tmp_pat_node = pattern_list(pat_node_pix);
    }

    /* generate a new physical_id if the one specified is zero */
    physid phys = (ph == zero_physid) ? ++system_next_physid : ph;

    /* construct a tuple from the IO_pattern */

    key = incoming->key();

    /* insert tuple into the pattern_node found above..*/
    tmp_pat_node->add_tuple(incoming,key);

    /* update the size of the largest tuple */
    largest_tuple_size(incoming->length());

    /* create a handle to the tuple */
    tuple_handle.set(this, incoming);

    /* update the physid_tuple_map table..; */
    physid_tuple_map[phys] = incoming;

    incoming->identifier(phys);
    release_blocked_requests(tuple_handle);

    return NO_ERROR;
}

ErrorType
TupleGroup::retrieve_tuple(TupleHandle& tuple_handle, Tuple *wantIt,
			   Tuple::OpType opType,  const physid& ph){
   Pix           pat_node_pix;
   PatternNode  *tmp_pat_node;
   Key           key;
   int           exhaustive = 0;  /* default is no exhaustive search*/
   Tuple *tuple;

   assert(opType == Tuple::IN || opType == Tuple::RD);

   if (ph != zero_physid) {
#ifndef NDEBUG
     if(ph > system_next_physid) {
	cout << "PLINDA internal error\n" <<
	  "Bad physid given to retrieve tuple\n" << flush;
	return E_INV_PHYSID;
     }
#endif
     tuple = physid_tuple_map[ph];
     if (tuple) {
	if(wantIt)
	  if(*tuple != *wantIt) {
	     // this is in the case of arg_rdp with bad matching patterns
	     tuple_handle.clear();	     
	     return NO_ERROR;
	  }
	tuple_handle.set(this, tuple);
	//	 trans->access_tuple(this, tuple_handle,opType);
	return NO_ERROR;
     } else{
	tuple_handle.clear();
	cout << "PLinda WARNING: retrieved tuple with physid but not here\n" << flush;
	return NO_ERROR;
     }
  } 
   assert(wantIt);
   pat_node_pix = matching_pattern_node(wantIt->pattern());

   if (pat_node_pix == 0) {
      tuple_handle.clear();
      return NO_ERROR;
   }
   tmp_pat_node = pattern_list(pat_node_pix);
   //   if(tmp_pat_node->num_tuples() == 0) {
   //      tuple_handle.clear();
   //      return NO_ERROR;
   //   }
   key = wantIt->key();
   /* if the key field is formal, cycle thru all tuples in store */
   if (key==-1) exhaustive = 1;
   
   /* if it is an exhaustive search, then we cycle thru all tuples
      of each possible key until a match is found */

   if (exhaustive) tmp_pat_node->first_key(key);
   if (key<0) {
      tuple_handle.clear();
      return NO_ERROR;
   }
   tmp_pat_node->first_match(key, tuple);
   if (tuple==0) {
      if (exhaustive){
	 while (1){
	    tmp_pat_node->next_key(key);
	    if (key<0) {
	       tuple_handle.clear();
	       return NO_ERROR;
	    }
	    tmp_pat_node->first_match(key, tuple);
	    if (tuple!=0) break;
	 }
      }
      else {
	 tuple_handle.clear();
	 return NO_ERROR;
      }
   }

   assert(tuple && wantIt);
   while(1){
      if (*tuple == *wantIt) {
	 tuple_handle.set(this, tuple);
//	 trans->access_tuple(this, tuple_handle,opType);
	 return NO_ERROR;
      }
      tmp_pat_node->next_match(tuple);
      if (tuple==0) {
	 if (exhaustive){
	    while (1){
	       tmp_pat_node->next_key(key);
	       if (key<0) {
		  tuple_handle.clear();
		  return NO_ERROR;
	       }
	       tmp_pat_node->first_match(key, tuple);
	       if (tuple!=0) break;
	    }
	 }
	 else {
	    tuple_handle.clear();
	    return NO_ERROR;
	 }
      }
   }
   return NO_ERROR;
}

void TupleGroup::commit_creation(){}

void TupleGroup::abort_creation(){}
    
void TupleGroup::commit_destruction()
{
  ObjectSpace::group_mgr.remove_group(this);
}
    
void TupleGroup::abort_destruction(){}

/*---------------------------------------------------------------------*/    

// tuple space access request handling ;
Pix   
TupleGroup::block_request(Process *p, Transaction* t, Tuple *wantIt,			  Tuple::OpType opType){
    RequestNode rnode;
    
    rnode.process = p;
    rnode.transaction = t;
    rnode.wantIt  = wantIt;
    rnode.opType = opType;
    return  (blkd_request_list.append(rnode));
 
}

void
TupleGroup::delete_blocked_request(Process* p, Pix cur) {
  RequestNode req = blkd_request_list(cur);
  assert(req.process->identifier() == p->identifier());
  
  blkd_request_list.del(cur);
}
    
  
/*---------------------------------------------------------------------*/    

int   
TupleGroup::release_blocked_requests(TupleHandle& tuple_handle)
{

  Tuple* tuple_ptr; 
  Pix p;
  RequestNode req;
    
  Pix dels[100];
  int index = 0;

    tuple_ptr = tuple_handle.tuple();

    for(p = blkd_request_list.first(); p!=0; blkd_request_list.next(p)){
	req = blkd_request_list(p);
	if(*tuple_ptr == *req.wantIt) {
	   assert(tuple_handle.valid());
	   req.transaction->access_tuple(this, tuple_handle, req.opType);
	   (req.process)->resume(this, tuple_handle, req.wantIt);
	  assert(index < 100);
	  dels[index++] = p;
	  if(req.opType == Tuple::IN)  
	    break; // the transaction removed this tuple from tuple space
	}
      }
  for(int i = 0 ; i < index ; i++)
    blkd_request_list.del(dels[i]);      

  return 1;
  }
 
/*---------------------------------------------------------------------*/    
// methods for tuplegroup checkpointing;

ErrorType
TupleGroup::checkpoint_group(void)
{



   TupleIterator  iter;  /*to cycle thru the tuples */


   ErrorType temp;

   CheckPoint  chkpt(group_id);

   temp = chkpt.open(WRITE_CHKPT);
   if(temp.fail())
     return temp;

   iterator(iter);   
//   cout << "About to iterate through all the tuples in here\n" << flush;
   for(Tuple *tuple_ptr = iter.first(); tuple_ptr ; tuple_ptr = iter.next()) {
//     cout << "checkpointing " << *tuple_ptr << endl << flush;
     if((temp = chkpt.write(*tuple_ptr)).fail()) {
       cerr << " error in writing a tuple to checkpoint\n";
       return temp;
     }
  }
   temp = chkpt.close();
   return temp;
}
/*---------------------------------------------------------------------*/    
ErrorType TupleGroup::load_checkpoint(void){
    

    ErrorType er;
    CheckPoint  chkpt(group_id);

    er = chkpt.open(READ_CHKPT); 
    if( er.fail() )
      return er;

    TupleHandle temp;
    for(Tuple *t = chkpt.read_tuple(); t ; t = chkpt.read_tuple())  {
       assert(system_next_physid >= t->identifier());
       er = insert_tuple(temp, t, t->identifier());
       if (er.fail())
	 return er;
    }
    er = chkpt.close();
     return er;
}
/*---------------------------------------------------------------------*/    

Pix
TupleGroup::matching_pattern_node(const Pattern & p){
    Pix x;

    for(x = pattern_list.first(); x!=0; pattern_list.next(x)){
	if (pattern_list(x)->pattern() == p) 
 	    return x;
    }
    return (Pix)0;
}
/*---------------------------------------------------------------------*/    
long
TupleGroup::num_tuples(void) {
    long num_tuples=0;
    
    for(Pix x = pattern_list.first(); x!=0; pattern_list.next(x)){
      num_tuples += pattern_list(x)->num_tuples();
    }
    return num_tuples;
}
/*---------------------------------------------------------------------*/    
long
TupleGroup::memory_used(void) {
    long mem=0;
    
    for(Pix x = pattern_list.first(); x!=0; pattern_list.next(x)){
      mem += pattern_list(x)->mem_used();
    }
    return mem;
}

/*-----------------------------------------------------------------------*/
ErrorType
TupleGroup::dump(ofstream& dump_stream) {


    TupleIterator iter;
    Pix 	  p;



    // dump the pattern nodes 
    dump_stream  
      << "/--------------- PATTERN NODES -----------------/\n" 
      << flush;
    for(p = pattern_list.first(); p != 0; pattern_list.next(p)){
	pattern_list(p)->dump(dump_stream) ;
	dump_stream << endl << flush;
    }

    /* dump the blocked requests 
    dump_stream << "\n/--------------- BLOCKED REQS -----------------/\n" << flush;
    for(p = blkd_request_list.first(); p != 0; blkd_request_list.next(p)){
	req = blkd_request_list(p);
	tmp_procid = (procid)((req.process)->identifier()) ;
	dump_stream << "PID = " << tmp_procid << endl << flush;
	dump_stream << "TID = " << ((req.transaction)->identifier()).print() 
	            << endl << flush;
	dump_stream << "LCK = " << (String)(req.lock) << endl << flush;
	dump_stream << "IO_PAT = " << (req.wantIt)->print() << endl << flush;
	dump_stream << "\n________________________________________________\n" 
	            << flush;
    }
    */

    /* initialize the tuple iterator..
    iterator(iter);

    //print all the tuples... 
    dump_stream << "\n/-------------------- TUPLES -----------------/\n" << flush;
    for(t = iter.first(); t != 0; t = iter.next()){
	dump_stream << t->print() << "\n" << flush;
    }
    dump_stream << "\n/--------------------********-----------------/\n" << flush;
    */

    return NO_ERROR;
}
/*-----------------------------------------------------------------------*/   
