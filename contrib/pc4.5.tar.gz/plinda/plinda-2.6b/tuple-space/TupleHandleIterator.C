
#include "TupleHandleIterator.h"
#include "Tuple.h"


void
TupleHandleIterator::clear(){
    pos_in_pat_list = pos_in_store_hdr = 0; cur_tuple = 0;
    pattern_list = 0; tup_grp = 0;
}
void
TupleHandleIterator::init(TupleGroup* g, PatternNodeList* p ){
    pos_in_pat_list = pos_in_store_hdr = 0; cur_tuple = 0;
    pattern_list = p; tup_grp = g;
}

/*------------------------------------------------------------------------------*/
void
TupleHandleIterator::first(TupleHandle& handle){

#if 0
    Tuple *t, *tmp, *another_tmp;
#endif
    handle.clear();
    if ((tup_grp==0) || (pattern_list==0)) return;
    
    pos_in_pat_list = pattern_list->first();
    if (pos_in_pat_list==0) return;
    cur_store = (*pattern_list)(pos_in_pat_list)->store();
    pos_in_store_hdr = cur_store->first();
    cur_tuple = cur_store->contents(pos_in_store_hdr);
    if (cur_tuple==0) return;

    // first tuple;
    cur_key = cur_store->key(pos_in_store_hdr);
    handle.set(tup_grp,cur_tuple);
    return;
}


/*------------------------------------------------------------------------------*/
void
TupleHandleIterator::next(TupleHandle& handle){
    
    Tuple *next_tuple;
    handle.clear();
    if ((pattern_list==0) || (tup_grp==0) || 
	(cur_tuple==0) ||(pos_in_store_hdr==0) ) {
	return;
    }
    assert(cur_tuple);
    assert(cur_store);

    next_tuple = cur_tuple->next();
    
    assert(next_tuple);
    if (next_tuple == (cur_store->contents(pos_in_store_hdr))){
	/* next tuple is same as first one within the list
	   of tuples with same key */
	/* go to next in store hdr (go to next key list)*/
        cur_store->next(pos_in_store_hdr);
	if (pos_in_store_hdr==0){
	    /* no more diff. keys */
	    /* go to next store */
	    pattern_list->next(pos_in_pat_list);
	    if (pos_in_pat_list==0){
		/* no more pattern nodes (stores) */
		/* done with all tuples */
		cur_tuple = (Tuple*)0;
		return;
	    }
	    /* next store */
	    cur_store = (*pattern_list)(pos_in_pat_list)->store();
	    /* first list in the store */
	    pos_in_store_hdr = cur_store->first();
	    /* first tuple in the store */
	    cur_tuple = cur_store->contents(pos_in_store_hdr);
	    cur_key = cur_tuple->key();
	    handle.set(tup_grp, cur_tuple);
	    return;
	}
	/* next list of tuples with a diff key */
	cur_tuple = cur_store->contents(pos_in_store_hdr);
	cur_key = cur_tuple->key();
	handle.set(tup_grp, cur_tuple);
	return;
}
    cur_tuple = next_tuple;
    cur_key = cur_tuple->key();
    handle.set(tup_grp, cur_tuple);
    return;

}   

/*----------------------------------------------------------------------------*/
