
#ifndef _CheckPoint_H_
#define _CheckPoint_H_

#include <stdio.h>
#include "ErrorType.h"
#include "plinda_ids.h"
#include "Pattern.h"
#include "Tuple.h"
#include "CheckPointDefs.h"

class CheckPoint {

  public:
    
    CheckPoint(const gid&);
    ~CheckPoint();

    ErrorType  open(int mode);
    ErrorType  close();
    
    ErrorType write(const Tuple& t);
    ErrorType write(const Tuple& t, const gid &);
    Tuple*    read_tuple();
    Tuple*    read_tuple(gid &);

  private:
    int fd;
    int dirn; // upload or download checkpoint? ;
    int opened_before;
    gid  grp_id;

};


#endif  // _CheckPoint_H_
