
#ifndef _SplayTree_H_
#define _SplayTree_H_ 1

#include "int.TupleList.SplayMap.h"
#include "Storage.h"

class SplayTree : public Storage {

 public:

  SplayTree(TupleList& dflt) : splay_tree(dflt) {}
  // ~SplayTree(){ splay_tree.~intTupleListSplayMap(); }

  TupleList&  operator [] (int key){ return (splay_tree.operator[](key)); }
  void        del(int key){ splay_tree.del(key); }
  Pix         first(){ return (splay_tree.first()) ; }
  void        next(Pix& i){ splay_tree.next(i); }
  int&        key(Pix i){ return (splay_tree.key(i)) ; }
  TupleList&  contents(Pix i){ return (splay_tree.contents(i)); }
  Pix         seek(int key){ return (splay_tree.seek(key)); }
  int         contains(int key){ return (splay_tree.contains(key)); }
  void        clear(){ splay_tree.clear(); }
  int         OK(){ return (splay_tree.OK()); }
  void        destroy(){ splay_tree.~intTupleListSplayMap(); }

 private:
  intTupleListSplayMap  splay_tree;

};

#endif   // _SplayTree_H_




