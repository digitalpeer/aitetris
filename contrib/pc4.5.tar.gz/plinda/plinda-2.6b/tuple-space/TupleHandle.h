#ifndef _TupleHandle_H_
#define _TupleHandle_H_ 1

#include <DLList.h>
#include "Tuple.h"

class TupleGroup;


class TupleHandle {
  public:
    TupleHandle(){ clear(); }
    TupleHandle(TupleGroup* g, Tuple* t ){  set(g,t); }
    TupleHandle(const TupleHandle& hdl) { 
      tup_grp_ = hdl.tup_grp_;
      tuple_ = hdl.tuple_;
    }
    void operator =(const TupleHandle& hdl) {
      tup_grp_ = hdl.tup_grp_;
      tuple_ = hdl.tuple_;
    }
    void   set(TupleGroup* g, Tuple *t) { tup_grp_ = g; tuple_ = t;  }
    void   clear(void) { tup_grp_ = 0; tuple_ = 0; }
    int    valid() const { return tup_grp_ != 0 && tuple_ != 0; }
    physid       identifier(void) const { return tuple_->identifier(); }
    Tuple*       tuple(void) const { return tuple_; }
    TupleGroup*  tuple_group(void) const { return tup_grp_; }
  private:
    TupleGroup*  tup_grp_;
    Tuple*       tuple_;
};

typedef TupleHandle* TupleHandlePtr;
typedef DLList<TupleHandle> TupleHandlesList;
typedef DLList<Tuple*> TuplesList;
#endif  /* _TupleHandle_H_ */
