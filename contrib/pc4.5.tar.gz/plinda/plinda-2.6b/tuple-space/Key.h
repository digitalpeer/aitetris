
#ifndef _Key_H_
#define _Key_H_ 1

#define HASHING_PRIME  3511

typedef  int Key;

inline Key
hash_string(unsigned char *text, int bytes)
{
  register long unsigned int sum = 0;
  register int    i;

  for (i = 0; i < bytes; i++, text++)
    sum += *text;
  sum += i;
  return (sum % HASHING_PRIME);
}


#endif  // _Key_H_
