#include "Tuple.h"

#ifdef _OUTLINE_
#define inline
#include "Tuple.iC"
#endif



static inline void reverse (int &word)
{
  assert(sizeof(int) == 4);
  int x = word;
  swab((char*)&word,((char*)&word)+2,2);
  swab(((char*)&x)+2,(char*)&word,2);
}


static inline void reverse (unsigned &word)
{
  assert(sizeof(int) == 4);
  int x = word;
  swab((char*)&word,((char*)&word)+2,2);
  swab(((char*)&x)+2,(char*)&word,2);
}


void Tuple::reverseEndian(Tuple *t,int isMyEndianNow) 
{
  assert(t);
  if(isMyEndianNow == -1) {
    // this means the tuple is coming from socket and besides
    // not being in my endian format, it needs to have its eti newed
    t->eti = new ExtraTupleInfo();
    assert(t->eti);
    t->eti->numFieldsInitialized = t->numFields;
    isMyEndianNow = 0;
    // above so tuple field::reverse will interpret it correctly
  }
  reverse(t->myGroup.low);
  reverse(t->myGroup.high);
  reverse(t->totLength);
  void *nextArrayLoc = 
    (void*)((long)t + sizeof(Tuple) + t->numFields * sizeof(TupleField));
  for(int i = 0 ; i < t->numFields ; i++) {
    TupleField &tf = t->fields(i);
    nextArrayLoc = TupleField::reverseEndian(tf,isMyEndianNow,nextArrayLoc);
  }
}


Key Tuple::key() const {
   if(fields(0).isFormal())
     return -1;
   Key  k;
   if (fields(0).myBasicType == TupleField::PLchar && 
       fields(0).isArray == true){
      k =  hash_string((unsigned char*)fields(0).data.array, 
		       fields(0).totalSize);
   } else if (fields(0).myBasicType == TupleField::PLint && 
	      fields(0).isArray == false){
      k =  fields(0).data.Int;
      if (k <= 0) 
	k = 1 - k;  // just make it positive
   } else {
      k =  PL_RANDOM_NO;      /* NOW THIS IS WILD...#def const!!*/
   }
   return k;
}
char Tuple::valid() const 
{
  if(!eti)
    return false;
  if(((void*)&___header != (void*)this))
    return false;
  long endOfTuple = (long)this + (long)sizeof(Tuple);
#ifdef alpha  
  if(endOfTuple - (long)sizeof(eti) != (long)&eti)
    return false;
#else
  if(endOfTuple - (long)sizeof(eti) - sizeof(ExtraTupleInfoPadding)!= (long)&eti)
    return false;
#endif
  if(eti->numFieldsInitialized != numFields)
    return false;
  return true;
   
}

Tuple *Tuple::copy(Tuple *c) 
{
  assert(c);
  assert(c->valid());
  char *temp = new char[c->length()];
  assert(temp);
  memcpy(temp,c,c->length());
  Tuple *newTuple = (Tuple*)temp;
  newTuple->updatePointers();
  return newTuple;
}

Tuple *Tuple::create(unsigned numFields, unsigned totArrayLength) 
{
   assert(numFields > 0);
#ifndef NDEBUG
   if(numFields > MAXTUPLEFIELDSDIV2 * 2) {
      cout << "PLinda ERROR: Sorry only up to " <<
	MAXTUPLEFIELDSDIV2 * 2 << " fields in a tuple implemented" << endl;
      cout << "To change this edit tuple-space/Pattern.h, the variable" <<
	" MAXTUPLEFIELDSDIV2 and then make clean and make\n" << flush;
      assert(0);
   }
#endif
#ifndef alpha
   assert(sizeof(void*) <= sizeof(int));
#else
   assert(sizeof(void*) <= sizeof(long));
#endif // alpha
   // a lot of the arithmetic assumes this
   Tuple *temp=(Tuple*) new char[sizeof(Tuple) + sizeof(TupleField) * 
				     (numFields) + totArrayLength];
   assert(temp);
   // worry about the following assignments if new char does not return
   // a word aligned thing.
   temp->totLength = sizeof(TupleField) * (numFields) + sizeof(Tuple) +
     totArrayLength;
   temp->numFields = numFields;
   temp->eti = new ExtraTupleInfo;
   assert(temp->eti);
   temp->eti->nextArrayLocation = sizeof(Tuple) + (numFields)*sizeof(TupleField);
   for(unsigned i = 0 ; i < numFields; i ++) {
      temp->fields(i).valid = 0;
   }
   temp->patternType.init();
   return temp;
}



// for actuals
void Tuple::setActual(const int fieldNum,const TupleField::BasicTypes bt, 
		      const int x) 
{
   assert(bt == TupleField::PLint);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   fields(fieldNum).initialize(TupleField::PLint, false);
   fields(fieldNum).data.Int = x;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
      
}
   
void Tuple::setActual(const int fieldNum,const  TupleField::BasicTypes bt, 
		      const char x) 
{
   assert(bt == TupleField::PLchar);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   fields(fieldNum).initialize(TupleField::PLchar, false);
   fields(fieldNum).data.Char = x;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}   

void Tuple::setActual(const int fieldNum, const TupleField::BasicTypes bt, 
		      const gid x)
{
   assert(bt == TupleField::PLgid);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   fields(fieldNum).initialize(TupleField::PLgid, false);
   fields(fieldNum).data.Gid = x;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}   

void Tuple::setActual(const int fieldNum,const  TupleField::BasicTypes bt, 
		      const long x)
{
   assert(bt == TupleField::PLlong);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   fields(fieldNum).initialize(TupleField::PLlong, false);
   fields(fieldNum).data.Long = x;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}   

void Tuple::setActual(const int fieldNum,const  TupleField::BasicTypes bt, 
		      const physid x)
{
   assert(bt == TupleField::PLphysid);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   fields(fieldNum).initialize(TupleField::PLphysid, false);
   fields(fieldNum).data.PhysId = x;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}



void Tuple::setActual(const int fieldNum, const TupleField::BasicTypes bt, 
		      const float x)
{
   assert(bt == TupleField::PLfloat);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   fields(fieldNum).initialize(TupleField::PLfloat, false);
   fields(fieldNum).data.Float = x;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}

void Tuple::setActual(const int fieldNum, const TupleField::BasicTypes bt, 
		      const double x)
{
   assert(bt == TupleField::PLdouble);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   fields(fieldNum).initialize(TupleField::PLdouble, false);
   TupleField &tf = fields(fieldNum);
   memcpy(&tf.data.Double, &x, sizeof(double));
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


void Tuple::setActual(const int fieldNum, const TupleField::BasicTypes bt, 
		      const void *x,const int structSize)
{
   assert(bt == TupleField::PLstruct);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   TupleField &tf = fields(fieldNum);
   tf.initializeStruct(false,  structSize);
   assert((int)tf.totalSize == structSize);
   tf.data.array = allocateArray(tf.totalSize);
   memcpy(tf.data.array, x, tf.totalSize);
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}

// for array actuals
void Tuple::setActual(const int fieldNum, const TupleField::BasicTypes bt, 
		      const int *x,const  int howMany)
{
   assert(bt == TupleField::PLint);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   TupleField &tf = fields(fieldNum);
   tf.initialize(TupleField::PLint, true, howMany);
   tf.data.array = allocateArray(tf.totalSize);
   memcpy(tf.data.array, x, tf.totalSize);
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}

void Tuple::setActual(const int fieldNum, const TupleField::BasicTypes bt, 
		      const char *x,const int howMany)
{
   assert(bt == TupleField::PLchar);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   TupleField &tf = fields(fieldNum);
   tf.initialize(TupleField::PLchar, true, howMany);
   tf.data.array = allocateArray(tf.totalSize);
   memcpy(tf.data.array, x, tf.totalSize);
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


void Tuple::setActual(const int fieldNum,const  TupleField::BasicTypes bt, 
		      const gid *x,const int howMany)
{
   assert(bt == TupleField::PLgid);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   TupleField &tf = fields(fieldNum);
   tf.initialize(TupleField::PLgid, true, howMany);
   tf.data.array = allocateArray(tf.totalSize);
   memcpy(tf.data.array, x, tf.totalSize);
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


void Tuple::setActual(const int fieldNum,const  TupleField::BasicTypes bt, 
		      const long *x,const int howMany)
{
   assert(bt == TupleField::PLlong);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   TupleField &tf = fields(fieldNum);
   tf.initialize(TupleField::PLlong, true, howMany);
   tf.data.array = allocateArray(tf.totalSize);
   memcpy(tf.data.array, x, tf.totalSize);
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}

void Tuple::setActual(const int fieldNum,const  TupleField::BasicTypes bt, 
		      const float *x,const int howMany)
{
   assert(bt == TupleField::PLfloat);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   TupleField &tf = fields(fieldNum);
   tf.initialize(TupleField::PLfloat, true, howMany);
   tf.data.array = allocateArray(tf.totalSize);
   memcpy(tf.data.array, x, tf.totalSize);
   if(eti->numFieldsInitialized == numFields) 
     pattern();

}

void Tuple::setActual(const int fieldNum,const  TupleField::BasicTypes bt, 
		      const double *x,const  int howMany)
{
   assert(bt == TupleField::PLdouble);
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   TupleField &tf = fields(fieldNum);
   tf.initialize(TupleField::PLdouble, true, howMany);
   tf.data.array = allocateArray(tf.totalSize);
   memcpy(tf.data.array, x, tf.totalSize);
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


void Tuple::setActual(const int fieldNum,const  TupleField::BasicTypes bt, 
		      const void *x,const  int structSize,const int howMany)
{

  assert(bt == TupleField::PLstruct);
   assert(eti);
  eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   TupleField &tf = fields(fieldNum);
   tf.initializeStruct(true, structSize,howMany);
   assert((int)tf.totalSize == structSize * howMany);
   tf.data.array = allocateArray(tf.totalSize);
   memcpy(tf.data.array, x, tf.totalSize);
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


// for formals
void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      int *x) 
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLint);
   fields(fieldNum).initialize(TupleField::PLint, false);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();

   
}
   
void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      char *x)
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLchar);
   fields(fieldNum).initialize(TupleField::PLchar, false);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}

void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      gid *x)
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLgid);
   fields(fieldNum).initialize(TupleField::PLgid, false);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}

void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      long *x)
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLlong);
   fields(fieldNum).initialize(TupleField::PLlong, false);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}

void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      physid *x)
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLphysid);
   fields(fieldNum).initialize(TupleField::PLphysid, false);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      float *x)
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLfloat);
   fields(fieldNum).initialize(TupleField::PLfloat, false);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}

void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      double *x)
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLdouble);
   fields(fieldNum).initialize(TupleField::PLdouble, false);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      void *x,const int structSize)
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLstruct);
   fields(fieldNum).initializeStruct(false,structSize);
   assert((int)fields(fieldNum).totalSize == structSize);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}

// for array formals
void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      int *x, const int howMany)
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLint);
   fields(fieldNum).initialize(TupleField::PLint, true, howMany);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


  
void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      char *x, const int howMany)
{ 
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLchar);
   fields(fieldNum).initialize(TupleField::PLchar, true, howMany);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


  
void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      gid *x,const int howMany)
{ 
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLgid);
   fields(fieldNum).initialize(TupleField::PLgid, true, howMany);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


  
void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt,
		      long *x,const int howMany)
{ 
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLlong);
   fields(fieldNum).initialize(TupleField::PLlong, true, howMany);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      float *x,const int howMany)
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLfloat);
   fields(fieldNum).initialize(TupleField::PLfloat, true, howMany);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}



void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, 
		      double *x, const int howMany)
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLdouble);
   fields(fieldNum).initialize(TupleField::PLdouble, true, howMany);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}


void Tuple::setFormal(const int fieldNum, const TupleField::BasicTypes bt, void *x,
		      int structSize,const int howMany)
{
   assert(eti);
   eti->numFieldsInitialized++;
   assert(eti->numFieldsInitialized <= numFields);
   assert(bt == TupleField::PLstruct);
   fields(fieldNum).initializeStruct(true, structSize, howMany);
   assert((int)fields(fieldNum).totalSize == structSize * howMany);
   fields(fieldNum).data.array = x;
   fields(fieldNum).isAFormal = 1;
   if(eti->numFieldsInitialized == numFields) 
     pattern();
}

/* ----------------------------------------------------------- */

void Tuple::read(const int fieldNum, const TupleField::BasicTypes bt, int &x) const
{
   assert(valid());
   assert(fields(fieldNum).isActual());
   assert(bt == TupleField::PLint && fields(fieldNum).myBasicType == bt);   
   x = fields(fieldNum).data.Int;
}

void Tuple::read(const int fieldNum, const TupleField::BasicTypes bt, char &x) const
{
   assert(valid());
   assert(fields(fieldNum).isActual());
   assert(bt == TupleField::PLchar && fields(fieldNum).myBasicType == bt);   
   x = fields(fieldNum).data.Char;
}

void Tuple::read(const int fieldNum, const TupleField::BasicTypes bt, long &x) const
{
   assert(valid());
   assert(fields(fieldNum).isActual());
   assert(bt == TupleField::PLlong && fields(fieldNum).myBasicType == bt);   
   x = fields(fieldNum).data.Long;
}

void Tuple::read(const int fieldNum, const TupleField::BasicTypes bt, gid &x) const 
{
   assert(valid());
   assert(fields(fieldNum).isActual());
   assert(bt == TupleField::PLgid && fields(fieldNum).myBasicType == bt);   
   x = fields(fieldNum).data.Gid;
}

void Tuple::read(const int fieldNum, const TupleField::BasicTypes bt, physid &x) const
{
   assert(valid());
   assert(fields(fieldNum).isActual());
   assert(bt == TupleField::PLphysid && fields(fieldNum).myBasicType == bt);   
   x = fields(fieldNum).data.PhysId;
}

void Tuple::read(const int fieldNum, const TupleField::BasicTypes bt,int *x,
		 const int maxLength) const
{
   assert(maxLength >= 0);
   assert(valid());
   assert(fields(fieldNum).isActual());
   assert(bt == TupleField::PLint && fields(fieldNum).myBasicType == bt);   
   assert((unsigned)maxLength * PL_INT_SZ >= fields(fieldNum).totalSize);
   memcpy(x, fields(fieldNum).data.array, fields(fieldNum).totalSize);
}

void Tuple::read(const int fieldNum, const TupleField::BasicTypes bt,char *x,
		 const int maxLength) const
{
   assert(maxLength >= 0);  
   assert(valid());
   assert(fields(fieldNum).isActual());
   assert(bt == TupleField::PLchar && fields(fieldNum).myBasicType == bt);   
   assert((unsigned)maxLength * PL_CHAR_SZ >= fields(fieldNum).totalSize);
   memcpy(x, fields(fieldNum).data.array, fields(fieldNum).totalSize);
}


void 
Tuple::read(const int fieldNum, const TupleField::BasicTypes bt,int *&x) const
{
   assert(valid());
   assert(fields(fieldNum).isActual());
   assert(bt == TupleField::PLint && fields(fieldNum).myBasicType == bt);   
   x = (int*)new char[fields(fieldNum).totalSize];
   memcpy(x, fields(fieldNum).data.array, fields(fieldNum).totalSize);
}

void 
Tuple::read(const int fieldNum, const TupleField::BasicTypes bt,char *&x) const
{
   assert(valid());
   assert(fields(fieldNum).isActual());
   assert(bt == TupleField::PLchar && fields(fieldNum).myBasicType == bt);   
   x =  new char[fields(fieldNum).totalSize];
   memcpy(x, fields(fieldNum).data.array, fields(fieldNum).totalSize);
}


ostream& operator<<(ostream& os, const Tuple& t)
{
   os << "Tuple[ " << t.numFields << " " << t.totLength << endl << flush;
   for(char i = 0 ; i < t.numFields ; i++)
     os << i << ":" << flush  << t.fields(i) << ":" << endl << flush;
   os << "]" << flush;
   return os;
}



