
#include <fcntl.h>
#include <iostream.h>
#include <stdlib.h>
#include "Machine.h"
#include "CheckPoint.h"
#include <unistd.h>

#include <assert.h>

#define DEBUG_CHKT 1   

#ifndef __GNUG__
#include <string.h>
#endif
/*-----------------------------------------------------------------------*/
    
CheckPoint::CheckPoint(const gid& g)
{
  grp_id = g;
}


CheckPoint::~CheckPoint(){}


/*-----------------------------------------------------------------------*/

ErrorType
CheckPoint::open(int mode){

    char* fname;
    int num = 0;

    fname = grp_id.name();

#ifdef DEBUG_CHKPT
    cout << "Opening the file " << fname << endl << flush;
#endif
    if (mode & READ_CHKPT){
	fd = ::open(fname, O_RDONLY);
	dirn = READ_CHKPT;
    }
    else{
       assert(mode & WRITE_CHKPT);
	fd = ::open(fname, O_CREAT|O_TRUNC|O_WRONLY, 0644);
	dirn = WRITE_CHKPT;
    }
    delete [] fname;
    if (!fd) {
	cerr << "file open failed for checkpoint.\n" << flush;
	return E_CHKPT_FILE_OPEN;
    }

    if (dirn==READ_CHKPT){
       char tmp_buffer[PL_GID_SZ];
       num = ::read(fd, tmp_buffer,PL_GID_SZ);
       if (num != (PL_GID_SZ)){
	  cerr << "error in checkpt file header read.\n" << flush;
	  return E_CHKPT_FILE_OPEN;
       }
       gid temp = grp_id;
       grp_id = ld_gid(tmp_buffer);
       assert(temp == grp_id);
       // if grp_id == zero_gid, this is the transactionGroup
    } else {
       char tmp_buffer[PL_GID_SZ];
       st_gid(grp_id,tmp_buffer);
       ::write(fd, tmp_buffer, PL_GID_SZ);
    }
    opened_before = 1; 
    return NO_ERROR;
}
/*---------------------------------------------------------------------------*/
ErrorType
CheckPoint::close(){
    int num = 0;
    if (!opened_before) return E_CHKPT_FILE_CLOSE;

    if (dirn == WRITE_CHKPT) {
       char temp[PL_INT_SZ];
       st_int(0, temp);
       num = ::write(fd, temp, PL_INT_SZ);
       if (num != PL_INT_SZ){
	  cerr << "error in checkpt file buffer write.\n" << flush;
	  return E_CHKPT_FILE_CLOSE;
       }
    }
    ::close(fd);
    opened_before = 0;
    return NO_ERROR;
}    


/*------------------------------------------------------------------------------*/

ErrorType CheckPoint::write(const Tuple& t)
{
   int sz, num=0;

   sz = t.length();
   assert(opened_before);
   assert(dirn == WRITE_CHKPT);
   char temp[PL_INT_SZ];
   st_int(t.length(), temp);
   num = ::write(fd, temp, PL_INT_SZ);
   if (num != PL_INT_SZ) {
      cerr << "error in checkpt file buffer write.\n" << flush;
      return E_CHKPT_FILE_CLOSE;
   }
   num = ::write(fd, &t, t.length());
   if (num != t.length()) {
      cerr << "error in checkpt file buffer write.\n" << flush;
      return E_CHKPT_FILE_CLOSE;
   }
   return NO_ERROR;
}

ErrorType CheckPoint::write(const Tuple& t, const gid &g){


   
   ErrorType er = write(t);
   if(!er)
     return er;

   char temp[PL_GID_SZ];
   st_gid(g, temp);
   int num = ::write(fd, temp, PL_GID_SZ);
   if (num != PL_GID_SZ) {
      cerr << "error in checkpt file buffer write.\n" << flush;
      return E_CHKPT_FILE_CLOSE;
   }
   return NO_ERROR;
}

Tuple* CheckPoint::read_tuple()
{
    Tuple* t; 
    int num, length;
    assert(dirn == READ_CHKPT);
    assert(opened_before);
    char temp[PL_INT_SZ];
    num = ::read(fd, temp, PL_INT_SZ);
    if (num != PL_INT_SZ) {
       cout << "error in checkpt file buffer read. 1 num = " << num << 
	 "\n" << flush;
       return (Tuple*)0;
    }
    length = ld_int(temp);
    if(length == 0)
      return NULL; // end of the tuples 
    assert(length > 0 && 
	   (unsigned)length >= sizeof(Tuple) + sizeof(TupleField));

    char *buf = new char[length];
    assert(buf);
    num = ::read(fd, buf, length);
    if (num != length) {
       cout << "error in checkpt file buffer read. 2 for " <<
	 length << " want to read, num = " << num << "\n" << flush;
       return NULL;
    }    
    t = (Tuple*)buf;
    t->updatePointers();
    assert(t->valid());
    assert(t->length() == length);
    return t;
}

Tuple* CheckPoint::read_tuple(gid &g)
{
   int num;

   Tuple *t = read_tuple();
   if(t == NULL)
     return t;

   char temp[PL_GID_SZ];
   num = ::read(fd, temp, PL_GID_SZ);
   if (num != PL_GID_SZ) {
      cerr << "error in checkpt file buffer read. 3\n" << flush;
      return NULL;
    }
   g = ld_gid(temp);
   return t;
}

