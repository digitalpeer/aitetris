// This may look like C code, but it is really -*- C++ -*-
//
// File:       Snapshot.h
// Description: process snapshot and global snapshot 
// Created:  
// Author:     Karp Joo Jeong
// Mail:       jeong@cs.nyu.edu
//

#ifndef _SNAPSHOT_H_
#define _SNAPSHOT_H_


// PLinda
#include "plinda_ids.h"

// GNU stuff
#include "GNU_Interface.h"

class ClientProcess;
class ProcessSnapshot;
typedef DLList<ProcessSnapshot*> ProcSnapshotList;


// ----------------------------------------------------------------
// Process Snapshot
// ----------------------------------------------------------------

class ProcessSnapshot {
 public:
  enum StatusType { READY, REQUESTED, FINISHED };

  // constructor;
  ProcessSnapshot(ClientProcess*);
  // destructor
  ~ProcessSnapshot(void);

  procid identifier(void) const;
  ClientProcess* client(void) const;

  // status: 
  // READY at construction time 
  // REQUESTED at ClientProcess::request_private_log
  // FINISHED at GlobalSnapshot::report_psnapshot
  StatusType status(void) const;
  void status(StatusType);
  
 private:
  ClientProcess* x_client;
  StatusType x_status;
};

  
// ----------------------------------------------------------------
// Global Snapshot
// ----------------------------------------------------------------

class GlobalSnapshot {
 public:
  enum StatusType { DEACTIVATED, ACTIVATED, FINISHED };
  enum SnapshotMode { SEQUENTIAL, CONCURRENT };

  // constructor
  GlobalSnapshot(void);

  // destructor
  ~GlobalSnapshot(void);

  // activate;
  void activate(void);
  
  // deactivate;
  void deactivate(void);
  
  // include a process in the global snapshot;
  void take_psnapshot(ClientProcess*);
  
  // client process reports the completion of snapshot;
  void complete_psnapshot(procid);

  // check the status of a process wrt global snapshot
  // 1: not done, 0: done, -1: not included.
  int check_status(ClientProcess*);

  // status;
  StatusType status(void) const;
  int finished(void) const;
  int activated(void) const;
  int deactivated(void) const;

  // mode;
  SnapshotMode mode(void) const;
  void mode(SnapshotMode);
    
 private:
  StatusType x_status;
  SnapshotMode x_mode;

  ProcSnapshotList x_psnapshot_list;

  int x_num_psnapshots;
};


#ifndef _OUTLINE_
#include "Snapshot.iC"
#endif


#endif // _SNAPSHOT_H_

