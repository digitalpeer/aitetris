// This may look like C code, but it is really -*- C++ -*-
//
// File:     TupleGroupManager.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//

#include <stream.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>

#include "plinda_ids.h"
#include "ErrorType.h"
#include "TupleHandle.h"
#include "Transaction.h"
#include "TupleGroup.h"
#include "TupleGroupManager.h"
#include "ObjectSpace.h"
#include "EventLog.h"
#include "System_Patterns.h"

// ----------------------------------------------------------------------
// constructor and destructor
// ----------------------------------------------------------------------

TupleGroupManager::TupleGroupManager(void) {
  group_list.clear();
}

// dummy copy constructor.
TupleGroupManager::TupleGroupManager(const TupleGroupManager& ) {
}

TupleGroupManager::~TupleGroupManager(void) {
  group_list.clear();
}

int TupleGroupManager::initialize(const gid& fgid, 
			      const physid& fphysid, 
			      const gid& cat_gid,
			      const gid& trace_gid) {
  TupleGroup::set_last_gid(fgid);
  TupleGroup::set_last_physid(fphysid);

  catalog_group.update_group_id(cat_gid);
  trace_group.update_group_id(trace_gid);

  return 1;
}


/*__________________________________________________________________________*/

TupleGroup*
TupleGroupManager::find_group(const gid& g) {
  Pix g_pix;
  if (g == TRACE_GID) {
      return (&trace_group);
  }
  for(g_pix = group_list.first(); g_pix != 0; group_list.next(g_pix)) {
    TupleGroup* g_cur = group_list(g_pix);
    if(g_cur->get_grpid() == g) {
      return g_cur;
    }
  }
  return 0;
}
/*__________________________________________________________________________*/

TupleGroup*
TupleGroupManager::find_group(const char* group_name){
  Pix g_pix;
  for(g_pix = group_list.first(); g_pix != 0; group_list.next(g_pix)) {
    TupleGroup* g_cur = group_list(g_pix);
    if(::strcmp(g_cur->group_name(), group_name) == 0) {
      return g_cur;
    }
  }
  return 0;
}
/*__________________________________________________________________________*/
ErrorType
TupleGroupManager::dump_group(const char* group_name){
  TupleGroup* g;
  char dump_file[200];
  ErrorType status;

  g = find_group(group_name);
  if (g == NULL){
      cerr << "invalid tuple group name.\n" << flush;
      return NO_ERROR;
  }
  ::strcpy(dump_file, "/tmp/");
  ::strcat(dump_file, group_name);
  //cout << dump_file << " ---- \n" << flush;
  {
    ofstream dump_stream;
    dump_stream.open(dump_file, ios::out);
    status = g->dump(dump_stream);
    dump_stream.close();
  }
  return status;
}
/*__________________________________________________________________________*/

TupleGroup* 
TupleGroupManager::open_group(const gid& g) {
  TupleGroup*  g_cur;

  if(g==zero_gid) {
    return 0;
  }
  
  g_cur = find_group(g);
  
  // we should find it.
  if (g_cur==0) {
    return 0;
  }
  
  // one more process.
  g_cur->incr_refcount();

  return g_cur;
}

/*__________________________________________________________________________*/

int 
TupleGroupManager::close_group(const gid& g) {
  TupleGroup*  cur;
  
  if(g==zero_gid) {
    return 0;
  }
  
  cur = find_group(g);
  
  if(cur==0) {
    return 0;
  }
  
  assert(cur->refcount() > 0);
  cur->decr_refcount();

  return 1;
}

 
/*__________________________________________________________________________*/

void 
TupleGroupManager::close_group(TupleGroup* g_cur) {
  assert(g_cur->refcount() > 0);
  g_cur->decr_refcount();
}


/*__________________________________________________________________________*/

TupleGroup* 
TupleGroupManager::create_group(Process* proc, 
			      Transaction* trans,
			      const char* name,
			      const gid& g){
  assert(trans && proc);
  assert(trans->process() == proc);
  assert(name);
  gid new_id;

#ifndef ALWAYS_FRESH_TS
  // check if a group with this name exists already if so, just use it
  {
    TupleGroup *g;
    if((g = find_group(name))) 
      return g;
  }
#endif    
  
  if(g == zero_gid){
    new_id = TupleGroup::get_next_gid();
  } else {
    new_id = g;
  }

  // create TupleGroup object.
  TupleGroup* g_cur = new TupleGroup; 
  assert(g_cur != 0);
  g_cur->update_group_id(new_id);
  g_cur->group_name(name);

  // append the object to the group list.
  group_list.append(g_cur);
   
  {
    // insert a catalog entry tuple into the catalog_group.
    Tuple* cat_tuple = ::create_catalog_tuple(new_id, name); 
    TupleHandle t_handle;
    catalog_group.insert_tuple(t_handle,cat_tuple);
    assert(t_handle.valid());
    cat_tuple = NULL; // do not destroy, it is in tuple space
  }
  
  // transaction will call either commit_creation or abort_creation.
  trans->create_group( g_cur);
  
  return g_cur;
}
void TupleGroupManager::remove_group(TupleGroup *)
{
}

int
TupleGroupManager::destroy_group(Process* ,
			       Transaction* trans,
			       TupleGroup* grp) 
{
  // Peter, currently this is not called, destroy group just sets
  // a gid to zero_gid on the client side
  Tuple* cat_tuple = ::create_catalog_tuple_pattern(grp->get_grpid());
  TupleHandle t_handle;
  catalog_group.retrieve_tuple(t_handle, cat_tuple, Tuple::IN);
  assert(t_handle.valid());
  trans->access_tuple(&catalog_group, t_handle,Tuple::IN);
  trans->destroy_group( grp);

  return 1;
}



// ----------------------------------------------------------------------
// checkpoint
// ----------------------------------------------------------------------
#include "TransactionManager.h"

ErrorType
TupleGroupManager::checkpoint(void) {
  ErrorType error_val;

  if(!(error_val=catalog_group.checkpoint_group())) {
    return error_val;
  }

  for(Pix cur=group_list.first(); cur!=0; group_list.next(cur)) {
    TupleGroup* group = group_list(cur);
    if( !( error_val = group->checkpoint_group()))
       return error_val;
 }

  return NO_ERROR;
}


// ----------------------------------------------------------------------
// rollback
// ----------------------------------------------------------------------

ErrorType
TupleGroupManager::rollback(void) {
  ErrorType error_val;
  if(!(error_val=catalog_group.load_checkpoint())) {
    return error_val;
  }
  TupleHandleIterator iter;
  TupleHandle g_hdle;
  catalog_group.iterator(iter);
  for(iter.first(g_hdle) ; g_hdle.valid(); iter.next(g_hdle)) {
    gid g;
    const char* name;
//    long store_type;
    Tuple *temp = ::create_catalog_tuple_pattern();
    // Above is a slight Kludge have to create an empty pattern to read this
    ::read_catalog_tuple(g_hdle.tuple(),temp, g, name);

    TupleGroup* group = new TupleGroup;
    assert(group != 0);
    group->update_group_id(g);

    if(!group->load_checkpoint()) {
      cerr << "ERROR loading checkpoint for group " << g << endl << flush;
      ObjectSpace::event_log.error("TupleGroupManager:rollback",
				   "unable to rollabck a group");
      continue;

    } else {
      group_list.append(group);
    }
 }

  return NO_ERROR;
}

void
TupleGroupManager::dump(ofstream& log) {
  log << "\n\n============ TupleGroup Manager ==================\n";

  log << "\n ---- Catalogue Group ---- \n";

  catalog_group.dump(log);

  log << "\n ---- User Groups ---- \n";

  Pix g_pix;
  for(g_pix = group_list.first(); g_pix != 0; group_list.next(g_pix)) {
    TupleGroup* g_cur = group_list(g_pix);
    log << "\n --- " << g_cur->get_grpid() << " --- \n";
    g_cur->dump(log);
  }
  log << "\n==================================================\n\n";

  log.flush();
}
