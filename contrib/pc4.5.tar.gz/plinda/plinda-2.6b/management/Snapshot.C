// This may look like C code, but it is really -*- C++ -*-
//
// File:       Snapshot.C
// Description 
// Created:  
// Author:     Karp Joo Jeong
// Mail:       jeong@cs.nyu.edu
//
#include "Snapshot.h"
#include "ClientProcess.h"


#ifdef  AUTO_FAULT_MODE
#include "FaultLevelManager.h"
#include "ObjectSpace.h"
#endif


#ifdef _OUTLINE_
#define inline
#include "Snapshot.iC"
#endif

// ---------------------------------------------------------------------
// class ProcessSnapshot
// ---------------------------------------------------------------------

ProcessSnapshot::ProcessSnapshot(ClientProcess* client) {
  x_status = READY;
  x_client = client;
}

ProcessSnapshot::~ProcessSnapshot(void) {
  x_client = 0;
}



// ----------------------------------------------------------------
// Global Snapshot
// ----------------------------------------------------------------

GlobalSnapshot::GlobalSnapshot(void) {
  x_psnapshot_list.clear();
  x_status = DEACTIVATED;
  x_mode = SEQUENTIAL;
  x_num_psnapshots = 0;
}

GlobalSnapshot::~GlobalSnapshot(void) {
  x_psnapshot_list.clear();
}

void
GlobalSnapshot::activate(void) {
  // global snapshot is activated.
  assert(x_status == DEACTIVATED);

  if(x_psnapshot_list.length() == 0) {
    // all psnapshots are fine. 
    x_status = FINISHED;
    return;
  }

  // start gsnapshot.
  x_status = ACTIVATED;

  Pix cur;
  if(x_mode == CONCURRENT) {
    // broadcast a global snapshot request
    for(cur = x_psnapshot_list.first(); cur != 0; x_psnapshot_list.next(cur)) {

      ProcessSnapshot* pcur = (ProcessSnapshot*)x_psnapshot_list(cur);
      pcur->status(ProcessSnapshot::REQUESTED);

      ClientProcess* proc = pcur->client();
#ifdef AUTO_FAULT_MODE
      if(ObjectSpace::ftlvl_mgr.is_need_change_ft_level() ||
         proc->inconsistent()) {
#else
      if (proc->inconsistent()) {
#endif
	proc->request_psnapshot();
      } else {
        pcur->status(ProcessSnapshot::FINISHED);
        --x_num_psnapshots;
      }
    }

  } else {
    // SEQUENTIAL
    // send a global snapshot request to the first process.
    cur = x_psnapshot_list.first();
    if(cur != 0) {
      ProcessSnapshot* pcur = (ProcessSnapshot*)x_psnapshot_list(cur);
      pcur->status(ProcessSnapshot::REQUESTED);

      ClientProcess* proc = pcur->client();
#ifdef AUTO_FAULT_MODE
      if(ObjectSpace::ftlvl_mgr.is_need_change_ft_level() ||
         proc->inconsistent()) {
#else
      if ( proc->inconsistent()) {
#endif
	proc->request_psnapshot();
      } else {
        pcur->status(ProcessSnapshot::FINISHED);
        --x_num_psnapshots;
      }
    }
  }
}


void
GlobalSnapshot::deactivate(void) {
  assert(x_status == FINISHED && x_num_psnapshots == 0);
  x_psnapshot_list.clear();
  x_status = DEACTIVATED;
}


void 
GlobalSnapshot::take_psnapshot(ClientProcess* proc) {
  ProcessSnapshot* psnapshot = new ProcessSnapshot(proc);
  x_psnapshot_list.append(psnapshot);
  ++x_num_psnapshots;
}

// process snapshot is completed.
void
GlobalSnapshot::complete_psnapshot(procid id) {
  Pix cur;
  ProcessSnapshot* pcur = 0;
  ClientProcess* proc = 0;

  // look for the process;
  for(cur=x_psnapshot_list.first(); cur != 0; x_psnapshot_list.next(cur)) {
    pcur = (ProcessSnapshot*)x_psnapshot_list(cur);
    proc = pcur->client();
    if(proc->identifier() == id) break;
  }

  if(proc != 0) {
    // when a process terminates, it informs the snapshot manager.
    assert(pcur->status() == ProcessSnapshot::REQUESTED ||
	   proc->status() == Process::COMPLETED);

    --x_num_psnapshots;
    if(x_num_psnapshots == 0) x_status = FINISHED;

    if(pcur->status() == ProcessSnapshot::READY) {
      // this is called only because this process terminated.
      pcur->status(ProcessSnapshot::FINISHED);
      return;
    } else {
      pcur->status(ProcessSnapshot::FINISHED);
    }
#define GLOBAL_SNAPSHOT_BUG_FIXED 1
#ifdef GLOBAL_SNAPSHOT_BUG_FIXED
 } else {
     // when a process terminates, the client process will send
      // a complete message to snapshot ( in GLOBAL_SNAPSHOT mode).
      return;

#endif
   }
  
  // for CONCURRENT, we have already sent a request to each process.
  if(x_mode == CONCURRENT) return;

  // FINISHED, of course, no need to go further;
  if(x_status == FINISHED) return;


  // SEQUENTIAL: look for a process whose snapshot has not been taken
  // and send it a request.
  for(cur=x_psnapshot_list.first(); cur != 0; x_psnapshot_list.next(cur)) {
    ProcessSnapshot* pcur = (ProcessSnapshot*)x_psnapshot_list(cur);
    assert(pcur->status() != ProcessSnapshot::REQUESTED);
    if(pcur->status() == ProcessSnapshot::READY) {
      pcur->status(ProcessSnapshot::REQUESTED);
      ClientProcess* proc = pcur->client();
#ifdef AUTO_FAULT_MODE
      if(ObjectSpace::ftlvl_mgr.is_need_change_ft_level() ||
         proc->inconsistent()) {
#else
      if(proc->inconsistent()) {
#endif
	// inconsistent snapshot in the server.
        proc->request_psnapshot();
        break;
      } else {
	// snapshot in the server is consistent with the process.
	pcur->status(ProcessSnapshot::FINISHED);
	--x_num_psnapshots;
      }
    }
  }
  assert((cur != 0 && x_num_psnapshots != 0) ||
	 (cur == 0 && x_num_psnapshots == 0));
  if(x_num_psnapshots == 0) {
    x_status = FINISHED;
  }  
}


int
GlobalSnapshot::check_status(ClientProcess* client) {
  Pix cur;
  // look for the process;
  for(cur=x_psnapshot_list.first(); cur != 0; x_psnapshot_list.next(cur)) {
    ProcessSnapshot* pcur = (ProcessSnapshot*)x_psnapshot_list(cur);
    ClientProcess* proc = pcur->client();
    if(proc->identifier() == client->identifier()) {
      if(pcur->status() != ProcessSnapshot::FINISHED) {
	// not yet.
	return 1;
      } else {
	// done.
	return 0;
      }
    }
  }
  
  // not included.
  return -1;
}
