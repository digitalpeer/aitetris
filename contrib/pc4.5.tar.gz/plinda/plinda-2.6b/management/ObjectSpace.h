// This may look like C code, but it is really -*- C++ -*-
//
// File:        ObjectSpace.h
// Description: The class ObjectSpace defines various object spaces
//		such as the process object space and the transaction
//		object space. In addition, the scheduler object and 
//		the connection/message listener objects are also defined.
// Created:  
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//

#ifndef _OBJECT_SPACE_H_
#define _OBJECT_SPACE_H_

#include <stdio.h>
#include <sys/types.h>

// *** GNU Stuff ***
#include <DLList.h>

// we do not need to know about the following classes here.
class Reactor;
class Scheduler;
class FailureMonitor;
class LoadBalancer;

class MessageListener;
class ConnectionListener;

class Process;
class TupleGroup;

class ProcessManager;
class TransactionManager;
class TupleGroupManager;
class MonitorProcess;

class LogManager;
class CheckpointManager;
class GlobalSnapshot;
class EventLog;

#ifdef AUTO_FAULT_MODE
class FaultLevelManager;
#endif


// more convenient to make it public. 
enum FT_LevelType { NO_SUPPORT, GLOBAL_SNAPSHOT, 
		    MESSAGE_REPLAY, PRIVATE_SNAPSHOT };

class ObjectSpace {
public:

  enum ServerMode  { NORMAL, DEBUGGING };
  enum ServerState { RUNNING, SUSPENDED, SHUTDOWN_SERVER};
  enum ConfigParam { LINK_TIMEOUT = 1, FAILURE_TIMEOUT=2, SEND_TIMEOUT=3,
		     CHKPT_INTERVAL=4, MAX_CONNECTIONS=5, IDLENESS_INTERVAL=6
		   };

  // ------------------------------------------------------------
  // These are the global server configuration parameters :
  // ------------------------------------------------------------
  static ServerState    server_state;
  static ServerMode     server_mode;


  static const unsigned  process_default_timeout;
  static unsigned  	 process_timeout;

  static const unsigned  loadbalancing_default_interval;
  static unsigned  	 loadbalancing_interval;

  static const unsigned  link_default_timeout;
  static const unsigned  send_default_timeout;

  static const unsigned  chkpt_default_interval;
  static unsigned  	 chkpt_interval;

#ifdef AUTO_FAULT_MODE
  static const float  failure_default_rate;
  static float   failure_rate;
 
  static const unsigned continuation_default_size;
  static unsigned       continuation_size;
#endif

  static const unsigned  default_minimum_idletime;
  static unsigned        minimum_idletime;

  static const unsigned  default_max_connections;
  static unsigned  	 max_connections;

  static const unsigned  default_max_num_clients_per_daemon;
  static const unsigned  max_num_clients_per_daemon;

  static const unsigned  monitor_update_interval;

  static unsigned        trace_on;

  static const char* x_server_name;
  static const char* working_directory;
  static const char* host_file;


  static int cleanup_log(const char* host, const char *uname,long pid);

  // ------------------------------------------------------------
  // The monitor process ...
  // ------------------------------------------------------------
  static MonitorProcess  monitor;

  // ------------------------------------------------------------
  // Fault Tolerance Level 
  // ------------------------------------------------------------
  static FT_LevelType fault_tolerance_level;
  static int check_ft_degree(FT_LevelType);

#ifdef AUTO_FAULT_MODE
  static void set_ft_degree(FT_LevelType);  
#endif

  // ------------------------------------------------------------
  // flags 
  // ------------------------------------------------------------

  static int batch_flag;	// batch 
  static int piranha_flag;      // Piranha style computation
  static int debugging_flag;	// debugging

  static int display_flag;	// display 
  static int dumb_monitor_flag; // flag for dumb monitor.

  // ------------------------------------------------------------
  // Constructor 
  // ------------------------------------------------------------
  ObjectSpace(void);

  // actual initialization is performed here.
  static int initialize(int recover_system, int concurrent_gsnapshot);

  // shutdown the server.
  static int shutdown(void);

  // ----------------------------------------------------
  // the server scheduler
  // ----------------------------------------------------
  static Scheduler scheduler;
  static FailureMonitor failure_monitor;
  static LoadBalancer load_balancer;


  // ----------------------------------------------------
  // ACE communication manager
  // ----------------------------------------------------
  static Reactor comm_mgr;


  // ----------------------------------------------------
  // object to handle connection requests. 
  // ----------------------------------------------------
  // static ConnectionListener loc_conn_lsner;
  static ConnectionListener conn_lsner;


  // ----------------------------------------------------
  // object to handle message delivery requests.
  // ----------------------------------------------------
  // static MessageListener loc_mssg_lsner;
  static MessageListener mssg_lsner;


  // ----------------------------------------------------
  // checkpoint manager 
  // ----------------------------------------------------
  static CheckpointManager   chkpt_mgr;
  static GlobalSnapshot      snapshot_mgr;
#ifdef AUTO_FAULT_MODE
  static FaultLevelManager   ftlvl_mgr; // Jihai
#endif
  
  // ----------------------------------------------------
  // logging process which is now dummy. 
  // ----------------------------------------------------
  static LogManager   log_mgr;


  // --------------------------------------------------------
  // recover a consistent state of the server before failure.
  // --------------------------------------------------------

  // restore a consistent system state by replaying the log 
  // after rollback to the last checkpoint.
  // now, we do not replay the log.
  static int 	 recover(void);


  // ----------------------------------------------------
  // Object Subspaces
  // ----------------------------------------------------
  static ProcessManager     proc_mgr;
  static TransactionManager trans_mgr;
  static TupleGroupManager  group_mgr;


  // ----------------------------------------------------
  // event log 
  // ----------------------------------------------------

  static EventLog     event_log;

  // ----------------------------------------------------
  // dump the entire state
  // ----------------------------------------------------

  static void dump(void);

  // ----------------------------------------------------
  // set server's state (check the type defined above)
  // ----------------------------------------------------
  static void state(const ServerState);
  static ServerState state(void);

  // ----------------------------------------------------
  // set server's operation mode (check type defined above)
  // ----------------------------------------------------
  static void mode(const ServerMode);
  static ServerMode mode(void);

  /* setting configuration parameters ... */
  static void set_config(const ConfigParam, unsigned);

  // need to protect the server from the SIG_PIPE signal.
  static void sigpipe_catcher(int);
  static void sigint_catcher(int);

};

#endif // _OBJECT_SPACE_H_
