// This may look like C code, but it is really -*- C++ -*-
//
// File:        TransactionManager.h
// Description:	manages information about the transactions.
// Created:  
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//
#ifndef _TRANSACTION_MANAGER_H_
#define _TRANSACTION_MANAGER_H_

// PLinda header files & forward declaration
#include "plinda_ids.h"


// GNU stuffs
#include <fstream.h>
#include "GNU_Interface.h"

#include "TupleGroupManager.h" // just for friend
class Transaction;

// default first transid.
const transid  FIRST_TRANSID = transid::zero(0,1);

class TransactionManager {
friend TupleGroupManager::checkpoint(void);
public:


  TransactionManager(void);
  virtual ~TransactionManager(void);

  int initialize(const transid& =FIRST_TRANSID); 

  // -----------------------------------------------------------------------
  // find, create and destroy transaction objects
  // -----------------------------------------------------------------------

  Transaction*   find_transaction(const transid&);
  Transaction*   create_transaction(Process*);
  int            destroy_transaction(Transaction*);

  ErrorType      checkpoint(void);
  ErrorType      rollback(void);
  // -----------------------------------------------------------------------
  // printing
  // -----------------------------------------------------------------------

  void dump(ofstream&); 
    
private:
  // transaction list
  TransactionList trans_list;

};

#endif // _TRANSACTION_MANAGER_H_
