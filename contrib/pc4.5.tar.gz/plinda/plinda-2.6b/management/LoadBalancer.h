// This may look like C code, but it is really -*- C++ -*-
//
// File:     LoadBalancer.h 
// Created:  May 1, 1995
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//
#ifndef _LOAD_BALANCER_H_
#define _LOAD_BALANCER_H_

// ACE
#include "Reactor.h"

class LoadBalancer : public Event_Handler {
public:
  // constructor and destructor
  LoadBalancer(void);
  ~LoadBalancer(void) {};

  // timeout
  void timeout(long);
  virtual int handle_timeout(const Time_Value&, const void*);

private:
  Time_Value x_timeout;
};

#ifndef _OUTLINE_
#include "LoadBalancer.iC"
#endif // _OUTLINE_

#endif // _LOAD_BALANCER_H_
