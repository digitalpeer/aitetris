// This may look like C code, but it is really -*- C++ -*-
//
// File:     Scheduler.h 
// Created:  May 1, 1994
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//
#ifndef _SCHEDULER_H_
#define _SCHEDULER_H_

// ACE
#include "Reactor.h"

class Scheduler {
public:
  Scheduler(void);
  int event_loop(void);

  // when ServerCommLink detects a process failure,
  // it calls this and so forces the schedulre to handle the failure
  // as soon as possible.
  void detect_failure(void);

  void activate_chkpt(void);
  int chkpt_on(void) const;

private:
  enum SchedulingModeType { REGULAR_SCHEDULING, GSNAPSHOT_SCHEDULING };
  SchedulingModeType x_scheduling_mode;

  int failure_detection_flag;

  int closedown_flag;
};

#ifndef _OUTLINE_
#include "Scheduler.iC"
#endif // _OUTLINE_

#endif // _SCHEDULER_H_
