// This may look like C code, but it is really -*- C++ -*-
//
// File:        DaemonProcess.C
// Description: 
// Created:  
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu

#include <stdio.h>
#include <sys/types.h>
#include <assert.h>

#include "plinda_ids.h"
#include "ErrorType.h"
#include "ConnectionListener.h"
#include "ClientProcess.h"
#include "Transaction.h"
#include "ProcessManager.h"
#include "TransactionManager.h"
#include "TupleGroupManager.h"
#include "ObjectSpace.h"
#include "ServerCommLink.h"
#include "DaemonProcess.h"
#include "Header.h"
#include "plinda_daemon.h"
//#include "MonitorPatterns.h"
#include "MonitorProcess.h"
#include "Scheduler.h"
#include "Architectures.h"

#ifdef _OUTLINE_
#define inline
#include "DaemonProcess.iC"
#endif
 
int DaemonProcess::system_next_hostid;

DaemonProcess::DaemonProcess(procid id, const char* host, const char *htype,
			     const char *uname) 
: Process(DAEMON, id) {

  int len = ::strlen(host)+1;
  char* ptr = new char[len];
  ::strcpy(ptr, host);
  x_hostname = ptr;

  int typelen = ::strlen(htype)+1;
  char* typeptr = new char[typelen];
  ::strcpy(typeptr, htype);
  x_hosttype = typeptr;
  x_username = new char[::strlen(uname)+1];
  ::strcpy((char*)x_username,uname);
  x_hostid = get_next_hostid();
    

  // need to check if the host is not remote.
  // anyhow, it is a temporary fix.
  x_server_ip = ObjectSpace::conn_lsner.ip_address();
  x_server_port = ObjectSpace::conn_lsner.port_number();

  // it is important that ObjectSpace::initialize is called before this.
  if(ObjectSpace::piranha_flag == 1) {
    status(DISPATCHED);
  } else {
    status(REQUEST_READY);
  }

  x_client = new ClientProcess* [ObjectSpace::max_num_clients_per_daemon];
  for(unsigned i=0; i<ObjectSpace::max_num_clients_per_daemon; i++){
      x_client[i] = 0;
  }
  //  x_cur_request = 0;
  
  x_num_clients = 0;
  x_max_num_clients = (ObjectSpace::max_num_clients_per_daemon);


  // fetching process info transactionally.
  x_dsptch_trans = 0;

  // daemon uses a temporary connection.
  set_temp_link_flag();

  x_alive_flag = 1;

  // should be aware of the order 
  // in which the current daemon sends messages.
  x_last_seq_num = -1;
}

DaemonProcess::~DaemonProcess(void) {
  delete [] (char*)x_hosttype;
  delete [] (char*)x_hostname;
  delete [] (char*)x_username;
  // do nothing
}


void
DaemonProcess::enqueue_request(Header *header, Tuple *tuple) {

  assert(tuple == 0);
  x_alive_flag = 1;

  int seq_num = header->sequenceNum();
  int message_type = header->daemonMsgType();

  // process the received message.
  switch(message_type) {
  case REGISTER:
    {

    int UNIX_pid = header->transientId();
    // we need to remember this to kill the daemon later.
    transient_id(UNIX_pid);
    
    // set the minimum idle time.
    set_minimum_idletime(ObjectSpace::minimum_idletime);

    // record the info about the daemon process (real UNIX process)
    ObjectSpace::cleanup_log(x_hostname,x_username, UNIX_pid);
   }
    break;
  case BUSY_NOTICE:
    if(seq_num < x_last_seq_num) {
#ifdef PL_DEBUG
       cout << "A TCP/IP ,message got out of order 1\n" << flush;
      // this message is delayed.
#endif
      break;
    }
    if(status() == REQUEST_READY || 
       status() == DISPATCHED || 
       status() == RUNNING) {
      status(SLEEPING);
      declare_client_failure();
    }
    cerr << "> host " << x_hostname << " is busy !!\n";
    cerr.flush();
    break;
  case IDLE_NOTICE:
    if(seq_num < x_last_seq_num) {
#ifdef PL_DEBUG
       cout << "A TCP/IP ,message got out of order 2\n" << flush;
      // this message is delayed.
#endif
      break;
    }

    if(status() != SLEEPING && status() != DISPATCHED && status() != RUNNING) {
      break;
    }

    if (x_num_clients < x_max_num_clients) {
	status(REQUEST_READY);
    } else {
	status(RUNNING);
    }
    cerr << ">> host " << x_hostname << " is idle !!\n";
    cerr.flush();
    break;
  case ALIVE_NOTICE:
	cerr << "> received ALIVE from " << x_hostname << "\n";
	cerr.flush(); 
    break;
  }

  x_last_seq_num = seq_num;
  delete header;
}


// the programmer is supposed to run processes with gdb.
int
DaemonProcess::pseudo_spawn_process(void) {
  assert(ObjectSpace::proc_mgr.evalcount() > 0);
  assert(ObjectSpace::debugging_flag == 1);

  Transaction* trans =
    ObjectSpace::trans_mgr.create_transaction(ObjectSpace::proc_mgr.super);
  
  char* name;
  procid proc_id;
  long retry;
  int interactive;

  ObjectSpace::proc_mgr.dispatch_PROCESS((DaemonProcess*)ObjectSpace::proc_mgr.super, 
				         trans, name, proc_id, retry,
					 interactive);

  cerr << "> RUN: " << name << " " << proc_id << " " 
	<< ObjectSpace::conn_lsner.port_number() << " "
	<< ObjectSpace::conn_lsner.hostname() << "\n";
  cerr.flush();
  delete [] name;
  name = NULL;
  trans->commit();
  ObjectSpace::trans_mgr.destroy_transaction(trans);

  return 0;
}

/*------------------------------------------------------------------------*/


#ifdef linux
static const char *server_type= "linux";
#endif
#ifdef alpha
static const char *server_type= "alpha";
#endif
#ifdef solaris
static char *server_type="solaris";
#endif
#ifdef sunos
static char *server_type="sunos";
#endif
#ifdef irix
static char *server_type= "irix";
#endif

int
DaemonProcess::dispatch_client(procid proc_id) {
   extern const char *REMOTESH;
  assert(ObjectSpace::proc_mgr.evalcount() > 0 && status() == REQUEST_READY);

  x_dsptch_trans = ObjectSpace::trans_mgr.create_transaction(this);
  
  char* name;
  long retry;
  int interactive;

  ClientProcess* client = ObjectSpace::proc_mgr.dispatch_PROCESS(this, 
						    x_dsptch_trans, 
						    name, proc_id, retry,
						    interactive);
  
  assert(client);
  assert(x_username);
  if(ObjectSpace::piranha_flag == 1) {
    // ***** PIRANHA is enabled *****;
    Header header;
    header.daemonMsgType(CREATE_WORKER);
    header.interactive(ObjectSpace::x_server_name == 0 ? 0 : interactive);
    header.processId(proc_id);
    Tuple *t = Tuple::create(1, ::strlen(name) + 1);
    t->setActual(0, TupleField::PLchar, name, ::strlen(name) + 1);
    header.tupleLength(t->length());
    
    if(send_reply(header,t) == -1) {
      x_dsptch_trans->abort();
      ObjectSpace::trans_mgr.destroy_transaction(x_dsptch_trans);
      declare_failure();
      return -1;
   }
    Tuple::destroy(t);
  } else {
    // **** PIRANHA is disabled. *****;
    // simplest method to dispatch a process on a remote machine.;
    char command[1000];

   if(! PLinda_Architectures::supported(x_hosttype)) {
       cerr << x_hosttype << " architecture is not currently supported Sorry" 
	 << __LINE__ << __FILE__ << endl << ::flush;
       assert(0);
    }
    int need_to_convert = PLinda_Architectures::need_to_convert(x_hosttype,
								server_type);
    if(interactive) {

      ::sprintf(command, 
		"%s %s -l %s \"xterm -display %s -e sh -c 'plinda/lib/%s/%s \
 %ld %d %s interactive %d ; cat' \" & ", REMOTESH, x_hostname,x_username,
		ObjectSpace::proc_mgr.x_server(), 
		x_hosttype,
		name, proc_id,
		ObjectSpace::conn_lsner.port_number(), 
		ObjectSpace::conn_lsner.hostname(),need_to_convert);
      ::system(command);
    } else { 
      ::sprintf(command, " %s %s -l %s \"plinda/lib/%s/%s %ld %d %s noninteractive %d -l  \" & ",REMOTESH,
		x_hostname, x_username,x_hosttype, name, proc_id, 
		ObjectSpace::conn_lsner.port_number(), 
		ObjectSpace::conn_lsner.hostname(),need_to_convert);
      ::system(command);
    }
 }
  client->daemon_process(this);
  client->executable(name);
  wait(client);
  x_dsptch_trans->commit();
  ObjectSpace::trans_mgr.destroy_transaction(x_dsptch_trans);
  x_dsptch_trans = 0;
  
  if (ObjectSpace::display_flag ==1){
      cout << ">process creation : " << name << ":" << proc_id << " on " << 
	  x_hostname << "(" << x_num_clients << ")" << endl << flush;
  }
  delete[] name;
  name = NULL;
  return 0;
}


// NOTE: this daemon has to remember minimum_idletime even when it failed.
//       It may be added or revived again, then this info is needed. 
//       For now, we do not do it.
int
DaemonProcess::set_minimum_idletime(int intval) {
    if(status() == FAILURE_DETECTED) return 0;

    Header header;
    header.daemonMsgType(SET_INTERVAL);
    header.idleTime(intval);
    send_reply(header);
    return 1;
}

    
/*------------------------------------------------------------------------*/
int
DaemonProcess::reduce_processes(void) {

  assert(ObjectSpace::piranha_flag == 1);
  assert(0 < x_num_clients);

  for(int i=0; i < x_max_num_clients; i++){
    if(x_client[i] != 0 &&
       x_client[i]->transient_id() > 0 && 
       !x_client[i]->failure_detected() &&
       !x_client[i]->failure_handled() && 
       !x_client[i]->interactive()) {
      //cout << "DaemonProcess::reduce_processes is killing worker\n" << 
      //flush;
      Header header;
      header.daemonMsgType(KILL_WORKER);
      header.transientId(x_client[i]->transient_id());
      send_reply(header);
      x_client[i]->declare_failure();
    break;
    }
  }
  return x_num_clients;
}

/*------------------------------------------------------------------------*/

int 
DaemonProcess::send_reply(Header &header,const Tuple *tuple) {

  assert((header.tupleLength() == 0 && tuple == NULL) ||
	 (tuple && tuple->length() == header.tupleLength()));
  if(comm_link() == 0 || status() == FAILURE_DETECTED) {
     return -1;
  }

  if(comm_link()->send(header,tuple) == -1)  {
     declare_failure();
     return -1;
  }

  return 0;
}

// --------------------------------------------------
// printing
// --------------------------------------------------

String
DaemonProcess::print(void) const {
  String hold;
  hold = "daemon(";
  hold += Process::print();
  
  hold += ",host:";
  hold += x_hostname;
  
  // hold += ",inet:";
  // hold += dec(x_server_ip);

  // hold += ",port:";
  // hold += dec(x_server_port);
  
  hold += ",# clients:";
  hold += dec(x_num_clients);
  hold += ")";

  return hold;
}
  
  
/*--------------------------------------------------------------
  Information about the host on which this daemon is running is
  packed as an IO_pattern and returned.
  ------------------------------------------------------------*/
void
DaemonProcess::host_info(char *hostname,int &hostId,int &cpuLoad,
			 int &mainMem, int &maxClients, int &numClients,
			 int &stat)
{
  int len = ::strlen(x_hostname);
  if(len + 1 > MONITOR_STRLEN) {
    len = MONITOR_STRLEN -1;
    cout << "ERROR: PLinda only supports hostnames of length " <<
      MONITOR_STRLEN << " the host " << x_hostname << 
	"will not show up in the interface\n" << flush;
    cout << "To make this length greater, change MONITOR_STRLEN in the " <<
      "file common/config.h and do a make clean and then a make\n";
    cout << flush;
  }
  
  memcpy(hostname, x_hostname, len);
  hostname[MONITOR_STRLEN - 1] = 0;
   hostId = x_hostid;
   cpuLoad = x_cpu_load;
   mainMem = x_main_mem;
   maxClients = x_max_num_clients;
   numClients = x_num_clients;
   stat = status();
}

/*------------------------------------------------------------
  pack all the information regarding the host, the processes
  on this host and return as IO_pattern. you need to call this
  function "x_num_clients" times ONCE for each process.
  -----------------------------------------------------------*/

void
DaemonProcess::monitor_info(int c,int &id, char *exec, char *host,
			    char *file, int &lineNum, int &status){
   // PRECONDITION the char *'s have MONITOR_STRLEN elements allocated!!!

   assert(isValidClient(c));

   id = x_client[c]->identifier();

   const char* theExec = (char*)x_client[c]->executable();
   int len  = ::strlen(theExec);
   if(len+1 > MONITOR_STRLEN )
     len = MONITOR_STRLEN - 1;
   memcpy(exec, theExec, len);
   exec[MONITOR_STRLEN - 1] = 0;
   len = ::strlen(x_hostname);
   if(len+1 > MONITOR_STRLEN )
     len = MONITOR_STRLEN - 1;
   memcpy(host,x_hostname, len);
   host[MONITOR_STRLEN - 1] = 0;
   const char* f = x_client[c]->file();
   if(f == 0) 
      strcpy(file,"?");
   else {
      strcpy(file,f);
   }

   lineNum = x_client[c]->lineno();
   status = (int)x_client[c]->status();

}

/*------------------------------------------------------------
  handle_request will normally pickup any arbitrary eval_tuple
  (corresponding to a process to be run) and create a process
  on this host. but dispatch_client will pick a particular 
  eval tuple
  -----------------------------------------------------------*/
int 
DaemonProcess::spawn_process(){
    return  dispatch_client(SUPER_PROCID);
}
/*-----------------------------------------------------------*/
void 
DaemonProcess::dispatch_client(ClientProcess* proc){
    assert(proc);
    dispatch_client(proc->identifier());
}


int 
DaemonProcess::check_failure(void) {
    // not yet connected.
    if(status() == DISPATCHED) return 1;

    Header header;
    header.daemonMsgType(TEST_FAILURE);
    if(send_reply(header) == -1) 
      return -1;   
    return 1;
}


void 
DaemonProcess::declare_client_failure(void) {

   for(int i=0; i<x_max_num_clients; ++i) {
       if(x_client[i] != 0) {
         x_client[i]->declare_failure();
	 // due to interaction with the admin process,
	 // we need to destroy daemon objects immediately and
	 // so clean up processes here.
#ifdef PL_DEBUG
	 cout << "daemon process is killing all clients for failure\n" << flush;
#endif
         x_client[i]->handle_failure();
       }
   }

   ObjectSpace::scheduler.detect_failure();
}


void
DaemonProcess::declare_failure(void) {
   cerr << "> " << x_hostname << " failed !\n"; 
   cerr.flush();

   declare_client_failure();

   status(FAILURE_DETECTED);

   if(comm_link() != 0) {
     comm_link()->shutdown();
     comm_link(0);
   }
}


/*------------------------------------------------------------------------*/
// terminate this daemon.
void
DaemonProcess::terminate(void) {

  Header header;
  header.daemonMsgType(TERMINATE);
  send_reply(header);
  
  declare_client_failure();
  
  status(FAILURE_DETECTED);
  
  if(comm_link() != 0) {
    comm_link()->shutdown();
    comm_link(0);
  }
  
  ObjectSpace::scheduler.detect_failure();
}

void
DaemonProcess::kill_processes(void) {
  for(int i=0; i<x_max_num_clients; ++i) {
    if(x_client[i] != 0) {
      x_client[i]->kill();
    }
  }
}


void
DaemonProcess::kill_process(int transientId) {
  Header header;
  header.daemonMsgType(KILL_WORKER);
  header.transientId(transientId);
  send_reply(header);
}

/*------------------------------------------------------------------------*/
// kill this daemon.
void
DaemonProcess::kill(void) {
  char command[1000];
  extern const char *REMOTESH;  
  ::sprintf(command, "%s %s -l %s kill -9 %ld",REMOTESH, x_hostname, 
	    x_username,transient_id());
  cerr << command << "\n";
  ::system(command);
  
  cerr << "> terminate the daemon on " << x_hostname << "\n";
  cerr.flush();
}



