// This may look like C code, but it is really -*- C++ -*-
//
// File:     Process.C
// Created:  May 1, 1994
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu

#include <stdio.h>
#include <sys/types.h>
#include <assert.h>

// PLinda header files
#include "Process.h"

#ifdef _OUTLINE_
#define inline
#include "Process.iC"
#endif


procid 	Process::system_next_procid;


Process::Process(ProcessType ptype, procid id) 
: x_type(ptype), x_identifier(id) {
  // initialize local state
  x_transient_id = 0;
  x_status = EVALED;
  x_error = NO_ERROR;
  x_next_step = 0;
  x_comm_link = 0;
  x_temp_link_flag = 0;

  if(ObjectSpace::check_ft_degree(PRIVATE_SNAPSHOT)) {
    x_logging_mode = LOGGING_ON;
  } else {
    // MESSAGE_REPLAY & GLOBAL_SNAPSHOT  & NO_SUPPORT
    x_logging_mode = LOGGING_OFF;
  } 
  x_run_mode = RECORDING;
}

Process::~Process() {
  assert(x_comm_link == 0);
}


String
Process::print(void) const {
  String hold;
  hold = "(id:";
  hold += dec(identifier());
 
  hold += ",t-id:";
  hold += dec(transient_id());
 
  hold += ",status:";
  switch(status()) {
  case EVALED:
    hold += "EVALED";
    break;
  case DISPATCHED:
    hold += "DISPATCHED";
    break;
  case RUNNING:
    hold += "RUNNING";
    break;
  case REQUEST_READY:
    hold += "REQUEST_READY";
    break;
  case REQUEST_BLOCKED:
    hold += "REQUEST_BLOCKED";
    break;
  case TRANSACTION_ABORTED:
    hold += "TRANSACTION_ABORTED";
    break;
  case FAILURE_DETECTED:
    hold += "FAILURE_DETECTED";
    break;
  case FAILURE_HANDLED:
    hold += "FAILURE_HANDLED";
    break;
  case COMPLETED:
    hold += "COMPLETED";
    break;
  default:
    assert(0);
  }

  hold += ",next-step:";
  hold += dec(next_step());

  hold += ")";

  return hold;
}




