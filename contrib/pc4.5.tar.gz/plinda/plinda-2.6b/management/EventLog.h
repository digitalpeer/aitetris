
// This may look like C code, but it is really -*- C++ -*-
#ifndef _EVENT_LOG_H_
#define  _EVENT_LOG_H_

// These are definitions for errors.
#include <assert.h>
#include <stream.h>
#include <fstream.h>
#include <stdlib.h>

#include "plinda_ids.h"
#include "ErrorType.h"

#define event_log_file_name "PL.event.log"

class EventLog {
public:

  // ---------------------------------
  // constructor and destructor
  // ---------------------------------
  EventLog(void); // do nothing.

  virtual ~EventLog(void);


  // ---------------------------------
  // open, close and flush
  // ---------------------------------

  void open(const char* name);
  ofstream& get_log(void);
  void close(void);
  void flush(void);

  // -----------------------------------------
  // predicates
  // -----------------------------------------

  int fail() const;
  int operator !() const;

  void fatal(const char* f_name, const char* msg);

  // -----------------------------------------
  // reporting functions.
  // -----------------------------------------

  void error(const char* f_name, const char* msg);
  void messg(const char* f_name, const char* msg);

  // ---------------------------------------------
  // >> operator for the predefined data types
  // ---------------------------------------------

  void exit(int ret);

private:
  // the event log file
  ofstream event_log_file;

};

#ifndef _OUTLINE_
#include "EventLog.iC"
#endif

#endif // _EVENT_LOG_H_
