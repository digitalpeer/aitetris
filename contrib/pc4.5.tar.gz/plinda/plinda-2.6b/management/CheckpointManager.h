// This may look like C code, but it is really -*- C++ -*-
//
// File:        CheckpointManager.h
// Description: 
// Created:  
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//

#ifndef _CHECKPOINT_MANAGER_H_
#define _CHECKPOINT_MANAGER_H_

#include <sys/types.h>
#include <sys/stat.h>

#define DEFAULT_CHKPT_LEFT_DIR_NAME   "TS_chkpt_left"
#define DEFAULT_CHKPT_RIGHT_DIR_NAME  "TS_chkpt_right"
#define DEFAULT_CHKPT_HEADER_NAME     "TS_chkpt_header"

#include "plinda_ids.h"
#include "ErrorType.h"

// ACE 
#include "Reactor.h"

class CheckpointManager : public Event_Handler {
public:

  enum  ChkptDirType { ROOT_DIR, CHKPT_LEFT_DIR, CHKPT_RIGHT_DIR };

  struct ChkptHeader {
    int      head;
    procid   last_procid;
    physid   last_physid;
    transid  last_transid;
    gid      last_gid;
    int      tail;
  };

  // ------------------------------------------------------------
  // Constructor and Destructor
  // ------------------------------------------------------------
  CheckpointManager(const char* left_name=DEFAULT_CHKPT_LEFT_DIR_NAME, 
		    const char* right_name=DEFAULT_CHKPT_RIGHT_DIR_NAME,
		    const char* header_name=DEFAULT_CHKPT_HEADER_NAME);
  ~CheckpointManager(void);


  // ------------------------------------------------------------
  // open and close
  // ------------------------------------------------------------

  ErrorType open(int recovery_flag);
  ErrorType close(void);


  // ------------------------------------------------------------
  // checkpoint the current state of tuple space. 
  // ------------------------------------------------------------

  virtual int handle_timeout(const Time_Value&, const void*);
  ErrorType checkpoint(void);

  
  // ------------------------------------------------------------
  // enable/disable checkpointing 
  // ------------------------------------------------------------
  ErrorType enable(void);
  ErrorType disable(void);


  // ------------------------------------------------------------
  // rollback to the last checkpointed state.
  // ------------------------------------------------------------

  ErrorType rollback(void);

  // in rollback, need to restore information about the identifiers.
  procid          get_last_procid(void);
  const transid&  get_last_transid(void);
  const physid&   get_last_physid(void);
  const gid&      get_last_gid(void);


  // ------------------------------------------------------------
  // change the current directory
  // ------------------------------------------------------------

  // move to the directory where the server is called.
  int change_to_working_dir(void);
  // move to the directory for the next checkpoint.
  int change_to_next_dir(void);		
  // move to a specific directory, one of root, left and right.
  int change_dir(ChkptDirType);

  // current location.
  ChkptDirType current_dir(void) const;
  // the directory for the next checkpoint.
  ChkptDirType next_chkpt_dir(void) const;
  // the directory for the last checkpoint.
  ChkptDirType last_chkpt_dir(void) const;

  // ----------------------------------------------------------
  // status of the last checkpoint directory
  // ----------------------------------------------------------
  int chkpt_dir_status(void) const;

private:

  // ------------------------------------------------------------
  // Checkpoint Header
  // ------------------------------------------------------------

  // size of the header
  int chkpt_header_size(void) const;
  
  // recover the header.
  int recover_chkpt_header(void);

  int alternate_chkpt_dir(void);

  // load the header of a checkpoint directory.
  int load_chkpt_header(int& flag, unsigned long& mtime, 
			const char* name, ChkptHeader& header);

  // check if a header is valid.
  int check_for_header_validity(ChkptHeader& header) const;
  
  // create the header for the current state.
  int create_chkpt_header(ChkptHeader& header);

  // store a checkpoint header.
  int store_chkpt_header(const char* name, ChkptHeader& header) const;


  // -----------------------------------------------------------------
  // activation flag
  // -----------------------------------------------------------------
  int x_activation_flag;

  // -----------------------------------------------------------------
  // pointer to the directory that contains the latest checkpoint 
  // -----------------------------------------------------------------
  ChkptDirType x_last_chkpt_dir;

  // the current working directory
  ChkptDirType x_current_dir;

  int x_chkpt_dir_status;		// zero means empty.

  // checkpoint header
  ChkptHeader x_chkpt_header;



  // ----------------------------------------------------------
  // pointers to two checkpoint directories.        
  // ----------------------------------------------------------

  int x_root_dir;
  int x_left_dir;
  int x_right_dir;

  // directory and header names
  char x_root_dir_name[1000];
  char x_left_dir_name[1000];
  char x_right_dir_name[1000];
  // header file
  char x_header_name[1000];

};

#ifndef _OUTLINE_
#include "CheckpointManager.iC"
#endif // 

#endif // _CHECKPOINT_MANAGER_H_
