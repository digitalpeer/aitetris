// This may look like C code, but it is really -*- C++ -*-
//
// File:        Process.h
// Description:	Base class for objects that represent various 
//              running processes. 
// Created:  
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//

#ifndef _PROCESS_H_
#define _PROCESS_H_

// ACE headers

// GNU
#include <Pix.h>

// PLinda header files & forward declaration
#include "plinda_ids.h"
#include "ErrorType.h"
#include "Tuple.h"
#include "TupleHandle.h"

class ServerCommLink;
class TupleGroup;
class Transaction;
class Header;

class Process {

public:
#ifdef __GNUG__
  enum ProcessType { CLIENT , DAEMON , MONITOR, 
		     ADMINISTRATION, DEBUGGER, SERVER };
#else
  enum ProcessType { PLINDA_CLIENT , DAEMON , MONITOR, 
		     ADMINISTRATION, DEBUGGER, SERVER };
#endif
  enum StatusType { EVALED = 0, DISPATCHED = 1, RUNNING = 2, 
		    SLEEPING = 3, REQUEST_READY = 4, REQUEST_BLOCKED = 5, 
                    TRANSACTION_ABORTED = 6, FAILURE_DETECTED = 7, 
		    FAILURE_HANDLED = 8, ERROR_FOUND = 9, COMPLETED = 10 };
  enum LoggingModeType { LOGGING_ON, LOGGING_OFF };
  enum RunModeType { RECORDING, REPLAYING };

  // ---------------------------------------------------
  // Identity and State             
  // ---------------------------------------------------

  // CONSTRUCTOR: process type and identifier should be 
  // decided at construction time.
  Process(ProcessType, procid); 

  ProcessType type(void) const;
  procid identifier(void) const;
  StatusType status(void) const;
  void status(StatusType);

  void error(ErrorType);
  ErrorType error(void) const;

  // 
  static procid get_last_procid(void);
  static procid get_next_procid(void);
  static void   set_last_procid(procid);

  // in the current design, it is possible that more than one application 
  // process can have the same identifier, and so their OS pids are used 
  // to distinguish them.
  long transient_id(void) const;

  // ServerCommLink should be destroyed by the time this destructor is called.
  virtual ~Process(void);

  // predicate functions to check the status.
  int alive(void) const;
  int completed(void) const;
  int failure_detected(void) const;
  int failure_handled(void) const;
  int transaction_aborted(void) const;
  int error_found(void) const;
  virtual int about_to_end(void) { return 0; }

  // comm link must exist when the following two functions are called.
  // int local(void) const;
  // int remote(void) const;

  
  // ---------------------------------------------------------
  // Communication Link
  // ---------------------------------------------------------

  ServerCommLink* comm_link(void);
  void comm_link(ServerCommLink*);

  // such processes as DaemonProcesses want only temporary connections.
  int temp_link_flag(void);
  void set_temp_link_flag(void);

  // used when ServerCommLink objects pass received messages.
  virtual void enqueue_request(Header*, Tuple *) =0;
  // used when Process objects read the messages.
  // this function is supposed to convert the message format 
  // from CommLinkMessage to Message.
//  virtual Message* dequeue_request(void) =0;


  // ----------------------------------------------------------
  // Scheduler
  // ----------------------------------------------------------
  
  // used when Scheduler checks 
  // if this process object has a request to process
  virtual int ready(void) =0;
  virtual int handle_request(void) =0;

  // in no use for now, because a reply is sent immediately when ready.
  virtual int ready_reply(void) { assert(0);  return 1;}
  virtual int handle_reply(void) { assert(0);   return 1; }



  // ----------------------------------------------------------------
  // THREADS:
  // Process objects are supposed to handle requests repeatedly. 
  // During execution, they may need to wait for some events to take place. 
  // In this case, they call the member function 'block' and sleep until 
  // the member function 'resume' is called. Hee, what is important is 
  // to restore the local state when resuming execution. 
  // Basically, we need to remember the two types of information: where 
  // to restart and what local variables to save.
  // Regarding the first information, we provide a data member, called
  // x_next_step, which records the location of the next statement.
  // Derived classes are supposed to decide what local variables to save
  // and how to do it.
  // ----------------------------------------------------------------

  // for TupleGroup
  virtual int block(int, TupleGroup*, Pix) =0;
  virtual int resume(const TupleGroup*, const TupleHandle&, Tuple *) =0;

  // for Transaction
  virtual int block(int, const Transaction*) { assert(0);  return 1;}
  virtual int resume(const Transaction*)  { assert(0);  return 1;}

  // for ServerCommLink
  virtual int block(int, const ServerCommLink*) { assert(0); return 1;}
  virtual int resume(const ServerCommLink*)   { assert(0); return 1;}

  // ------------------------------------------------------
  // for failure detection and reaction against failure.
  // ------------------------------------------------------

  // check if processes are alive.
  virtual int check_failure(void) =0; 
  virtual void declare_failure(void) =0;

  // if there is a program error in a process, 
  // then we just remove the process instead of restarting it. 
  virtual void declare_error(ErrorType) =0;

  // abort active transactions started by failed processes.
  // recreate an eval tuple.
  virtual void handle_failure(void) =0;

  // ---------------------------------------------------
  // Identity and State             
  // ---------------------------------------------------

  LoggingModeType logging_mode(void) const;
  void logging_mode(LoggingModeType lmode);

  RunModeType run_mode(void) const;
  void run_mode(RunModeType lmode);

  // ---------------------------------------------------
  // print 
  // ---------------------------------------------------
  
  virtual String print(void) const;


protected:

  // ---------------------------------------------------
  // Identity and State             
  // ---------------------------------------------------

  void transient_id(long);

  // ---------------------------------------------------
  // THREADS
  // ---------------------------------------------------

  int  next_step(void) const;
  void next_step(int);

  // ---------------------------------------------------
  // Communication Link
  // ---------------------------------------------------  


private:

  static procid    system_next_procid;

  // ---------------------------------------------------
  // Identity and State             
  // ---------------------------------------------------

  const ProcessType x_type;
  const procid      x_identifier;
  long              x_transient_id;
  StatusType 	    x_status;
  LoggingModeType   x_logging_mode;
  RunModeType       x_run_mode;
  ErrorType	    x_error;

  // ---------------------------------------------------
  // THREADS
  // ---------------------------------------------------

  int x_next_step;

  // ---------------------------------------------------
  // Communication Link
  // ---------------------------------------------------  

  ServerCommLink* x_comm_link;
  int x_temp_link_flag;

};

#ifndef _OUTLINE_
#include "Process.iC"
#endif

#endif // _PROCESS_H_
