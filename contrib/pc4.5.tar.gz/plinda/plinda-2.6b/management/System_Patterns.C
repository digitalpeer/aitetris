// This may look like C code, but it is really -*- C++ -*-
//
// File:     System_Patterns.C
// Created:
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//

#include "plinda_ids.h"
#include "System_Patterns.h"
#include "Tuple.h"
#include "TupleHandle.h"
#include "Machine.h"

#ifndef __GNUG__
#include <string.h>
#endif
// ---------------------------------------------------------------------------
// the pattern of an eval tuple is 
// (procid, 
//  parent's procid, 
//  name of exec-file, 
//  gid of the private log group,
//  physid of its argument tuple,
//  retry #,
//  interactive)
//

Tuple *
create_eval_tuple(procid id,  procid parent_id, const char* name,
		  const gid& log_id, const physid& arg_id,
		  long retry, int interactive) 
{
   int len = ::strlen(name) + 1;
   Tuple *t = Tuple::create(7, len * PL_CHAR_SZ);

   t->setActual(0,TupleField::PLlong, (long)id);
   t->setActual(1,TupleField::PLlong , (long)parent_id);
   t->setActual(2,TupleField::PLchar, name, len);
   t->setActual(3,TupleField::PLgid, log_id);
   t->setActual(4,TupleField::PLphysid, arg_id);
   t->setActual(5,TupleField::PLlong, (long)retry);
   t->setActual(6,TupleField::PLint, interactive);
   return t;
}


// -----------------------------------------------------------------------
// IO_pattern to be used to retrieve the proc tuple 
// either for a certain process or for a randome one.
   static long lValueProcId = 0;
   static long lValueParentId = 0;
   static char lValueName[100]; 
   static gid lValueGid = zero_gid;
   static physid lValuePhysid = zero_physid;
   static long lValueRetry = 0;
   static int lValueInteractive = 0;
   // these statics will be read by read_eval_tuple

Tuple *
create_eval_tuple_pattern(procid id) 
{
   Tuple *t = Tuple::create(7,0);
   

   if(id != 0) 
     t->setActual(0,TupleField::PLlong, (long)id);
   else
     t->setFormal(0,TupleField::PLlong, &lValueProcId);
   t->setFormal(1,TupleField::PLlong, &lValueParentId);
   t->setFormal(2,TupleField::PLchar, lValueName, 100);
   t->setFormal(3,TupleField::PLgid, &lValueGid);
   t->setFormal(4,TupleField::PLphysid, &lValuePhysid);   
   t->setFormal(5,TupleField::PLlong, &lValueRetry);
   t->setFormal(6,TupleField::PLint, &lValueInteractive);
   return t;
}



// --------------------------------------------------------------------------
// get the contents of the fields of an eval tuple.
//

int
read_eval_tuple(Tuple* retrievedTuple, Tuple *origTuple,
		procid& id, procid& parent_id, 
		const char*& name,gid& log_id,	physid& arg_id,
		long& retry,int& interactive) 
{
   assert(origTuple);
   assert(retrievedTuple);
   assert(retrievedTuple->allActuals());
   origTuple->bindFormals(*retrievedTuple);
   // this fills in those static vars from before
   retrievedTuple->read(0,TupleField::PLlong, (long&)id);
   // read this right from the tuple since it may have been an actual
   parent_id = lValueParentId;
   log_id = lValueGid;
   arg_id = lValuePhysid;
   retry = lValueRetry;
   interactive = lValueInteractive;
   name = new char[strlen(lValueName) + 1];
   strcpy((char*)name, lValueName);
   return 1;
}
   

// --------------------------------------------------------------------------
// get the name of execfile from an arg tuple.
//
const char*
read_name_from_arg(Tuple* e_tuple) {
   char* str = new char[100];
   e_tuple->read(0, TupleField::PLchar, str, 100);
   return str;
} 
 

// --------------------------------------------------------------------------
// create a catalog entry tuple
//

Tuple *
create_catalog_tuple(const gid& g, const char* name) {
   int len = ::strlen(name) + 1;
   Tuple *t = Tuple::create(3, len * PL_CHAR_SZ);
   t->setActual(0,TupleField::PLchar, '?');
   t->setActual(1,TupleField::PLgid, g);
   t->setActual(2,TupleField::PLchar, name, PL_CHAR_SZ * len);
   return t;
}

// -----------------------------------------------------------------------
// IO_pattern to be used to retrieve the catalog entry tuple 
// either for a certain tuple group or for a random process.
//
static gid lValueCatGid = zero_gid;
static char lValueCatChar[100];

Tuple *create_catalog_tuple_pattern(const gid& g) 
{
   Tuple *t = Tuple::create(3,0);
   t->setActual(0,TupleField::PLchar, '?');
   if(g != zero_gid) 
    t->setActual(1,TupleField::PLgid, g);
   else
     t->setFormal(1,TupleField::PLgid, &lValueCatGid);
   t->setFormal(2,TupleField::PLchar, lValueCatChar,100);
  return t;
}


int
read_catalog_tuple(Tuple *retrievedTuple,Tuple* e_tuple, gid& id, 
		   const char*& name) {
   e_tuple->bindFormals(*retrievedTuple);
   id = lValueCatGid;
   name = new char[strlen(lValueCatChar) + 1];
   strcpy((char*)name,lValueCatChar);
   return 1;
}
   

// -----------------------------------------------------------------------
// IO_pattern to be used to retrieve the main program tuple 
//

Tuple *
create_main_prgm_tuple(const char* name) {
  int len = ::strlen(name) + 1;
  Tuple *t = Tuple::create(1, len * PL_CHAR_SZ);
  t->setActual(0,TupleField::PLchar, name,len);
  return t;
}
