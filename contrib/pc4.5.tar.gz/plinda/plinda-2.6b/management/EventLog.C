// This may look like C code, but it is really -*- C++ -*-
//
// File:     EventLog.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//

#include <fstream.h>

#include "EventLog.h"

#ifdef _OUTLINE_
#define inline
#include "EventLog.iC"
#endif


// ---------------------------------
// constructor and destructor
// ---------------------------------
EventLog::EventLog(void) {
  // event_log_file.open(event_log_file_name, ios::out);
}

void
EventLog::open(const char* name) {
  event_log_file.open(name, ios::out);
}

ofstream&
EventLog::get_log(void) {
  return event_log_file;
}

void
EventLog::close(void) {
  event_log_file.close();
}

void
EventLog::flush(void) {
  event_log_file.flush();
}

EventLog::~EventLog(void) {
  event_log_file.flush();
}
