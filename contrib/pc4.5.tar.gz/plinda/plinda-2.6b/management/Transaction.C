// This may look like C code, but it is really -*- C++ -*-
//
// File:     Transaction.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//

// PLinda include files

#include "TupleGroup.h"
#include "Transaction.h"
#include "ObjectSpace.h"
#include "ProcessManager.h"
#include "LogManager.h"

// next transaction identifier.
transid Transaction::system_next_transid;

Transaction::Transaction(const Process *p, const transid &t) 
: x_proc(p)
{
  assert(p);
  x_identifier = t;
  x_status = ACTIVE;
  x_eval_list.clear();
  x_out_tuples.clear();
  x_in_tuples.clear();
  x_created_groups.clear();
  x_destroyed_groups.clear();
}

Transaction::~Transaction(void) {
  x_eval_list.clear();
  x_out_tuples.clear();
  x_in_tuples.clear();
  x_created_groups.clear();
  x_destroyed_groups.clear();  
}

int 
Transaction::check_for_committability() const {
  return(x_status != ABORTED && x_status != COMMITTED);
}

void
Transaction::commit() {

  while(!x_eval_list.empty()) {
    Tuple *t = x_eval_list.remove_front();
    assert(t);
    ObjectSpace::proc_mgr.spawn_PROCESS(x_proc, t,0);
  }

  while(!x_out_tuples.empty()) {
    TupleHandle tuple = x_out_tuples.remove_front();
    assert(tuple.tuple_group());
    assert(tuple.tuple());
    tuple.tuple_group()->insert_tuple(tuple,tuple.tuple(),
				      tuple.identifier());
    // if it is a log tuple it may already have a gid
    // This is also inserting tuples into the catalog group
    // if the above was an out into the catalog group
  }

  while(!x_in_tuples.empty()) {
    TupleHandle tuple = x_in_tuples.remove_front();
    Tuple* t = tuple.tuple();
    if(t->readers() == 0)
      Tuple::destroy(t);
    else
      t->setInned();
  }
    
  while(!x_rd_tuples.empty()) {
    TupleHandle tuple = x_rd_tuples.remove_front();
    Tuple* t = tuple.tuple();
    t->decrementReaders();
    assert(t->readers() >= 0);
    if(t->readers() == 0 && t->inned())
      Tuple::destroy(t);
  }

  
  while(!x_created_groups.empty()) {
    TupleGroup* group = x_created_groups.remove_front();
    group->commit_creation();
  }

  while(!x_destroyed_groups.empty()) {
    assert(0); // this should be done on the client side
//    TupleGroup* group = x_destroyed_groups.remove_front();
//    group->commit_destruction();
  }

  status(COMMITTED);
}
  
void
Transaction::abort() {
  while(!x_eval_list.empty())  {
    Tuple *t = x_eval_list.remove_front();
    assert(t);
    Tuple::destroy(t);
  }

  while(!x_out_tuples.empty()) {
    TupleHandle tuple = x_out_tuples.remove_front();
    Tuple* t = tuple.tuple();
    Tuple::destroy(t);
  }

  while(!x_in_tuples.empty()) {
     TupleHandle tuple = x_in_tuples.remove_front();
     assert(tuple.identifier() != zero_physid);
     assert(tuple.tuple());
     assert(tuple.tuple()->inned() == 0);
     (tuple.tuple_group())->insert_tuple(tuple, tuple.tuple(),
					 tuple.identifier());

  }
  while(!x_rd_tuples.empty()) {
    TupleHandle tuple = x_rd_tuples.remove_front();
    Tuple* t = tuple.tuple();
    t->decrementReaders();
    assert(t->readers() >= 0);
    if(t->readers() == 0 && t->inned())
      Tuple::destroy(t);
 }


  while(!x_created_groups.empty()) {
    TupleGroup* group = x_created_groups.remove_front();
    group->abort_creation();
  }
  //
  while(!x_destroyed_groups.empty()) {
    assert(0); // only done on client side
    TupleGroup* group = x_destroyed_groups.remove_front();
    group->abort_destruction();
  }
  status(ABORTED);
}


void 
Transaction::access_tuple(TupleGroup *group,const TupleHandle &tuple_handle,
			  Tuple::OpType opType)
{
  assert(tuple_handle.tuple());
  switch(opType) {
   case Tuple::OUT:
     x_out_tuples.append(tuple_handle);
     break;
   case Tuple::IN:
     assert(tuple_handle.tuple());
     x_in_tuples.append(tuple_handle);
     assert(group && tuple_handle.tuple());
     assert(tuple_handle.tuple()->identifier() != zero_physid);
     {
	Tuple *temp = group->delete_tuple(tuple_handle.tuple()->identifier());
	assert(temp == tuple_handle.tuple());
     }
     break;
   case Tuple::RD:
     assert(tuple_handle.tuple());
     tuple_handle.tuple()->incrementReaders();
     x_rd_tuples.append(tuple_handle);
     break;
   default:
     assert(0);
  };
}
    
// we do not need to log process creation and group creation
// because we can reconstruct such informtion 
// from the proc group and the catalog group


String
Transaction::print(void) {
  String h = "Transaction";
  return h;
}

