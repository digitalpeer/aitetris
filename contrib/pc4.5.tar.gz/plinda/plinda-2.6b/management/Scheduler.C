// This may look like C code, but it is really -*- C++ -*-
//
// File:     Scheduler.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//

// *** GNU stuff ***
#include <iostream.h>
#include <SLList.h>
#include "C_Interface.h"

#include "Process.h"
#include "MonitorProcess.h"
#include "Scheduler.h"
#include "ProcessManager.h"
#include "ObjectSpace.h"
#include "CheckpointManager.h"
#include "EventLog.h"
#include "Snapshot.h"


#ifdef _OUTLINE_
#define inline
#include "Scheduler.iC"
#endif // _OUTLINE_


#ifdef  AUTO_FAULT_MODE
#include "FaultLevelManager.h"
#endif

Scheduler::Scheduler() {
  failure_detection_flag = 0;
  closedown_flag = 0;
  x_scheduling_mode = REGULAR_SCHEDULING;
}


// ----------------------------------------------------------------------
// this function is called when the communication layer
// detects process failure, so that the failure can be immediately
// handled.
// ----------------------------------------------------------------------
void
Scheduler::detect_failure(void) {
  failure_detection_flag = 1;
}

// -----------------------------------------------------------------------
// this function is called to take a global snapshot of the entire system
// including the client processes. once a global snapshot is completed,
// the server state is globally consistent with all the clients.
// then checkpointing can be performed.
// ------------------------------------------------------------------------
void
Scheduler::activate_chkpt(void) {
  if(x_scheduling_mode == GSNAPSHOT_SCHEDULING) {
    return;
  }

  x_scheduling_mode = GSNAPSHOT_SCHEDULING;
  ObjectSpace::proc_mgr.activate_gsnapshot();
}


// Scheduler::main_loop is the main driver routine of the PLinda server.
// The tasks of the function are:
// (1) activates the communication manager to check if messages
//     have been arrived on connections;
// (2) let process objects handle requests received if any;
// (3) ask process objects to check if their processes are still alive,
//     when the failure detection mode is activated;
// (4) let process objects send replies to their processes.
int
Scheduler::event_loop() {
//  Pix cur;

  while(1){


    if (ObjectSpace::state() == ObjectSpace::SHUTDOWN_SERVER) break;

    // ---------------------------------------------------------------------
    // if there are no more running process, then we terminate the server.
    // ---------------------------------------------------------------------
    if(ObjectSpace::proc_mgr.num_processes() == 0 && 
       ObjectSpace::batch_flag == 1) {
      break;
    }


    // ---------------------------------------------------------------------
    // schedule for global snapshot.
    // ---------------------------------------------------------------------
    if(x_scheduling_mode == REGULAR_SCHEDULING) {
      // let processes handle requests
      // we do not necessarily need to iterate 
      // over all the process objects, but we are doing it now.
       ObjectSpace::proc_mgr.schedule();
    }


    // ---------------------------------------------------------------------
    // schedule for global snapshot.
    // ---------------------------------------------------------------------
    if(x_scheduling_mode == GSNAPSHOT_SCHEDULING) {
      // global snapshot is only activated 
      // under GLOBAL_SNAPSHOT or MESSAGE_REPLAY
#ifndef AUTO_FAULT_MODE
    // In AUTO_FAULT_MODE case, we also allow private_snapshot mode to
       // change mode to global snapshot
      assert(ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT) ||
	     ObjectSpace::check_ft_degree(MESSAGE_REPLAY)); 
#endif
      // schedule
      ObjectSpace::proc_mgr.schedule_for_gsnapshot();

      // check if global snapshot is completed.
      if(ObjectSpace::snapshot_mgr.finished()) {
	if(!ObjectSpace::chkpt_mgr.checkpoint()) {
	  ObjectSpace::event_log.messg("CheckpointManager", "checkpoint");
	}
	x_scheduling_mode = REGULAR_SCHEDULING;
	ObjectSpace::snapshot_mgr.deactivate();
#ifdef AUTO_FAULT_MODE
	ObjectSpace::ftlvl_mgr.set_new_ft_level();
#endif
      }
    } 


    // ------------------------------------------------------------------
    // check on connections. 
    // ------------------------------------------------------------------
    Time_Value timeout(ObjectSpace::link_default_timeout);
    int num = ObjectSpace::comm_mgr.handle_events(timeout);
    if(num == 0) {
      // no request received, and good time to flush the log buffers
      // or checkpoint tuple space.
    }


    // --------------------------------------------------------------------
    // check if each process is alive.
    // --------------------------------------------------------------------
    if(failure_detection_flag) {
      if(ObjectSpace::proc_mgr.handle_failure() > 0) {

	if(ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT)) {
	  // kill processes.
	  ObjectSpace::proc_mgr.terminate();

	  cerr << "> error: can't recover from process failure "
	       << "under global snapshot mode !\n";
	  cerr << "         please restart the server with -r option.\n";
	  ::exit(1);

	} else if(ObjectSpace::check_ft_degree(NO_SUPPORT)) {
	  ObjectSpace::proc_mgr.terminate();
	  cerr << "> error: can't recover from process failure "
	       << "under no fault-tolerance mode !\n";
          ::exit(1);
	}
      }

      failure_detection_flag = 0;
    }

  } // while
  return 1;
}







