// This may look like C code, but it is really -*- C++ -*-
//
// File:       Transaction.h
// Description 
// Created:  
// Author:     Karp Joo Jeong
// Mail:       jeong@cs.nyu.edu
//

#ifndef _TRANSACTION_H_
#define _TRANSACTION_H_

// GNU stuff
#include "GNU_Interface.h"
#include "TransactionManager.h" // just to make it a friend

// forward declaration
class ClientProcess;
class TupleGroup;

class Transaction {
friend TransactionManager::checkpoint(void);
public:
  enum StatusType {    ACTIVE,   COMMITTED,   ABORTED   };
  
  Transaction(const Process *p,const transid &t);
  virtual ~Transaction(void);
  StatusType status(void) const { return x_status ; }

  static const transid& get_last_transid(void) { return system_next_transid;}
  static const transid& get_next_transid(void) { return ++system_next_transid;}
  static void  set_last_transid(const transid& tid) {system_next_transid=tid;}
  const transid& identifier(void) const { return x_identifier; };

  int check_for_committability() const;
  void commit();
  void abort();
  const Process *process() const { return x_proc; }
  void access_tuple(TupleGroup *group,const TupleHandle &tuple, 
		    Tuple::OpType opType);
  void create_group(TupleGroup* g) {   x_created_groups.append(g); }
  void destroy_group(TupleGroup*) { assert(0); }

  // transactional process creation 
  void eval_tuple(Tuple *eval) {   x_eval_list.append(eval); }

  String print(void);
protected:
  void status(StatusType stat) { x_status = stat; }

private:
  static transid system_next_transid;

  // identifier
  transid x_identifier; 

  // status
  StatusType x_status;

  const Process* x_proc;

  TuplesList x_eval_list;
  TupleHandleList x_out_tuples;  
  TupleHandleList x_in_tuples;
  TupleHandleList x_rd_tuples;
  TupleGroupList x_created_groups;
  TupleGroupList x_destroyed_groups;
};

#endif // _TRANSACTION_H_
