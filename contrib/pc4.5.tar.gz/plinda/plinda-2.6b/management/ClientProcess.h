// This may look like C code, but it is really -*- C++ -*-
//
// File:     ClientProcess.h
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//
#ifndef _CLIENT_PROCESS_H_
#define _CLIENT_PROCESS_H_


// ACE headers

// PLinda header files & forward declarations
#include "plinda_ids.h"
#include "ErrorType.h"
#include "plinda_requests.h"
#include "Process.h"
#include "TupleHandle.h"
//#include "Replay.h"
#include "CheckpointManager.h"
#include "Header.h"

class ServerCommLink;
class DaemonProcess;
class Transaction;

// GNU
#include "GNU_Interface.h"


// ------------------------------------------------------------
// Private log size limit: 
// up to one mega bytes, we keep private log in memory. 
// ------------------------------------------------------------

const int PL_MAX_IN_MEMORY_LOG_SZ = 5000000;



class ClientProcess : public Process {

public:

  // --------------------------------------------------
  // CONSTRUCTOR and DESTRUCTOR
  // --------------------------------------------------

  ClientProcess(procid my_pid, procid parent_pid, const physid& arg,int interactive);
  virtual ~ClientProcess(void);

  void daemon_process(DaemonProcess* dproc);
  DaemonProcess* daemon_process(void);
  int interactive() const { return interactive_; }
  // --------------------------------------------------
  // used for debugging purposes ...
  // --------------------------------------------------
  void executable(const char*);
  const char* executable(void) const;
  const char* file(void) const;
  void file(const char* name);
  unsigned lineno(void) const;
  void lineno(unsigned) ;


  // --------------------------------------------------
  // Communication Link
  // --------------------------------------------------

  // overwritten virtual functions.
  virtual void enqueue_request(Header*,Tuple*); 
//  virtual Message* dequeue_request(void) {assert(0);  return NULL;}
  void destroy_current_request();

  HeaderAndTuple current_request(void) const;  
  void current_request(HeaderAndTuple);


  // --------------------------------------------------
  // Scheduler
  // --------------------------------------------------

  // overwritten virtual functions.
  virtual int about_to_end(void);
  virtual int ready(void);
  virtual int handle_request(void);
  int xcommit();
  // request type
  ClientRequest request_type(void) const;


  // ---------------------------------------------------
  // Tuple Groups
  // ---------------------------------------------------

  void close_groups(void);

  // ---------------------------------------------------
  // Argument Tuple and Private Log
  // ---------------------------------------------------

  const physid& arg_id(void) const;

  int log_flag(void) const;
  void set_log_flag(void);
  int in_file(void) const;
  void set_in_file(void);

  CheckpointManager::ChkptDirType cur_log_dir(void) const;
  void cur_log_dir(CheckpointManager::ChkptDirType);

  CheckpointManager::ChkptDirType last_log_dir(void) const;
  void last_log_dir(CheckpointManager::ChkptDirType);

  // check if the log exists in the last checkpoint directory.
  int restore_private_log(void);
  int checkpoint_private_log(void);

  // load private log from/store to a file.
  int load_private_log(CheckpointManager::ChkptDirType);
  int store_private_log(CheckpointManager::ChkptDirType);

  // --------------------------------------------------
  // Threads
  // --------------------------------------------------

  virtual int block(int, TupleGroup*, Pix);
  virtual int resume(const TupleGroup*, const TupleHandle&, Tuple*);
  
  // -------------------------------------------------
  // Forced Termination
  // -------------------------------------------------

  void kill(void);
  void terminate(void);

  // --------------------------------------------------
  // Failure Detection and Reaction 
  // --------------------------------------------------

  // overridden virtual functions.
  virtual int check_failure(void);
  virtual void declare_failure(void);
  virtual void handle_failure(void);

  virtual void declare_error(ErrorType);
  void handle_error(void);

  void cleanup_state(void);
  void remove_persistent_identity(void);

  // --------------------------------------------------------
  // Snapshot: (0: snapshot for global snapshot, 
  //            1: snapshot for flushing the message log)
  // --------------------------------------------------------
  int request_psnapshot(int=0);

  // inconsistent snapshot in the server ?
  int inconsistent(void) const;

  // ---------------------------------------------------
  // For debugging/program stepping purposes .....
  // ---------------------------------------------------
  void normal_mode(void);
  void single_step(int num_steps=1);

  // ---------------------------------------------------
  // Printing
  // ---------------------------------------------------

  virtual String print(void) const;

protected:

  // ---------------------------------------------------
  // Transactions
  // ---------------------------------------------------

  Transaction* trans(void) const;
  void trans(Transaction*);


  // ---------------------------------------------------
  // Tuple Groups
  // ---------------------------------------------------

  // list of the tuple groups that this process opens.
  TupleGroup* find_group(const gid&);


  // ---------------------------------------------------
  // Argument Tuple and Private Log
  // ---------------------------------------------------

  void arg_id(const physid&);  


  // ---------------------------------------------------
  // Scheduler
  // ---------------------------------------------------

  // int request_available(void);
  

  // ---------------------------------------------------
  // Reply to Requests
  // ---------------------------------------------------

  int send_reply(Header&,const Tuple * = NULL);
//  ClientMessage* make_reply(ClientRequest, int);


  // ---------------------------------------------------
  // error checking 
  // ---------------------------------------------------

  ErrorType check_for_errors(const Header &,const Tuple *);
private:
  const int interactive_;
  DLList<Tuple*> outList;
  // ---------------------------------------------------
  // what executable is this process running...?
  // ---------------------------------------------------
  char*  x_exec_name;

  // ---------------------------------------------------
  // Those who have created this process
  // ---------------------------------------------------

  procid x_parent_id;
  DaemonProcess* x_daemon_proc;

  // ---------------------------------------------------
  // Current Transaction
  // ---------------------------------------------------

  Transaction* x_trans;
  Transaction* x_temp_trans;  // when this process runs no transaction.

  // if there is a temporary transaction created, then commit or abort it.
  Transaction* start_temp_trans(void);
  void commit_temp_trans(void);
  void abort_temp_trans(void);

  // ---------------------------------------------------
  // Blocking
  // ---------------------------------------------------

  Pix 		x_blk_request;
  TupleGroup* 	x_blk_group;

  // ---------------------------------------------------
  // Communication Link and Scheduler
  // ---------------------------------------------------

  // CommLinkMessage* x_message;
  HeaderAndTuple x_cur_request;

  HeaderAndTuple x_next_request;
  int x_n_step;
  HeaderAndTuple x_blocked_request;
  int x_b_step;

  // ---------------------------------------------------
  // THREADS
  // these data members are for simulation of threading.
  // ---------------------------------------------------

  TupleHandle x_tuple_handle;

  // ---------------------------------------------------
  // Argument tuple and Private Log
  // ---------------------------------------------------

  physid x_arg_id;

  // a single tuple for private log 
  // which is stored either in main memory or in a file.
  int x_in_file;  // location
  int x_log_flag; // existence.
  Tuple* x_private_log;
  int x_flush_flag;
  int x_inconsistency_flag;

#ifdef AUTO_FAULT_MODE
  int x_continuation_size;
#endif
  // which directory 
  CheckpointManager::ChkptDirType x_cur_log_dir;
  CheckpointManager::ChkptDirType x_last_log_dir;

  // ---------------------------------------------------
  // opened groups
  // ---------------------------------------------------
  TupleGroupList x_group_list;

  // ---------------------------------------------------
  // Replaying
  // ---------------------------------------------------
//  ExecutionHistory x_history;

  // ---------------------------------------------------
  // store the last request for monitoring purposes ..
  // ---------------------------------------------------

  //---------------------------------------------------
  // the file name and line number of the last plinda
  // operation processed by the server for this client.
  // ---------------------------------------------------
  char*        x_file;
  unsigned     x_lineno;

  //---------------------------------------------------
  // Needed for single stepping the execution. If 
  // x_single_stepping is non-zero, then x_steps_to_run
  // will tell how many steps this proc. can run before 
  // it is blocked.
  //---------------------------------------------------
  int     x_steps_to_run;
  int     x_single_stepping;
  int     steps_to_run(void) const;
  void    execute_next_step(void);
  int     single_stepping(void) const;


};

#ifndef _OUTLINE_
#include "ClientProcess.iC"
#endif

#endif // _CLIENT_PROCESS_H_
