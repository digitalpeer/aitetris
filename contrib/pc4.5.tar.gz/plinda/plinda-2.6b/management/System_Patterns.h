// This may look like C code, but it is really -*- C++ -*-
//
// File:     System_Patterns.h
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu

#ifndef _SYSTEM_PATTERNS_H_
#define _SYSTEM_PATTERNS_H_

#include "plinda_ids.h"


class TupleHandle;

// --------------------------------------------------------------------------
// eval tuple
// (this process id:      procid, 
//  parent's process id:  procid, 
//  name:                 char[], 
//  private log id:       gid, 
//  argument tuple id:    physid,
//  # of retries:         long,
//  interactive:	  int);

class Tuple;

Tuple *
create_eval_tuple(procid id, procid parent_id, const char* name,
	          const gid& log_id, const physid& arg_id, long retry,
		  int interactive);

Tuple *
create_eval_tuple_pattern(procid id =0);


int 
read_eval_tuple(Tuple* ,Tuple *, procid& id, procid& parent_id,
		const char*& name, gid& log_id, physid& arg_id, 
		long& retry, int& interactive);


// --------------------------------------------------------------------------
// arg tuple
// (exec-file name:	char[],
//  ... we do not know the rest 

const char* read_name_from_arg(Tuple* e_tuple);

// --------------------------------------------------------------------------
// catalog tuple
// (group id:      gid, 
//  name:          char[]);

Tuple *
create_catalog_tuple(const gid& g, const char* name);
 
Tuple *
create_catalog_tuple_pattern(const gid& g =zero_gid);

int
read_catalog_tuple(Tuple *retrievedTuple,
		   Tuple* e_tuple, gid& g, const char*& name);

// -----------------------------------------------------------------------
// main_prgm_tuple
// (name: char[])


Tuple* create_main_prgm_tuple(const char* name);


#endif // _SYSTEM_PATTERNS_H_
