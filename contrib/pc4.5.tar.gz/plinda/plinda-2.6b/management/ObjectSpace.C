// This may look like C code, but it is really -*- C++ -*-
//
// File:     ObjectSpace.C
// Created:  May 3, 1994
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//

// C or C++ header files
#include <stdio.h>
#include <stream.h>

// *** GNU Stuff ***
#include <SLList.h>

#include "ServerCommLink.h"
#include "Reactor.h"
#include "Scheduler.h"
#include "FailureMonitor.h"
#include "LoadBalancer.h"
#include "ConnectionListener.h"
#include "MessageListener.h"
#include "ProcessManager.h"
#include "TransactionManager.h"
#include "TupleGroupManager.h"
#include "MonitorProcess.h"

#include "CheckpointManager.h"
#include "Snapshot.h"
#include "LogManager.h"

#ifdef AUTO_FAULT_MODE
#include "FaultLevelManager.h"
#endif

#include "EventLog.h"
#include "ObjectSpace.h"

// -----------------------------------------------------------------------
// state and mode of operation of the server 
// -----------------------------------------------------------------------

ObjectSpace::ServerState  ObjectSpace::server_state;
ObjectSpace::ServerMode   ObjectSpace::server_mode;

const unsigned  ObjectSpace::process_default_timeout = 30;
unsigned     	ObjectSpace::process_timeout = 
			ObjectSpace::process_default_timeout;

const unsigned  ObjectSpace::loadbalancing_default_interval = 2;
unsigned     	ObjectSpace::loadbalancing_interval = 
			ObjectSpace::loadbalancing_default_interval;

const unsigned  ObjectSpace::link_default_timeout = 5;
const unsigned  ObjectSpace::send_default_timeout = 5;

const unsigned  ObjectSpace::chkpt_default_interval = 30;
unsigned     	ObjectSpace::chkpt_interval = 
			ObjectSpace::chkpt_default_interval;
#ifdef AUTO_FAULT_MODE
			const unsigned  ObjectSpace::continuation_default_size = 2000;
			unsigned        ObjectSpace::continuation_size =
			ObjectSpace::continuation_default_size;
 
			const float  ObjectSpace::failure_default_rate = 0.1;
			float           ObjectSpace::failure_rate =
			ObjectSpace::failure_default_rate ;
#endif
 


const unsigned  ObjectSpace::default_minimum_idletime = 600; // ten minutes
unsigned        ObjectSpace::minimum_idletime = 
                        ObjectSpace::default_minimum_idletime;

const unsigned  ObjectSpace::default_max_connections = 50;
unsigned     	ObjectSpace::max_connections = 
			ObjectSpace::default_max_connections;

const unsigned  ObjectSpace::default_max_num_clients_per_daemon = 30;
const unsigned 	ObjectSpace::max_num_clients_per_daemon =
                        ObjectSpace::default_max_num_clients_per_daemon;

const unsigned  ObjectSpace::monitor_update_interval = 3;

unsigned  ObjectSpace::trace_on = 0;

const char* 	ObjectSpace::x_server_name = 0;
const char* 	ObjectSpace::working_directory = 0;
const char* 	ObjectSpace::host_file = 0;


// ------------------------------------------------------------
// Fault Tolerance Level 
// ------------------------------------------------------------

FT_LevelType ObjectSpace::fault_tolerance_level = PRIVATE_SNAPSHOT; 

// ------------------------------------------------------------
// flags
// ------------------------------------------------------------

int ObjectSpace::display_flag = 0;	// display
int ObjectSpace::debugging_flag = 0;	// debugging
int ObjectSpace::batch_flag = 0;	// batch processing.
int ObjectSpace::piranha_flag = 1;	// default is piranha style computation
int ObjectSpace::dumb_monitor_flag = 0;	// dumb monitor


// -----------------------------------------------------------------------
// Scheduler 
// -----------------------------------------------------------------------

Scheduler ObjectSpace::scheduler;
FailureMonitor ObjectSpace::failure_monitor;
LoadBalancer ObjectSpace::load_balancer;


// -----------------------------------------------------------------------
// ACE COMMUNICATION MANAGER 
// -----------------------------------------------------------------------
Reactor ObjectSpace::comm_mgr;


// -----------------------------------------------------------------------
// Monitoring Process 
// -----------------------------------------------------------------------
MonitorProcess  ObjectSpace::monitor;


// -----------------------------------------------------------------------
// Checkpoint Manager 
// -----------------------------------------------------------------------

CheckpointManager ObjectSpace::chkpt_mgr;
GlobalSnapshot    ObjectSpace::snapshot_mgr;
#ifdef AUTO_FAULT_MODE
FaultLevelManager ObjectSpace::ftlvl_mgr;
#endif
 

// -----------------------------------------------------------------------
// Logging Manager 
// -----------------------------------------------------------------------

LogManager ObjectSpace::log_mgr;


// -----------------------------------------------------------------------
// Object Subspaces.
// -----------------------------------------------------------------------

ProcessManager     ObjectSpace::proc_mgr;
TransactionManager ObjectSpace::trans_mgr;
TupleGroupManager  ObjectSpace::group_mgr;


// -----------------------------------------------------------------------
// Listener that will handle connection requests.
// -----------------------------------------------------------------------
ConnectionListener ObjectSpace::conn_lsner;


// -----------------------------------------------------------------------
// Listener that will handle message requests. Those which
// do not have dedicated connections send messages via Message Listener.
// -----------------------------------------------------------------------
MessageListener ObjectSpace::mssg_lsner;



// -----------------------------------------------------------------------
// event log
// -----------------------------------------------------------------------

EventLog ObjectSpace::event_log;


// -----------------------------------------------------------------------
// "do nothing" constructor
// -----------------------------------------------------------------------

ObjectSpace::ObjectSpace(void) {
  // do nothing.
}


// ----------------------------------------------------------------------
// When writes to a socket that is connected to a failed process,
// the SIGPIPE signal may be raised.
// ----------------------------------------------------------------------

void
ObjectSpace::sigpipe_catcher(int sig) {
  (void)sig; // keep compiler quiet
  ::printf("ObjectSpace:sigpipe_catcher caught a signal:\n");
}

void
ObjectSpace::sigint_catcher(int sig) {
  (void)sig; // keep compiler quiet
  cerr << "> SIGINT signal caught. kill all the processes !\n";
  if(check_ft_degree(NO_SUPPORT)) {
    cerr << "  You may resume from the last checkpointed state by using -r.\n";
  }
  cerr.flush();
  ObjectSpace::proc_mgr.terminate();
  ::exit(1);
}

int
ObjectSpace::check_ft_degree(FT_LevelType ft) {
  return (fault_tolerance_level == ft);
}
#ifdef AUTO_FAULT_MODE
void
ObjectSpace::set_ft_degree(FT_LevelType ft){
        fault_tolerance_level = ft;
}
#endif

// Initialize all the objects in the global object space.
int
ObjectSpace::initialize(int recover_system, int concurrent_gsnapshot) {
  ErrorType error_val;

  //server starting state : running by default;
  server_state = RUNNING;


  // initialize the communication manager.  ----------------------------
  comm_mgr.open(100, 1);


  // initialize ServerCommLink attributes.
  ServerCommLink::initialize(max_connections);


  // set up listeners         ------------------------------------
  //		for now, just use system assigned ports.
  unsigned short connection_port = 0;
  unsigned short message_port = 0;
  // create the connection request listeners.
  conn_lsner.open(INET_Addr(connection_port));
  // create the message delivery request listeners.
  mssg_lsner.open(INET_Addr(message_port));

  {
    // create a file to contain information about the server port.
    FILE* fp = fopen("plinda.server","w");
    if(fp == NULL) {
      cerr << "> error: can't create plinda.server !\n";
      cerr.flush();
      ::exit(1);
    }
    fprintf(fp,"%d %s\n", conn_lsner.port_number(), conn_lsner.hostname());
    fclose(fp);

    // to synchronize with the admin process
    fp = fopen("plinda.lock","w");
    fclose(fp);
  }


  // register Listeners into the communication manager.
  comm_mgr.register_handler(&(ObjectSpace::conn_lsner)); 
			    
  comm_mgr.register_handler(&(ObjectSpace::mssg_lsner)); 



  // initialize the checkpoint manager      ----------------------------
  if(!(error_val=chkpt_mgr.open(recover_system))) {
    cerr << ">  error: failed to open the directories for checkpoint.\n" 
	 << flush;
    exit(1);
    ObjectSpace::event_log.error("CheckpointMananger::open",
				 error_val.message());
  }


  // initialize the global snapshot manager.
  if(concurrent_gsnapshot == 1) {
    snapshot_mgr.mode(GlobalSnapshot::CONCURRENT);
  } else {
    snapshot_mgr.mode(GlobalSnapshot::SEQUENTIAL);
  }


  // initialize the log manager      ----------------------------
  log_mgr.initialize(0);

#ifdef AUTO_FAULT_MODE
  // initialize the Fault tolerent level manager  Jihai
  ftlvl_mgr.initialize(continuation_size, failure_rate);
#endif

  // timeouts for scheduler     --------------------------------------

  // failure detection frequency
  failure_monitor.timeout(process_timeout);

  // if process_timeout == 0, then no failure detection is performed.
  if(process_timeout) {
    Time_Value failure_timeout(process_timeout, 0);
    comm_mgr.schedule_timer(&(ObjectSpace::failure_monitor), 0,
			    failure_timeout, failure_timeout);
  }

  // load balancing frequency
  {
    load_balancer.timeout(loadbalancing_interval);
    Time_Value interval(loadbalancing_interval, 0);
    comm_mgr.schedule_timer(&(ObjectSpace::load_balancer), 0, 
			    interval, interval);
  }

  // timeout for the checkpoint manager  --------------------------------------

  // if chkpt_interval == 0, then no checkpointing.
  if(chkpt_interval) {
    // checkpoint interval
    Time_Value interval(chkpt_interval, 0);
    comm_mgr.schedule_timer(&(ObjectSpace::chkpt_mgr),0, interval, interval);
  }
     

  // object subspaces          -----------------------------------------

  proc_mgr.initialize(FIRST_PROCID, EVAL_GID, PROC_GID, ARG_GID);
  trans_mgr.initialize(FIRST_TRANSID);
  group_mgr.initialize(FIRST_GID, FIRST_PHYSID, CATALOG_GID, TRACE_GID);

  // x server name
  proc_mgr.x_server(x_server_name);
  
  // signal catcher for SIGPIPE.  -------------------------------
  signal(SIGPIPE, ObjectSpace::sigpipe_catcher);

  // signal catcher for SIGINT.  -------------------------------
  signal(SIGINT, ObjectSpace::sigint_catcher);


  return 1;
}


// --------------------------------------------------------------------
// shutdown
// --------------------------------------------------------------------

int
ObjectSpace::shutdown(void) {
  state(SHUTDOWN_SERVER);
  return 1;
}


// --------------------------------------------------------------------
// recover: rollback to the latest checkpoint state and
// then replay the log 
// --------------------------------------------------------------------

int
ObjectSpace::recover(void) {

  if(!chkpt_mgr.rollback()) {
    return 0;
  } 

  // replay the log; we do not do this now, 
  // but we will add logging soon.
  if(!log_mgr.replay()) {
    return 0;
  }

  return 1;
}

void
ObjectSpace::dump(void) {
  group_mgr.dump(event_log.get_log());

  proc_mgr.dump(event_log.get_log());

  trans_mgr.dump(event_log.get_log());
}
/* ----------------------------------------------------
   set server's state (check the type defined above)
   ----------------------------------------------------*/
void 
ObjectSpace::state(const ObjectSpace::ServerState s){
    server_state = s;
}

ObjectSpace::ServerState 
ObjectSpace::state(void) {
    return server_state;
}
/* ----------------------------------------------------
   set server's operation mode (normal/debugging)
   ----------------------------------------------------*/
void 
ObjectSpace::mode(const ObjectSpace::ServerMode s){
    server_mode = s;
}

ObjectSpace::ServerMode 
ObjectSpace::mode(void) {
    return server_mode;
}

/* ----------------------------------------------------*/
void 
ObjectSpace::set_config(const ObjectSpace::ConfigParam p,
			unsigned value){
  switch(p){
    case FAILURE_TIMEOUT:
    if(process_timeout != value)
      cerr << "Sorry server does not currently support dynamically " <<
	" changing the failure timeout, only done at initialization\n" <<
	  flush;
    process_timeout = value;
    break;
  case CHKPT_INTERVAL:
    if(chkpt_interval != value)
      cerr << "Sorry server does not currently support dynamically " <<
	" changing the checkpoint interval, only done at initialization\n"<<
	  flush;
    chkpt_interval = value;
    break;
  case MAX_CONNECTIONS:
    if(max_connections != value)
      cerr << "Sorry server does not currently support dynamically " <<
	" changing the max connection, only done at initialization\n"<<
	  flush;
    max_connections = value;
    break;
  case IDLENESS_INTERVAL:
    cerr << "new dleness interval = " << value << endl << flush;
    ObjectSpace::minimum_idletime = value;
    ObjectSpace::proc_mgr.set_minimum_idletime(value);
    break;
  default:
    cerr << "unknow value to ObjectSpace::set_config\n" << flush;
    break;
  }
}
// -----------------------------------------------------------------------
// Cleanup log 
// -----------------------------------------------------------------------
int ObjectSpace::cleanup_log(const char* host, const char *uname,long pid) {
   extern const char *REMOTESH;
  //if(ObjectSpace::batch_flag == 1) return 0;
  char full_name[1000];
  ::sprintf(full_name, "%s/plinda.cleanup", working_directory);
  FILE* fp = ::fopen(full_name,"a+");
  if(fp == NULL) {
	cout << "\ncannot create " << working_directory << "/plinda.cleanup\n" << flush;
	return 0;
  }
  if(host != 0) {
    assert(uname);
    ::fprintf(fp,"%s %s -l %s kill -9 %ld\n", REMOTESH, host, uname,pid);
  } else {
    ::fprintf(fp,"echo \"** host is unknown for process %ld\"", pid);
  }
  ::fclose(fp);

  return 1;
}
