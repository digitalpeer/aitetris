// This may look like C code, but it is really -*- C++ -*-
//
// File:     FaultLevelManager.h 
// Created:  Oct 29, 1995
// Author:   Jihai  Qiu
// Mail:     jihai@cs.nyu.edu
//
#ifdef AUTO_FAULT_MODE
#ifndef _FAULT_LEVEL_MANAGER_H
#define _FAULT_LEVEL_MANAGER_H

#include "ObjectSpace.h"

class FaultLevelManager  {
public:
  // constructor and destructor
  FaultLevelManager(void){};
  ~FaultLevelManager(void) {};
  void initialize(int continuation_size, float failure_rate );

  void add_one_continuation(int continuation_size);
  void delete_one_continuation(int continuation_size);

  //void add_one_in_tuple(int tuple_size);
  //void add_one_out_tuple(int tuple_size);
  void add_one_process(void);
  void delete_one_process(void);
  void add_one_failure(void);

  int  ft_continuation_size(void);
  void set_ft_continuation_size(int continuation_size);

  //int ft_tuple_change(void);
  //void  set_ft_tuple_change(int tuple_change);
  
  float ft_frequent_failure_rate(void);
  void set_ft_frequent_failure_rate(float frequent_failure_rate);

  float ft_rare_failure_rate(void);
  void set_ft_rare_failure_rate(float rare_failure_rate);

  int check_change_ft_level(void); 
  void set_new_ft_level(void);
  
  int is_need_change_ft_level(void);
  FT_LevelType  get_new_ft_level(void);

private:
// the size sum of each client process's continuation's 
  int total_continuation_size;


// the number of total processes 
  int total_processes;


// the number of failed process in this interval
  int i_failed_processes;

// the threshold values for changing the fault tolerent mode
  int threshold_continuation_size;
  float threshold_frequent_failure_rate;

  int need_change_ft_level;
  FT_LevelType new_ft_level;
  
};

#ifndef _OUTLINE_
#include FaultLevelManager.iC
#endif

#endif // _FAULT_LEVEL_MANAGER_H
#endif AUTO_FAULT_MODE
