// This may look like C code, but it is really -*- C++ -*-
//
// File:        ProcessManager.C
// Description:	member functions of class ProcessManager.
// Created:  
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//

#include <iostream.h>
#include <fstream.h>

// PLinda header files & forward declaration
#include "plinda_ids.h"
#include "ErrorType.h"
#include "TupleHandle.h"
#include "TupleHandleIterator.h"
#include "Process.h"
#include "ClientProcess.h"
#include "DaemonProcess.h"
#include "Transaction.h"
#include "MonitorProcess.h"
#include "ServerCommLink.h"
#include "FailureMonitor.h"


// #include "AdminProcess.h"
#include "ProcessManager.h"
#include "TupleGroupManager.h"
#include "TransactionManager.h"
#include "System_Patterns.h"
#include "EventLog.h"
#include "ObjectSpace.h"
#include "Snapshot.h"

// GNU stuffs
#include "GNU_Interface.h"
#include <stream.h>

#ifdef  AUTO_FAULT_MODE
#include "FaultLevelManager.h"
#endif

ProcessManager::ProcessManager(void) {
  x_num_evals = 0;
}

// dummy copy constructor
ProcessManager::ProcessManager(const ProcessManager& ) {
  x_num_evals = 0;
}

ProcessManager::~ProcessManager(void) {
  client_list.clear();
  daemon_list.clear();
  delete super;
}

int
ProcessManager::num_processes(void) {
  return client_list.length();
}


int
ProcessManager::evalcount(void) const {
  return x_num_evals;
}

void
ProcessManager::incr_evalcount(void) {
  ++x_num_evals;
}

void
ProcessManager::decr_evalcount(void) {
  --x_num_evals;
}

const 
char* 
ProcessManager::x_server(void) const {
  return x_server_name;
}

void
ProcessManager::x_server(const char* name) {
  if(name == 0) {
    x_server_name = 0;
    return;
  }

  char* ptr = new char[::strlen(name)+1];
  ::memcpy(ptr, name, ::strlen(name)+1);
  x_server_name = ptr;
}

void
ProcessManager::initialize(procid pid, const gid& e_gid, 
			 const gid& p_gid, const gid& a_gid) {
  // assign identifiers to the special groups
  eval_group.update_group_id(e_gid);
  proc_group.update_group_id(p_gid);
  arg_group.update_group_id(a_gid);

  // set the last procid.
  Process::set_last_procid(pid);

  // create the super user process object. 
  super = new ClientProcess(SUPER_PROCID, zero_procid, zero_physid,1);
}


// -------------------------------------------------------------
// find process objects
// -------------------------------------------------------------

Process*
ProcessManager::find_process(procid id) {
  Process* proc = 0;

  proc = find_client(id);
  if(proc != 0)
    return proc;

  proc = find_daemon(id);
  if(proc != 0)
    return proc;

  return 0;
}

ClientProcess*
ProcessManager::find_client(procid id) {
  Pix p_cur;
  for(p_cur=client_list.first(); p_cur!=0; client_list.next(p_cur)) {
    ClientProcess* proc = (ClientProcess*)client_list(p_cur);
    if(proc->identifier() == id) {
      return proc;
    }
  }
  return 0;
}

DaemonProcess*
ProcessManager::find_daemon(procid id) {
  Pix p_cur;
  for(p_cur=daemon_list.first(); p_cur!=0; daemon_list.next(p_cur)) {
    DaemonProcess* proc = (DaemonProcess*)daemon_list(p_cur);
    if(proc->identifier() == id) {
      return proc;
    }
  }
  return 0;
}


DaemonProcess*
ProcessManager::find_daemon(const char* host){
  Pix p_cur;
  for(p_cur=daemon_list.first(); p_cur!=0; daemon_list.next(p_cur)) {
    DaemonProcess* proc = (DaemonProcess*)daemon_list(p_cur);
    if (::strcmp(proc->hostname(),host) == 0) {
      return proc;
    }
  }
  return (DaemonProcess*)0;
}

int
ProcessManager::num_clients(void){
  return (client_list.length()); 
}

// -------------------------------------------------------------
// destroy process objects
// -------------------------------------------------------------

int
ProcessManager::destroy_process(Process* proc) {
  switch(proc->type()) {
#ifdef __GNUG__
  case Process::CLIENT:
#else
  case Process::PLINDA_CLIENT:
#endif
    return destroy_client((ClientProcess*)proc);
    break;
  case Process::DAEMON:
    return destroy_daemon((DaemonProcess*)proc);
    break;
  default:
    assert(0);
  }

  return 0;
}

int
ProcessManager::destroy_client(ClientProcess* proc) {
  Pix p_cur;
  for(p_cur=client_list.first(); p_cur!=0; client_list.next(p_cur)) {
    ClientProcess* c_proc = (ClientProcess*)client_list(p_cur);
    if(proc->identifier() == c_proc->identifier()) {
      // found the process object, and destroy it.
      client_list.del(p_cur);
      delete proc;
      return 1;
    }
  }
  return 0;
}

int
ProcessManager::destroy_daemon(DaemonProcess* proc) {
  Pix p_cur;
  for(p_cur=daemon_list.first(); p_cur!=0; daemon_list.next(p_cur)) {
    DaemonProcess* c_proc = (DaemonProcess*)daemon_list(p_cur);
    if(proc->identifier() == c_proc->identifier()) {
      // found the process object, and destroy it.
      daemon_list.del(p_cur);
      delete proc;
      return 1;
    }
  }
  return 0;
}

void
ProcessManager::terminate(void) {
  Pix p_cur;
  for(p_cur=client_list.first(); p_cur!=0; client_list.next(p_cur)) {
    ClientProcess* c_proc = (ClientProcess*)client_list(p_cur);

    // already done.
    if(c_proc->status() == Process::COMPLETED) continue;

    // EVALED means it is not created.
    if(c_proc->status() != Process::EVALED) {
      c_proc->terminate();
    }
  }

  if(ObjectSpace::piranha_flag == 0) return;

  for(p_cur=daemon_list.first(); p_cur!=0; daemon_list.next(p_cur)) {
    DaemonProcess* d_proc = (DaemonProcess*)daemon_list(p_cur);
    d_proc->terminate();
  }
}


DaemonProcess* 
ProcessManager::create_daemon(const char* host,const char *htype,
			      const char *uname) {

  procid id = Process::get_next_procid();
  DaemonProcess* proc = new DaemonProcess(id, host,htype,uname);
  daemon_list.append(proc);

  return proc;
}


// -------------------------------------------------------------
// read arguments
// -------------------------------------------------------------

ErrorType
ProcessManager::retrieve_argument(TupleHandle& t_handle, 
				  Transaction* trans,
				  Tuple* arg_pat,
				  const physid& arg_id) {
  (void)trans;
  return  arg_group.retrieve_tuple(t_handle, arg_pat, Tuple::RD,arg_id);
  // do not bother to call trans->access_tuple since this is a read
  // this is a bit of a Kludge
}


// -------------------------------------------------------------
// real OS process management
// -------------------------------------------------------------

int
ProcessManager::spawn_PROCESS(const Process* proc,
			      Tuple* arg_tuple,int interactive) {

  // name of the executable file for the new process to create.
  char* name = (char*)::read_name_from_arg(arg_tuple);

  // a new process needs two types of identifier.
  procid par_pid = proc->identifier();
  procid new_pid = Process::get_next_procid();
  gid log_id = TupleGroup::get_next_gid();
  physid arg_id = TupleGroup::get_next_physid();
  long retry = 0;

  // create an eval tuple to be retrieved by a Daemon
  // eval tuple contains information: process id of the process,
  // process id of the parent process, name of the executable file,
  // and the physid of the argument tuple.
  Tuple* eval_tuple = ::create_eval_tuple(new_pid,par_pid,name,
				               log_id,arg_id, 
					       retry, 
					       interactive);

  delete [] name;
  // insert eval tuple. 
  TupleHandle t_handle;
  eval_group.insert_tuple(t_handle,eval_tuple);
  assert(t_handle.valid());

  assert(arg_tuple != eval_tuple);
  arg_group.insert_tuple(t_handle, arg_tuple, arg_id);
  assert(t_handle.valid());

  // create a process object. 

  ClientProcess* new_proc = 
    new ClientProcess(new_pid, par_pid, arg_id,interactive);
  assert(new_proc);
  client_list.append(new_proc);

  incr_evalcount();
  return 1;
}



ClientProcess* 
ProcessManager::dispatch_PROCESS(Process* ,
				 Transaction* dsptch_trans,
				 const char*& name, 
				 procid& proc_id, 
				 long& retry,
				 int& interactive) {

  // we should have an eval tuple.
  assert(evalcount() > 0);


  procid par_id;
  gid    log_id;
  physid arg_id;
 
  // read an eval tuple ---------------------------------
  { 
    Tuple* eval_tuple;
    TupleHandle t_hdle;
    
    /* if the proc_id is provided, then a specific process
       has to be spawned . */
    if (proc_id==SUPER_PROCID){
	eval_tuple = ::create_eval_tuple_pattern();
    }
    else {
	eval_tuple = ::create_eval_tuple_pattern(proc_id);
    }

    eval_group.retrieve_tuple(t_hdle, eval_tuple, Tuple::IN);
    assert(t_hdle.valid());
    dsptch_trans->access_tuple(&eval_group, t_hdle, Tuple::IN);
    ::read_eval_tuple(t_hdle.tuple(), eval_tuple, 
		      proc_id, par_id, name, log_id, 
		      arg_id, retry, interactive);
    Tuple::destroy(eval_tuple);
  }

  // there must already be a process object. 
  ClientProcess* proc = find_client(proc_id);
  assert(proc != 0);
  
  // create proc tuple          ------------------------------------------
  { 
    Tuple* proc_tuple;
    long num_try = retry + 1; 
    proc_tuple = ::create_eval_tuple(proc_id, par_id, name, log_id, 
				     arg_id, num_try, interactive);

    // insert proc tuple in proc_group.
    TupleHandle t_hdle;
    proc_group.insert_tuple(t_hdle, proc_tuple);

  }

  // decrement the eval count.
  decr_evalcount();

  // change the status of the process

  if(proc->status() == Process::EVALED) {
    proc->status(Process::DISPATCHED);
  } else {
    assert(proc->status() == Process::FAILURE_HANDLED);
  }

  return proc;
}



int
ProcessManager::respawn_PROCESS(procid proc_id) 
{

  procid id;
  procid par_id;
  const char* name;
  gid    log_id;
  physid arg_id;
  long retry;
  int  interactive;

  // read proc tuple ---------------------------------
  {
    Tuple* proc_tuple = ::create_eval_tuple_pattern(proc_id);
    TupleHandle t_hdle;

    proc_group.retrieve_tuple(t_hdle, proc_tuple, Tuple::IN);
    assert(t_hdle.valid());
    proc_group.delete_tuple(t_hdle.identifier()); 
    // no transaction here, just do it.
    ::read_eval_tuple(t_hdle.tuple(),proc_tuple, id, par_id, name, 
		      log_id, arg_id, retry, interactive);
    Tuple::destroy(proc_tuple);
  }
  
  {
    ++retry;
    Tuple* eval_tuple = ::create_eval_tuple(proc_id, par_id, name,
						 log_id, arg_id, retry, 
						 interactive);
    TupleHandle t_hdle;
    eval_group.insert_tuple(t_hdle, eval_tuple);
    
  }
  ClientProcess* new_proc = find_client(proc_id);
  assert(new_proc != 0);
  incr_evalcount();
  return 1;
}


int
ProcessManager::terminate_PROCESS(Transaction* end_trans,
                                ClientProcess* proc) {

  // delete the proc tuple
  TupleHandle tuple_handle;
  Tuple* proc_tuple = ::create_eval_tuple_pattern(proc->identifier());
  proc_group.retrieve_tuple(tuple_handle,proc_tuple, Tuple::IN);
  if(!tuple_handle.valid()) {
     // This happens under global snapshot when there is a failure
     // first the procs failure handler is called to move its tuple to
     // the eval group and now the scheduler realizes that this
     // is global snapshot and therefore kills all running processes
     eval_group.retrieve_tuple(tuple_handle,proc_tuple, Tuple::IN);     
     assert(tuple_handle.valid());
     end_trans->access_tuple(&eval_group, tuple_handle, Tuple::IN);
  } else {
     end_trans->access_tuple(&proc_group, tuple_handle, Tuple::IN);
  }

  // delete the argument tuple
  arg_group.retrieve_tuple(tuple_handle, NULL, Tuple::IN, 
			   proc->arg_id());
  assert(tuple_handle.valid());
  end_trans->access_tuple(&arg_group, tuple_handle, Tuple::IN);
  Tuple::destroy(proc_tuple);
  return 1;
}



// --------------------------------------------------------------------
// checkpoint and rollback
// --------------------------------------------------------------------

ErrorType
ProcessManager::checkpoint(void) {
  ErrorType error_val;
  if(!(error_val=eval_group.checkpoint_group())) {
    return error_val;
  }
  if(!(error_val=proc_group.checkpoint_group())) {
    return error_val;
  }
  if(!(error_val=arg_group.checkpoint_group())) {
    return error_val;
  }
  // checkpoint the private logs of all the processes.
  Pix cur;
  for(cur=client_list.first(); cur != 0; client_list.next(cur)) {
    ClientProcess* proc = (ClientProcess*)client_list(cur);
    assert(ObjectSpace::check_ft_degree(PRIVATE_SNAPSHOT) ||
	   proc->logging_mode() == Process::LOGGING_OFF);
   proc->checkpoint_private_log();
  }
  return NO_ERROR;
}


ErrorType
ProcessManager::rollback(void) {
  ErrorType error_val;
  if(!(error_val = eval_group.load_checkpoint())) {
    ObjectSpace::event_log.error("ProcessManager::rollback",
                                 "unable to recover the eval group");
    return error_val;
  }
  
  if(!(error_val = proc_group.load_checkpoint())) {
    ObjectSpace::event_log.error("ProcessManager::rollback", 
                                 "unable to recover the proc group");
    return error_val;
  }
  if(!(error_val = arg_group.load_checkpoint())) {
    ObjectSpace::event_log.error("ProcessManager::rollback", 
      			         "unable to recover the arg group");
    return error_val;
  }
  // now, the three distinguished tuple groups must already 
  // have been recovered.

//  Transaction* rec_trans;
//  rec_trans = ObjectSpace::trans_mgr.create_transaction(super);
//  assert(rec_trans);
  // move proc tuples to the eval group.
  TupleHandleIterator p_iter;
  proc_group.iterator(p_iter);
  TupleHandle p_handle;
  DLList<physid> theIds;
  for(p_iter.first(p_handle); p_handle.valid(); p_iter.next(p_handle)) {
    theIds.append(p_handle.identifier());
    TupleHandle t_handle;
    Tuple *newTuple = Tuple::copy(p_handle.tuple());
    eval_group.insert_tuple(t_handle,newTuple,p_handle.identifier());
  }
  for(Pix p = theIds.first() ; p ; theIds.next(p)) {
    // cannot delete things as we go in the above loop because  that
    // would throw off the iteration operation
    Tuple * temp= proc_group.delete_tuple(theIds(p));
    assert(temp);
    Tuple::destroy(temp);
  }
  // create process objects.
  TupleHandleIterator e_iter;
  eval_group.iterator(e_iter);
  TupleHandle e_handle;
  for(e_iter.first(e_handle) ; e_handle.valid(); e_iter.next(e_handle)) {
    procid id;
    procid par_id;
    const char* name;
    physid arg_id;
    gid    log_id;
    long retry;
    int interactive;
    Tuple * temp = ::create_eval_tuple_pattern();
    ::read_eval_tuple(e_handle.tuple(),temp, id, par_id, name, 
		      log_id, arg_id,  retry, interactive);

  ClientProcess* proc = new ClientProcess(id, par_id, arg_id,interactive);
  assert(proc);
  client_list.append(proc);

    if(retry > 0) {
      proc->status(Process::FAILURE_HANDLED);
    }
    incr_evalcount();
    Tuple::destroy(temp);
  }
  // restore the private logs of all the processes.
  Pix cur;
  for(cur=client_list.first(); cur != 0; client_list.next(cur)) {
    ClientProcess* proc = (ClientProcess*)client_list(cur);
    proc->restore_private_log();
  }

  return NO_ERROR;
}


DaemonProcess* 
ProcessManager::find_ready_daemon(void) {
  assert(evalcount() > 0);

  DaemonProcess* cur_daemon = 0;
  for(Pix cur=daemon_list.first(); cur != 0; daemon_list.next(cur)) {
    DaemonProcess* proc = (DaemonProcess*)daemon_list(cur);

    if(proc->ready()) {
      if(cur_daemon == 0) cur_daemon = proc;
      else if(cur_daemon->num_clients() > proc->num_clients()) {
	cur_daemon = proc;
      } 
    }
  }

  return cur_daemon;
}


int
ProcessManager::num_machines(void) {
   int num = 0;
  for(Pix cur=daemon_list.first(); cur != 0; daemon_list.next(cur)) {
    DaemonProcess* proc = (DaemonProcess*)daemon_list(cur);
    if(proc->ready()) {
       num++;
      } 
 }
  return num;
}


DaemonProcess*
ProcessManager::find_busy_daemon(void) {
  DaemonProcess* cur_daemon = 0;

  for(Pix cur=daemon_list.first(); cur != 0; daemon_list.next(cur)) {
    DaemonProcess* proc = (DaemonProcess*)daemon_list(cur);

    if(!proc->failure_detected() && proc->num_clients() > 1) {
      if(cur_daemon == 0) cur_daemon = proc;
      else if(cur_daemon->num_clients() < proc->num_clients()) {
	cur_daemon = proc;
      }
    }
  }

  return cur_daemon;
}


void
ProcessManager::set_minimum_idletime(int time) {
  for(Pix cur=daemon_list.first(); cur != 0; daemon_list.next(cur)) {
    DaemonProcess* proc = (DaemonProcess*)daemon_list(cur);
    proc->set_minimum_idletime(time);
  }
}


DaemonProcess*
ProcessManager::find_idle_daemon(void) {
  DaemonProcess* cur_daemon = 0;

  for(Pix cur=daemon_list.first(); cur != 0; daemon_list.next(cur)) {
    DaemonProcess* proc = (DaemonProcess*)daemon_list(cur);

//    if(proc->ready() && proc->num_clients() == 0 && !proc->reserved()) {
    if(proc->ready() && proc->num_clients() == 0) {
      cur_daemon = proc;
      break;
    }
  }

  return cur_daemon;
}


int
ProcessManager::count_idle_daemons(void) {
  int counter = 0;
  
  for(Pix cur=daemon_list.first(); cur != 0; daemon_list.next(cur)) {
    DaemonProcess* proc = (DaemonProcess*)daemon_list(cur);

//    if(proc->ready() && proc->num_clients() == 0 && !proc->reserved()) 
    if(proc->ready() && proc->num_clients() == 0) ++counter;
  }

  return counter;
}



int
ProcessManager::schedule(void) {
    // client processes ------------------------------;
    Pix cur;
    if (ObjectSpace::state() != ObjectSpace::SUSPENDED){
	for(cur=client_list.first(); cur != 0; client_list.next(cur)) {
	    ClientProcess* proc = (ClientProcess*)client_list(cur);
	    
	    if(proc->ready()) {
		proc->handle_request();
	    } else if(proc->completed()) {
		// delete the process object.;
		client_list.del(cur);
		delete proc;
	    }
	}
	
	if(ObjectSpace::debugging_flag == 1) {
	    while(evalcount() > 0) {
	      DaemonProcess::pseudo_spawn_process();
	    }
	    
	    return 1;
	}
	
	// daemon processes ----------------;
	while(evalcount() > 0) {
	    DaemonProcess* proc = find_ready_daemon();
	    
	    // all the machines are busy.;
	    if(proc == 0) break;
	    
	    // found an available machine.;
	    proc->spawn_process();
	}
	
    }


    /* invoke the monitor */
    if ((ObjectSpace::monitor).ready()){
	(ObjectSpace::monitor).handle_request();
    }

	
    return 1;
}



int 
ProcessManager::activate_gsnapshot(void) {
  // client processes
  Pix cur;
  for(cur=client_list.first(); cur != 0; client_list.next(cur)) {
    ClientProcess* proc = (ClientProcess*)client_list(cur);
    if(proc->status() == Process::RUNNING ||
       proc->status() == Process::REQUEST_READY ||
       proc->status() == Process::REQUEST_BLOCKED ||
       proc->status() == Process::FAILURE_DETECTED ||
       proc->status() == Process::FAILURE_HANDLED) {
#ifndef AUTO_FAULT_MODE
      if(proc->inconsistent()) {
#else
    // we only ask a process with an inconsistent snapshot in the server
	if ( ObjectSpace::ftlvl_mgr.is_need_change_ft_level() ||
           proc->inconsistent() ){
        //  when we change fault tolerent level or the process is inconsistent
#endif
        // we only ask a process with an inconsistent snapshot in the server
        ObjectSpace::snapshot_mgr.take_psnapshot(proc);
      }
    }
  }
  ObjectSpace::snapshot_mgr.activate();

  return client_list.length();
}

int
ProcessManager::schedule_for_gsnapshot(void) {
  // global snapshot should be activated.
  assert(ObjectSpace::snapshot_mgr.activated() 
	 || ObjectSpace::snapshot_mgr.finished());

  // client processes
  Pix cur;
  for(cur=client_list.first(); cur != 0; client_list.next(cur)) {
    ClientProcess* proc = (ClientProcess*)client_list(cur);
    
    if(proc->ready()) {
      int status = ObjectSpace::snapshot_mgr.check_status(proc);
      if(status == 1) {
	// snapshot is not yet taken; any request is fine.
	proc->handle_request();
      } else { 
	// status is either 0 (taken) or -1 (not included).
	// snapshot is already taken or this process is not included.
	// in this case, the process is not allowed to commit.
	if(proc->request_type() != XCOMMIT) {
	  proc->handle_request();
	}
      }
    }

    if(proc->completed()) {
      // delete the process object.
      client_list.del(cur);
      delete proc;
    }
  }

  // still run daemon processes so that processes that failed
  // during checkpointing can progress. Otherwise, the checkpointing
  // operation will get into a deadlock.
  if(ObjectSpace::debugging_flag == 1) {
    while(evalcount() > 0) {
      DaemonProcess::pseudo_spawn_process();
    }
    
    return 1;
  }

  while(evalcount() > 0) {
    DaemonProcess* proc = find_ready_daemon();

    // all the machines are busy.
    if(proc == 0) break;

    // found an available machine.
    proc->spawn_process();
  }
  // during checkpointing, we do not migrate processes.

  return 1;
}



int
ProcessManager::handle_failure(void) {
  int num_failures = 0;
  Pix cur;
  for(cur= client_list.first(); cur != 0; client_list.next(cur)) {
     ClientProcess* proc = (ClientProcess*)client_list(cur);
     
     if(proc->comm_link() != 0) {
       if((proc->comm_link())->broken() && proc->alive()) {
#ifdef PL_DEBUG
	  cerr << "ProcessManager::handle_failure kicking in\n" << flush;
#endif
	  if(ObjectSpace::check_ft_degree(NO_SUPPORT)) {
	     proc->declare_error(E_FAIL);
	  } else {  
	     proc->declare_failure();
	  }
       }
     }

     // if failure is detected but not processed,
     // deal with it here.
     if(proc->failure_detected()) {
#ifdef PL_DEBUG
	cout << "ProcessManager::handle_failure is dealing with failure\n";
#endif
	proc->handle_failure();
	num_failures++;
     } 

     if(proc->error_found()) {
#ifdef PL_DEBUG
	cout << "ProcessManager::handle_failure is dealing with error\n";
#endif
	proc->handle_error();
	num_failures++;
     }
  }

  return num_failures;
}

// If we run PLinda daemons on hosts, we use them to detect processor failure.
// Failure detection is conducted in a two phase style: EXAMINE and CONCLUDE.
// In EXAMINE, we say hello to daemons and in CONCLUDE we check 
// if they respond. For those who have not replied, we concluded that
// they have already failed.
int
ProcessManager::check_failure(FailureMonitor::PhaseType phase) {
  // if there is no daemon, then we just rely on the TCP/IP protocol
  if(ObjectSpace::piranha_flag == 0) 
    return 0;

  int failure_count = 0;
  Pix cur;
  for(cur= daemon_list.first(); cur != 0; daemon_list.next(cur)) {
      DaemonProcess* dproc = (DaemonProcess*)daemon_list(cur);
      // do not care about those not yet connected or already failed.
      if(dproc->status() == Process::FAILURE_DETECTED ||
	 dproc->status() == Process::FAILURE_HANDLED) 
	continue;

      // not interested in daemons which do run processes.
      if(dproc->num_clients() == 0) 
	continue;

      // We are examining, but have talked to daemon in this phase already
      if(phase==FailureMonitor::EXAMINE_PHASE && dproc->alive_flag() ==1)
	continue;

      if(phase == FailureMonitor::EXAMINE_PHASE && dproc->alive_flag() == 0) 
	dproc->check_failure();
      else if(dproc->alive_flag() == 1) 
	dproc->set_alive_flag(0);
      else {
	// terminate the daemon 
	dproc->terminate();
	destroy_daemon(dproc);
	++failure_count;
      }
  }
  return failure_count;
}


// ----------------------------------------------------------------------
// dump
// ----------------------------------------------------------------------

void 
ProcessManager::dump(ofstream& log) {
  
  log << "\n  ============  Process Manager  =============  \n";

  log << "\n  --- Eval Group ---  \n";

  eval_group.dump(log);

  log << "\n  --- Proc Group ---  \n";

  proc_group.dump(log);

  log << "\n  --- Arg Group ---  \n";

  arg_group.dump(log);

  log << "\n  --- Client Process Object List --- \n";

  int idx = 1;
  Pix p_cur;
  for(p_cur = client_list.first(); p_cur != 0; client_list.next(p_cur), ++idx) {
    Process* proc = client_list(p_cur);
    log << dec(idx) << ". " << proc->print() << "\n";
  }

  log << "\n  --- Daemon Process Object List --- \n";

  idx = 1;
  Pix d_cur;
  for(d_cur = daemon_list.first(); d_cur != 0; daemon_list.next(d_cur), ++idx) {
    Process* daemon = daemon_list(d_cur);
    log << dec(idx) << ". " << daemon->print() << "\n";
  }

  log << "\n # of the currently accessible eval tuples: ";
  log << x_num_evals;

  log << "\n  ======================================== \n";

  log.flush();
}
  


/*-----------------------------------------------------------------
  ErrorType kill_PROCESS(procid):
  terminate the client process specified by the given procid with
  no scope of restarting it. Its private log is also destroyed so
  if it is to be respawned, it would start from the beginning.
  1. check if the procid specifies a valid client which is running.
  2. obtain the client obj corresp. to the procid.
  3. transactionally,
     - destroy the private log tuple group
     - delete the proc_tuple (there should be one)
     - delete the arg_tuple
     - ask the client obj. to handle its intermediate tasks :
        * abort of current transaction.
	* destroy private stuff : current_pending request if any
	* any blocked stuff in the blocked tuple group.
	* destroy the communication link.
	* inform its daemon 
     - destroy the client obj.
  ------------------------------------------------------------*/
ErrorType
ProcessManager::kill_PROCESS(const procid pid){

    // there must be a process object. ;
    ClientProcess* proc = find_client(pid);
    //assert(proc != 0);
    if (proc == NULL){
	cerr << "process id : " << pid << "doesnt exist!" << 
	    " -- in \"ProcessManager::kill_PROCESS\"\n" << flush;
	return NO_ERROR;
    }

    // ClientProcess will commit suicide alone. 
    proc->terminate();

    // delete the entry from the list.
    destroy_client(proc);

    return NO_ERROR;

}


/* ---------------------------------------------------------------
   migrate_PROCESS(procid, new_host_on_which_to_continue);
   This call is equivalent to killing the process on the current
   host and respawning on the new host. However, here the killing
   is not the same as above one because, since we want to continue 
   it, we should not restart it again from the start (should
   make use of the log).
   -------------------------------------------------------------*/
ErrorType
ProcessManager::migrate_PROCESS(const procid pid, 
				const char* new_host){

    /* find the daemon associated with the new_host.
       If there is no daemon on it, the user first has to 
       "add" that host (which would create a daemon. */
    DaemonProcess* daemon_proc = find_daemon(new_host);
    if (daemon_proc ==0){
	cerr << "no daemon on host : " << new_host << "!\n" << flush;
	return NO_ERROR;
    }

    /* there should be a process with this pid */
    ClientProcess* client_proc = find_client(pid);
    if (client_proc == 0){
	cerr << "no process with id : " << pid << "!\n" << flush;
	return NO_ERROR;
	//return E_INV_PROCESS;
    }

    /* if this process is already on the new host, do nothing */
    if ((client_proc->daemon_process())->identifier() 
	== daemon_proc->identifier()){
        cerr << "process = " << pid << " already on : " << new_host << ".\n" << flush;
	return NO_ERROR;
    }

    /* if the daemon if fully loaded, cant migrate */
    if (daemon_proc->fully_loaded()){
        cerr << "host machine : " << new_host << " is fully loaded.\n" << flush;
	return E_OVER_LOADED;
    }

    /* dep. on the status of the client we take approp. action*/
    switch(client_proc->status()){

      case Process::EVALED:
	/* there is no real process. but since it needs to be spawned, 
	   we spawn it by asking the new_host's daemon.
	   I dont think this situation will occur unless we inform
	   the monitor process of all processes even the evaled
	   one's (not necessarily the one's "really" created */
	{
	    /*Ask the daemon on the new host to dispatch client*/
	    daemon_proc->dispatch_client(client_proc->identifier());
	}
	break;
      case Process::DISPATCHED:
	/* this process has been spawned but it has not sent its 
	   first request (PROC_START) yet. There is proc_tuple but 
	   no eval tuple.*/
      case Process::RUNNING:
      case Process::REQUEST_READY:
      case Process::REQUEST_BLOCKED:
	{
	    /* The below two steps are equivalent to cleaning up
	       all the intermediate results in the client process 
	       object, transfering the proc_tuple to eval_group.*/

	    // send a kill request to the daemon.
	    (client_proc->daemon_process())->kill_process(client_proc->transient_id());
	    		// client_proc->kill();

	    client_proc->declare_failure();
#ifdef PL_DEBUG
	    cout << "ProcessManager::MIGRATE is calling handle_failure\n";
#endif
	    client_proc->handle_failure();
	    // the post condition for the above is that the clients status
	    // is Process::REQUEST_READY or Process::FAILURE_HANDLED
	    if(client_proc->status() == Process::REQUEST_READY) {
	       client_proc->terminate();
	    } else 
	    /* Ask the daemon on the new host to dispatch this 
	       client. Note that the handle_failure would notify
	       the previous daemon to take this process off its
	       list. */
	      daemon_proc->dispatch_client(client_proc->identifier());
	 }
        break;
      case Process::FAILURE_DETECTED:
	// the post condition for the above is that the clients status
	// is Process::REQUEST_READY or Process::FAILURE_HANDLED
	if(client_proc->status() == Process::REQUEST_READY) {
	   client_proc->terminate();
	} else {
#ifdef PL_DEBUG
	   cout << "ProcessManager::MIGRATE is handling failure for ";
	   cout << " a truly failed process\n";
#endif
	   client_proc->handle_failure();
	   /*Ask the daemon on the new host to dispatch client*/
	   daemon_proc->dispatch_client(client_proc->identifier());
	}
	break;
      case Process::FAILURE_HANDLED:
      case Process::COMPLETED:
	break;
      default:
	return E_INV_PROCESS;
    }

    return NO_ERROR;
}

/*--------------------------------------------------------------------
  destroy_daemon(hostname):
  If there are no running processes on that host - its easy.
  If there are, then they have to be migrated to other hosts provided
  we meet the following condition : no new host is "over_loaded".
  ------------------------------------------------------------------*/
ErrorType
ProcessManager::delete_host(const char* host){

    DaemonProcess* daemon_proc = find_daemon(host);

    /* there should be daemon on that host */
    if (daemon_proc == 0){
	cerr << "invalid host name : " << host 
	    << " (or daemon doesnt exist on it).\n" << flush;
	return NO_ERROR;
    }
    
    // terminate the daemon
    daemon_proc->terminate();

    destroy_daemon(daemon_proc);
    return NO_ERROR;
}


/*-------------------------------------------------------------------*/
Tuple *
ProcessManager::host_list() 
{
   const int numHosts = daemon_list.length();
   const int hostNamesLength = MONITOR_STRLEN * PL_CHAR_SZ * numHosts;
   const int hostIdsLength = PL_INT_SZ * numHosts;
   const int cpuLoadsLength = PL_INT_SZ * numHosts;
   const int mainMemsLength = PL_INT_SZ * numHosts;
   const int maxClientsLength = PL_INT_SZ * numHosts;
   const int numClientsLength = PL_INT_SZ * numHosts;
   const int statusesLength = PL_INT_SZ * numHosts;
   const int totArrayLength = 
     hostNamesLength + hostIdsLength + cpuLoadsLength +
     mainMemsLength + maxClientsLength + numClientsLength + statusesLength;

   char hostNames[ MONITOR_STRLEN * numHosts];
   for(int i = 0 ; i < MONITOR_STRLEN * numHosts ; i++) 
     hostNames[i] = 0;
   int  hostIds[numHosts];
   int  cpuLoads[numHosts];
   int  mainMems[numHosts];
   int  maxClients[numHosts];
   int  numClients[numHosts];
   int  statuses[numHosts];

  int cur = 0;
  for(Pix p_cur=daemon_list.first(); p_cur!=0; daemon_list.next(p_cur)) {
     DaemonProcess* proc = (DaemonProcess*)daemon_list(p_cur);
     proc->host_info(&(hostNames[cur * MONITOR_STRLEN]),
		     hostIds[cur], cpuLoads[cur],
		     mainMems[cur], maxClients[cur], numClients[cur],
		     statuses[cur]);
     cur++;
  }
   // Format
   // int numHosts
   // char *hostNames one every MONITOR_STRLEN chars
   // int *hostIds
   // int *cpuLoads
   // int *mainMem
   // int *maxClients
   // int *numClients
   // int *statuses
   Tuple *tuple = Tuple::create(8, totArrayLength);
   tuple->setActual(0,TupleField::PLint, numHosts);
   tuple->setActual(1,TupleField::PLchar,    hostNames, numHosts * MONITOR_STRLEN);
   tuple->setActual(2,TupleField::PLint, hostIds, numHosts);
   tuple->setActual(3,TupleField::PLint, cpuLoads, numHosts );
   tuple->setActual(4,TupleField::PLint, mainMems, numHosts);
   tuple->setActual(5,TupleField::PLint, maxClients, numHosts);
   tuple->setActual(6,TupleField::PLint, numClients, numHosts);
   tuple->setActual(7,TupleField::PLint, statuses, numHosts);
   return tuple;

}

/*-------------------------------------------------------------------*/
Tuple *ProcessManager::monitor_info()
{
   int num = 0; 
   Pix p_cur;
   for(p_cur=daemon_list.first(); p_cur!=0; daemon_list.next(p_cur)) {
      DaemonProcess* dproc = (DaemonProcess*)daemon_list(p_cur);
      for(int j=0; j<dproc->max_num_clients();  j++){
	 if (dproc->isValidClient(j))
	   num++;
      }
   }

   //Format
   // int HowManyProcesses
   // int *ids
   // char *execs One every MONITOR_STRLEN characters
   // char *hosts One every MONITOR_STRLEN characters
   // char *files One every MONITOR_STRLEN characters
   // int  *lineNums
   // int *statuses

   const int idsLength = PL_INT_SZ * num ;
   const int execsLength = MONITOR_STRLEN * PL_CHAR_SZ * num;
   const int hostsLength = MONITOR_STRLEN * PL_CHAR_SZ * num;
   const int filesLength = MONITOR_STRLEN * PL_CHAR_SZ * num;
   const int lineNumsLength = PL_INT_SZ * num;
   const int statusesLength = PL_INT_SZ * num;
   const int totTupleArraysLength =  idsLength + filesLength + execsLength +
     hostsLength + lineNumsLength + statusesLength;


   int ids[num];
   char execs[MONITOR_STRLEN * num]; 
   char hosts[MONITOR_STRLEN * num];
   char files[MONITOR_STRLEN * num];
   int lineNums[num];
   int statuses[num];
   
   for(int i = 0 ; i < MONITOR_STRLEN * num ; i++) 
      execs[i] = files[i] = hosts[i] = 0;
      
   int cur = 0;
   for(p_cur=daemon_list.first(); p_cur!=0; daemon_list.next(p_cur)) {
      DaemonProcess* dproc = (DaemonProcess*)daemon_list(p_cur);
      for(int j=0; j < dproc->max_num_clients();  j++){
	 if(dproc->isValidClient(j)) {
	    assert(cur <= num);
	    dproc->monitor_info(j, ids[cur],&(execs[cur*MONITOR_STRLEN]),&(hosts[cur*MONITOR_STRLEN]),
				&(files[cur*MONITOR_STRLEN]),lineNums[cur],statuses[cur]);
	    cur++;
	   }
      }
   }
   Tuple *mlist = Tuple::create(7, totTupleArraysLength);
   mlist->setActual(0,TupleField::PLint, num);
   mlist->setActual(1,TupleField::PLint, ids, num);
   mlist->setActual(2,TupleField::PLchar,  execs, num * MONITOR_STRLEN);
   mlist->setActual(3,TupleField::PLchar,  hosts, num * MONITOR_STRLEN);
   mlist->setActual(4,TupleField::PLchar,  files, num * MONITOR_STRLEN); 
   mlist->setActual(5,TupleField::PLint, lineNums, num);  
   mlist->setActual(6,TupleField::PLint, statuses, num);
   return mlist;
}


/*-------------------------------------------------------------------*/
ErrorType 
ProcessManager::spawn_main_program(const char* prog_name, 
				   const char* host){

  (void)host; // keep compiler quiet
  
  Tuple* main_prgm_tuple = ::create_main_prgm_tuple(prog_name);
  spawn_PROCESS(super, main_prgm_tuple, 1);
  return NO_ERROR;

}

/*-----------------------------------------------------------*/
ErrorType
ProcessManager::dump_group(const char* name){
  char dump_file[200];
  ErrorType status;

  ::strcpy(dump_file, "/tmp/");
  ::strcat(dump_file, name);
  {
    ofstream dump_stream;
    dump_stream.open(dump_file, ios::out);
    if (::strcmp(eval_group.group_name(), name) == 0)
      status = eval_group.dump(dump_stream);
    else if (::strcmp(proc_group.group_name(), name) == 0)
      status = proc_group.dump(dump_stream);
    else if (::strcmp(arg_group.group_name(), name) == 0)
      status = arg_group.dump(dump_stream);
    else 
      status = E_INV_GROUP;
    dump_stream.close();
  }
  return status;

}
/*---------------------------------------------------------------*/










