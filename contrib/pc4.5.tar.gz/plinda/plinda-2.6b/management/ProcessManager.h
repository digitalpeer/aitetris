// This may look like C code, but it is really -*- C++ -*-
//
// File:        ProcessManager.h
// Description:	manages the process objects. 
// Created:  
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//
#ifndef _PROCESS_MANAGER_H_
#define _PROCESS_MANAGER_H_

// GNU stuffs
#include <fstream.h>
#include "GNU_Interface.h"

// PLinda header files & forward declaration
#include "plinda_ids.h"
#include "TupleGroup.h"
#include "FailureMonitor.h"

class Process;
class DaemonProcess;
class ClientProcess;

const procid   SUPER_PROCID   = 1;
const procid   MONITOR_PROCID = 2;
const procid   FIRST_PROCID   = 3;
const gid      EVAL_GID       = gid::zero(0,2);
const gid      PROC_GID       = gid::zero(0,3);
const gid      ARG_GID        = gid::zero(0,4);



class ProcessManager {
public:

  ProcessManager(void);
  virtual ~ProcessManager(void);
  // will never be happen.
  ProcessManager(const ProcessManager& another);

  void initialize(procid =FIRST_PROCID, const gid& =EVAL_GID, 
	         const gid& =PROC_GID, const gid& =ARG_GID);

 
  // -----------------------------------------------------------------------
  // number of processes
  // -----------------------------------------------------------------------
   int num_processes(void);

  int num_machines(void);
  // -----------------------------------------------------------------------
  // schedule: 
  // activate ready process objects; destroy completed process objects. 
  // -----------------------------------------------------------------------
  int schedule(void);

  // set the minimum_idletime of all of the daemons.
  void set_minimum_idletime(int);

  DaemonProcess* find_ready_daemon(void);
  DaemonProcess* find_busy_daemon(void);
  DaemonProcess* find_idle_daemon(void);
  int count_idle_daemons(void);

  // for global snapshot
  int schedule_for_gsnapshot(void);
  int activate_gsnapshot(void);

  // -----------------------------------------------------------------------
  // handle failure
  // -----------------------------------------------------------------------

  int check_failure(FailureMonitor::PhaseType);
  int handle_failure(void);


  // -----------------------------------------------------------------------
  // find and destroy process objects
  // -----------------------------------------------------------------------
  
  Process*       find_process(procid);
  ClientProcess* find_client(procid);
  DaemonProcess* find_daemon(procid);
  int            destroy_process(Process*);
  int            destroy_client(ClientProcess*);
  int            destroy_daemon(DaemonProcess*);
  int            num_clients(void);
  DaemonProcess* find_daemon(const char* host_name);

  // kill all the processes.
  void           terminate(void);


  // -----------------------------------------------------------------------
  // create process objects (c++ data structure).
  // -----------------------------------------------------------------------
  //  ClientProcess* create_client(procid, procid, const physid&,int);

  DaemonProcess* create_daemon(const char*,const char*,const char*);

  // -----------------------------------------------------------------------
  // read argument tuples
  // -----------------------------------------------------------------------

ErrorType retrieve_argument(TupleHandle& t_handle, 
			    Transaction* trans,
			    Tuple* arg_pat,
			    const physid& arg_id);

  // -----------------------------------------------------------------------
  // number of eval tuples
  // -----------------------------------------------------------------------

  int evalcount(void) const;
  void incr_evalcount(void);
  void decr_evalcount(void);

  // -----------------------------------------------------------------------
  // functions to manipualate real OS processes
  // -----------------------------------------------------------------------

  int spawn_PROCESS(const Process*, Tuple*,int);
  ClientProcess* dispatch_PROCESS(Process*, Transaction*, 
				  const char*&, procid&, long&, int&);
  int respawn_PROCESS(procid);
  int terminate_PROCESS(Transaction*, ClientProcess*);

#if 0
  // ----------------------------------------------------------------------
  // functions needed to implement monitoring tasks :
  // ----------------------------------------------------------------------
#endif
  ErrorType kill_PROCESS(const procid pid);
  ErrorType migrate_PROCESS(const procid pid, const char* new_host);
  ErrorType delete_host(const char* host_name);    /* == delete host*/

  Tuple *host_list();
  Tuple *monitor_info();
  ErrorType spawn_main_program(const char*, const char*);

  ErrorType dump_group(const char*);


  // -----------------------------------------------------------------------
  // checkpointing and rollback
  // -----------------------------------------------------------------------

  // checkpoint the process space.
  ErrorType      checkpoint(void);

  // restore the process space from the last checkpointed state.
  ErrorType      rollback(void);


  // super user process
  ClientProcess*  super;

  // X server
  const char* x_server(void) const;
  void x_server(const char*);

  // -----------------------------------------------------------------------
  // dump
  // -----------------------------------------------------------------------
       
  void dump(ofstream&);

private:

  // --------------------------------------------------------------------
  // number of eval tuples
  // --------------------------------------------------------------------
  int x_num_evals;

  // --------------------------------------------------------------------
  // special tuple groups for process management
  // --------------------------------------------------------------------
  TupleGroup eval_group;
  TupleGroup proc_group;
  TupleGroup arg_group;
  
  // --------------------------------------------------------------------
  // list of processes.
  // --------------------------------------------------------------------
  ProcessList client_list;
  ProcessList daemon_list;

  // --------------------------------------------------------------------
  // x server name
  // --------------------------------------------------------------------
  const char* x_server_name;


};


#endif // _PROCESS_MANAGER_H_

