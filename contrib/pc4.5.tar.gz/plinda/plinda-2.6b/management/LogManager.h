// This may look like C code, but it is really -*- C++ -*-
//
// File:       LogManager.h
// Description 
// Created:  
// Author:     Karp Joo Jeong
// Mail:       jeong@cs.nyu.edu
//

#ifndef _LOG_MANAGER_H_
#define _LOG_MANAGER_H_

#include "plinda_ids.h"
#include "TupleHandle.h"
#include "ErrorType.h"

const int PL_DEFAULT_LOG_SIZE = 500000;

class Process;
class Transaction;

class LogManager {
public:

  LogManager(void);
  LogManager(long);
  virtual ~LogManager(void);

  void initialize(long =PL_DEFAULT_LOG_SIZE);

  ErrorType replay(void);

  int start_transaction(Process*, Transaction*);
  int abort_transaction(Process*, Transaction*);
  int commit_transaction(Process*, Transaction*);

  int in_tuple(Process*, Transaction*, const TupleHandle&);
  int rd_tuple(Process*, Transaction*, const TupleHandle&);
  int out_tuple(Process*, Transaction*, const TupleHandle&);

private:
  int   x_log_buf_size;
  int   x_avail_size;
  char* x_log_buffer;
  char* x_cursor;
  
};

#endif // _LOG_MANAGER_H_

