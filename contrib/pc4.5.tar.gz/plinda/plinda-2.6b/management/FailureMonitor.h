// This may look like C code, but it is really -*- C++ -*-
//
// File:     FailureMonitor.h 
// Created:  May 1, 1995
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//
#ifndef _FAILURE_MONITOR_H_
#define _FAILURE_MONITOR_H_

// ACE
#include "Reactor.h"

class FailureMonitor : public Event_Handler {
public:
  enum PhaseType { EXAMINE_PHASE, CONCLUDE_PHASE };
  PhaseType phase_type(void) const;

  // constructor and destructor
  FailureMonitor(void);
  ~FailureMonitor(void) {};

  // timeout
  void timeout(long);
  virtual int handle_timeout(const Time_Value&, const void*);

private:
  Time_Value x_failure_timeout;
  PhaseType x_phase;
};

#ifndef _OUTLINE_
#include "FailureMonitor.iC"
#endif // _OUTLINE_

#endif // _FAILURE_MONITOR_H_
