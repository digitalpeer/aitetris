// This may look like C code, but it is really -*- C++ -*-
//
// File:        TransactionManager.C
// Description:	member functions of class TransactionManager
// Created:  
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu

#include "plinda_ids.h"
#include "ErrorType.h"
#include "Transaction.h"
#include "TransactionManager.h"
#include "ObjectSpace.h"
#include "GNU_Interface.h"

TransactionManager::TransactionManager(void) {
  trans_list.clear();
}

TransactionManager::~TransactionManager(void) {
  trans_list.clear();
}

int
TransactionManager::initialize(const transid& id) {
  Transaction::set_last_transid(id);
  return 1;
}

ErrorType TransactionManager::checkpoint(void)
{

  CheckPoint chkpt(zero_gid);
  ErrorType error_val = chkpt.open(WRITE_CHKPT);
  if(error_val.fail())
    return error_val;
  Pix t_cur;

  for(t_cur=trans_list.first(); t_cur!=0; trans_list.next(t_cur)) {
     Transaction* trans = trans_list(t_cur);
     Pix temp;
     for(temp = trans->x_in_tuples.first(); temp;
	 trans->x_in_tuples.next(temp)) {
	TupleHandle thandle = trans->x_in_tuples(temp);
	assert(thandle.tuple_group());
	error_val = chkpt.write(*thandle.tuple(), 
				thandle.tuple_group()->get_grpid());
	if( error_val.fail() )
	  return error_val;
     }
   }
  chkpt.close();
  return NO_ERROR;
}

ErrorType TransactionManager::rollback(void)
{
  // reload all the transaction Tuples and Gid's that were inned
  // but not committed at the time of failure
  CheckPoint chkpt(zero_gid);
  ErrorType er = chkpt.open(READ_CHKPT);
  if(er.fail())
    return er;
  gid g;
  Tuple *t;
  TupleHandle temp;
  while((t = chkpt.read_tuple(g))) {
     assert(t->valid());
     assert(g != zero_gid);
     TupleGroup *group = ObjectSpace::group_mgr.find_group(g);
     assert(group);
     assert(t->identifier() != zero_physid);
     group->insert_tuple(temp, t, t->identifier());
  }
  chkpt.close();
  return NO_ERROR;
}
// -----------------------------------------------------------------------
// find, create and destroy transaction objects
// -----------------------------------------------------------------------

Transaction*   
TransactionManager::create_transaction(Process* proc) {
   transid id = Transaction::get_next_transid();
   Transaction* trans = new Transaction(proc,id);

//   trans->start(proc);
   trans_list.append(trans);
   return trans;
}


Transaction*   
TransactionManager::find_transaction(const transid& id) {
  Pix t_cur;
  for(t_cur=trans_list.first(); t_cur!=0; trans_list.next(t_cur)) {
    Transaction* trans = trans_list(t_cur);
    if(trans->identifier() == id) {
      return trans;
    }
  }
  return 0;
}


int
TransactionManager::destroy_transaction(Transaction* trans) {
  Pix t_cur;
  for(t_cur=trans_list.first(); t_cur!=0; trans_list.next(t_cur)) {
    Transaction* c_trans = trans_list(t_cur);
    if(trans->identifier() == c_trans->identifier()) {
      trans_list.del(t_cur);
      delete trans;
      return 1;
    }
  }
  return 0;
}


void 
TransactionManager::dump(ofstream& log) {

  log << "\n ============ Transaction Manager ============= \n";

  int idx =1;
  Pix t_cur;
  for(t_cur=trans_list.first(); t_cur!=0; trans_list.next(t_cur), ++idx) {
    Transaction* c_trans = trans_list(t_cur);
    log << dec(idx) << ". " << c_trans->print() << "\n";
  }

  log << "\n ============================================== \n";

  log.flush();
}
