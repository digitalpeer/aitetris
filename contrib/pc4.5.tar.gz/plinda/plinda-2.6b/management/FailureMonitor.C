// This may look like C code, but it is really -*- C++ -*-
//
// File:     FailureMonitor.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//


#include "FailureMonitor.h"
#include "Scheduler.h"
#include "ProcessManager.h"
#include "ObjectSpace.h"

#ifdef _OUTLINE_
#define inline
#include "FailureMonitor.iC"
#endif


// constructor
FailureMonitor::FailureMonitor(void) {
  x_phase = EXAMINE_PHASE;
}


// invoke failure detection 
int
FailureMonitor::handle_timeout(const Time_Value& , const void*) {
  // ProcessManager::check_failure only find failure, but does not handle it.
  // Scheduler will call ProcessManager::handle_failure to deal with it
  // if there is any failure.

  if(ObjectSpace::proc_mgr.check_failure(x_phase) > 0) {
    ObjectSpace::scheduler.detect_failure();
  }

  // switch to the other phase.
  if(x_phase == CONCLUDE_PHASE) 
    x_phase = EXAMINE_PHASE;
  else 
    x_phase = CONCLUDE_PHASE;

  return 0;
}





