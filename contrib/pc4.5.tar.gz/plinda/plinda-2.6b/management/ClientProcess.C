
// This may look like C code, but it is really -*- C++ -*-
//
// File:        ClientProcess.C
// Description: 
// Created:  
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu

#include <stdio.h>
#include <sys/types.h>
#include <assert.h>

// PLinda header files
#include "ErrorType.h"
#include "System_Patterns.h"
#include "ServerCommLink.h"
#include "CheckpointManager.h"
#include "DaemonProcess.h"
#include "ClientProcess.h"
#include "Transaction.h"
#include "TupleGroup.h"
#include "ProcessManager.h"
#include "TransactionManager.h"
#include "TupleGroupManager.h"
#include "ObjectSpace.h"
#include "EventLog.h"
#include "Snapshot.h"



#include "Timer.h"

#ifdef _OUTLINE_
#define inline
#include "ClientProcess.iC"
#endif

#ifdef  AUTO_FAULT_MODE
#include "FaultLevelManager.h"
#endif

ClientProcess::ClientProcess(procid my_pid, 
			     procid parent_pid,
			     const physid& arg_id,int interactive) 
#ifdef __GNUG__
: Process(CLIENT, my_pid) , interactive_(interactive)
#else
: Process(PLINDA_CLIENT, my_pid) , interactive_(interactive)
#endif
{
   x_parent_id = parent_pid;
   x_arg_id = arg_id;

   x_trans = 0;
   x_temp_trans = 0;
   x_cur_request.header = 0;
   x_cur_request.tuple = 0;
   x_next_request.header = 0;
   x_next_request.tuple = 0;
   x_n_step = 0;
   x_blocked_request.header = 0;
   x_blocked_request.tuple = 0;
   x_b_step = 0;
   x_tuple_handle.clear();

   x_blk_request = 0;
   x_blk_group = 0;

   x_in_file = 0;
   x_private_log = 0;
   x_flush_flag = 0;

   // at the beginning, the server and each process are consistent.
   x_inconsistency_flag = 0;

#ifdef AUTO_FAULT_MODE
   x_continuation_size = 0;
#endif
   
   // NOTE: chkpt_mgr must already have recovered all the data 
   // when ClientProcess objects are created.
   // log existence flag 
   x_log_flag = ObjectSpace::chkpt_mgr.chkpt_dir_status();
   // directory where to store a snapshot.
   x_cur_log_dir = ObjectSpace::chkpt_mgr.next_chkpt_dir();
   // directory where to store a snapshot.
   x_last_log_dir = ObjectSpace::chkpt_mgr.last_chkpt_dir();

   x_daemon_proc = 0;
   x_group_list.clear();
   x_exec_name = NULL;
   x_file = 0;
   x_lineno = 0;

   x_steps_to_run = 0;
   x_single_stepping = 0;
}

ClientProcess::~ClientProcess(void) {
   if(x_cur_request.header)
     delete x_cur_request.header;
   if(x_cur_request.tuple)
     Tuple::destroy(x_cur_request.tuple);
   if(x_next_request.header)
     delete x_cur_request.header;
   if(x_next_request.tuple)
     Tuple::destroy(x_next_request.tuple);
   if(x_blocked_request.header)
     delete x_blocked_request.header;
   if(x_blocked_request.tuple)
     Tuple::destroy(x_blocked_request.tuple);

   if (x_file != 0) delete [] x_file;
   x_file = 0;
   delete [] x_exec_name;
}


ErrorType
ClientProcess::check_for_errors(const Header &header,const Tuple *tuple) {
   if(!(header.status())) {
      return header.status();
   }

   if(header.clientRequest() != PROC_START) {
      if(header.clientRequest() != LOG_FLUSH) {
	 // process only receive requests in the RUNNING status.
	 if(status() == REQUEST_BLOCKED || status() == COMPLETED) {
	    return E_INV_STATUS;
	 }
      }

      // the transient id must be the same.
      if(transient_id() != header.transientId()) {
	 return E_ALREADY_FAIL;
      }
   } else {
      // only two cases where PROC_START can be received.
      if(status() != DISPATCHED && status() != FAILURE_HANDLED) {
	 return E_INV_STATUS;
      }
   }
   if(header.tupleLength() == 0 && tuple)
     return E_INV_MESSAGE;
   //   if(header.tupleLength() && ! tuple)
   //     return E_INV_MESSAGE;
   //   if(header.tupleLength() && header.tupleLength() != tuple->length())
   //     return E_INV_MESSAGE;
   if(tuple && !tuple->valid())
     return E_INV_MESSAGE;
   return NO_ERROR;

}


TupleGroup* ClientProcess::find_group(const gid&  g) 
{
   Pix g_cur;
   for(g_cur = x_group_list.first(); g_cur != 0; x_group_list.next(g_cur)) {
      TupleGroup* group = x_group_list(g_cur);
      if(group->get_grpid() == g) {
	 return group;
      }
   }

   TupleGroup* group = ObjectSpace::group_mgr.open_group(g);
   if(group != 0) {
      x_group_list.prepend(group);
   }
   return group;
}


// each tuple group maintains a reference count.
// when opened by a process, it increases its reference count by one;
// it decreases the count by one when closed.

void ClientProcess::close_groups(void) {
   Pix g_cur;
   for(g_cur = x_group_list.first(); g_cur != 0; x_group_list.next(g_cur)) {
      TupleGroup* group = x_group_list(g_cur);
      ObjectSpace::group_mgr.close_group(group);
   }
}


// Due to log replies, the server can receive multiple messages
// from a client process. (usually, up to two messages are enqueued).

void 
ClientProcess::enqueue_request(Header *header, Tuple *tuple) {

   assert(header);
   file(header->fileName());
   lineno(header->lineNum());
   if(x_cur_request.header == 0) {
      x_cur_request.header = header;
      x_cur_request.tuple = tuple;
      next_step(1);
      if(header->clientRequest() == TUPLE_CREATIONS) {
	 assert(outList.length() == 0);
	 outList.append(tuple);
	 x_cur_request.tuple = NULL;
      } else if(header->clientRequest() == XCOMMIT && tuple) {
	 assert(tuple->valid());
	 assert(tuple->numOfFields() == 3);
	 assert(outList.length() == 0);
	 int numTuples,*tupleLengths;
	 char *buf,*cur;
	 tuple->read(0, TupleField::PLint, numTuples);
	 tuple->read(1, TupleField::PLint, tupleLengths);
	 buf = cur = tuple->innerTuples();

	 for(int i = 0 ; i < numTuples ; i++) {
	    Tuple *curTuple = (Tuple*)new char[tupleLengths[i]];
	    memcpy(curTuple, cur, tupleLengths[i]);
	    curTuple->updatePointers();
	    assert(curTuple->valid());
	    assert(curTuple->length() == tupleLengths[i]);
	    cur += tupleLengths[i];
	    outList.append(curTuple);
	 }
	 Tuple::destroy(tuple);
	 delete [] tupleLengths;
	 x_cur_request.tuple = NULL;
      }
   } else {
      assert(x_next_request.header == 0);
      // this should be a log request
#ifndef NDEBUG
      if(header->clientRequest() != LOG_FLUSH)  {
	 cout << "BAD, PLinda getting a second message queued that is not" <<
	   " log flush "  << header->clientRequest() << endl << flush;
      }
#endif
      x_next_request.header = header;
      x_next_request.tuple = tuple;
      x_n_step = 1;
   }

   // informs the daemon that there has been a message; in other words,
   // the processor is still fine.
   if(x_daemon_proc != 0) 
     x_daemon_proc->set_alive_flag(1);
}

#undef NDEBUG

void
ClientProcess::destroy_current_request() {
   /* now it is ready to take more requests (=> RUNNING status) */
   if(x_cur_request.header != 0) {
      if(x_cur_request.header->clientRequest() != TUPLE_CREATIONS &&
	 x_cur_request.header->clientRequest() != LOG_FLUSH &&
	 x_cur_request.header->clientRequest() != XCOMMIT &&
	 x_cur_request.tuple) { 
	 // do not destroy the tuple if it was the case that it was
	 // put into tuple space. this may cause a memory leak if
	 // there was a failure and the tuple did not quite make it
	 // into tuple space yet. That is it was enqeued but never
	 // gotten to.
	 Tuple::destroy(x_cur_request.tuple);
      }
      x_cur_request.tuple = NULL;

      delete x_cur_request.header;
      x_cur_request.header = NULL;
   }

   if(status() == REQUEST_READY) {
      status(RUNNING);
   }
   // if we have another message in the queue,
   if(x_next_request.header != 0) {
      x_cur_request = x_next_request;
      next_step(x_n_step);
      x_next_request.header = NULL;
      x_next_request.tuple = NULL;
      x_n_step = 0;
   }
}



// ----------------------------------------------------------------------------
// Service requests from cliets.
// ----------------------------------------------------------------------------
int ClientProcess::handle_request(void) 
{
   HeaderAndTuple &request = x_cur_request;

   assert(x_daemon_proc);
   assert(x_daemon_proc->username());
   assert(!single_stepping());
   assert(x_cur_request.header != 0);
   assert(run_mode() == RECORDING);
   
   Header reply;
   reply.clientRequest(request.header->clientRequest());
   reply.transientId(transient_id());
#ifndef NDEBUG
   {
      ErrorType stat;
      if(!(stat = check_for_errors(*request.header,request.tuple))) {
	 reply.status(stat);
	 cout << "The server got a bad message\n" << flush;
	 if(send_reply(reply) == -1) 
	   declare_failure();
	 return 0;
      }
   }
#endif
   if(request.header->xstart()) {
     // later make this into part of the client request so that this
     // can go in the switch 
     assert(x_trans == 0);
      x_trans = ObjectSpace::trans_mgr.create_transaction(this);
      assert(x_trans != 0);
      request.header->xstart(0); 
      // if a blocking request we will reenter this code
   }
   Transaction *cur_trans = NULL;
   Tuple *curTuple = NULL;
   Tuple::OpType opType;
   TupleGroup *group = NULL;
   char* groupName = NULL;
   Tuple *replyTuple;

   switch(request.header->clientRequest()) {
    case NUM_MACHINES:
      replyTuple = Tuple::create(1,0);
      replyTuple->setActual(0, TupleField::PLint, 
			    ObjectSpace::proc_mgr.num_machines());
      reply.tupleLength(replyTuple->length());
      if(send_reply(reply,replyTuple) == -1) 
	declare_failure();    
      Tuple::destroy(replyTuple);
      replyTuple = NULL;
      break;
    case XCOMMIT:
    case TUPLE_CREATIONS: 
      cur_trans = x_trans == 0 ? start_temp_trans() : x_trans;
      curTuple = NULL;
      for(Pix p = outList.first() ; p ; outList.next(p)) {
	curTuple = outList(p);
	assert(curTuple);
	assert(curTuple->opType() != Tuple::XCOMMIT ||
	       (outList.next(p), p == NULL));
	if(curTuple->opType() == Tuple::XCOMMIT) {
	  break;
	}
	if(curTuple->opType() == Tuple::EVAL) {
	   assert(curTuple->group() == zero_gid);
	    cur_trans->eval_tuple(curTuple);
	 } else {
	   assert(curTuple->opType() == Tuple::OUT);
	   assert(curTuple->group() != zero_gid);
	   TupleGroup *  group = find_group(curTuple->group());
	    assert(group); // later change this to more friendly
	    assert(curTuple->identifier() == zero_physid);
	    x_tuple_handle.set(group, curTuple);
	    cur_trans->access_tuple(group, x_tuple_handle, Tuple::OUT);
	 }
	 curTuple = NULL;
      }
      outList.clear();
      x_cur_request.tuple = curTuple; // this may be a log tuple
      assert(!curTuple || curTuple->opType() == Tuple::XCOMMIT);

      if(send_reply(reply) == -1) 
	declare_failure();    
      assert((x_trans == 0 &&
	      request.header->clientRequest() == TUPLE_CREATIONS) ||
	     ( x_trans && request.header->clientRequest() == XCOMMIT));
      xcommit();
      break;			  
    case IN:
    case RD: 
      opType = 
	request.header->clientRequest() == RD ? Tuple::RD : Tuple::IN;
      // IN may block if there is no matching tuple found. 
      // so we simulate threading.
      switch(next_step()) {
       case 1:
	 cur_trans = x_trans == 0 ? start_temp_trans() : x_trans;
	 group = find_group(request.header->g());
	 x_tuple_handle.clear();
#ifndef NDEBUG
	 if(group == 0) {
	    cerr << "PLinda user error: trying to in/rd to a " <<
	      "bad tuple handle. restart the computation\n" << flush;
	    terminate();
	    reply.status(E_INV_GID);
	    send_reply(reply);
	    declare_error(E_INV_GID);
	    return 0;
	 }
#endif
	 group->retrieve_tuple(x_tuple_handle,request.tuple, opType);

	 if(request.header->synchronyType()==BLOCK &&
	    !x_tuple_handle.valid()) {
	    Pix cur = group->block_request(this, cur_trans, 
					   request.tuple, opType);
	    block(2, group, cur);
	    return 0;
	 }
	 else if(x_tuple_handle.valid()) {
	    cur_trans->access_tuple(group, x_tuple_handle, opType);
	 }
	 break;
       case 2:
	 // we got back the tuple from the block, the tuple group
	 // called Transaction::access_tuple for us
	 // nothing special.
	 break;
       default:
	 assert(0);
      }
      assert(request.header->synchronyType() == NOBLOCK || 
	     x_tuple_handle.valid());
      assert((x_tuple_handle.valid() && x_tuple_handle.tuple()) ||
	     (!x_tuple_handle.valid() && !x_tuple_handle.tuple()));

      reply.tupleLength((x_tuple_handle.valid() ? 
			 x_tuple_handle.tuple()->length() : 0));
      
      if(send_reply(reply, x_tuple_handle.tuple()) == -1) 
	 declare_failure();
      assert(request.header == x_cur_request.header);
      assert(request.tuple == x_cur_request.tuple);
      if(x_trans == 0)			  
	xcommit();
      break;
    case CREATE_GROUP:   
      cur_trans = x_trans == 0 ? start_temp_trans() : x_trans;
      assert(request.tuple);

      request.tuple->read(0,TupleField::PLchar, groupName);
      group = ObjectSpace::group_mgr.create_group(this, cur_trans, groupName);
      delete  [] groupName;
      groupName= NULL;
      assert(group);
      reply.g(group->get_grpid());
      if(send_reply(reply) == -1) 
	declare_failure();
      assert(request.header == x_cur_request.header);
      assert(request.tuple == x_cur_request.tuple);
      if(x_trans == 0) 
	xcommit();
      break;
    case ARG_RDP: 
      cur_trans = x_trans == 0 ? start_temp_trans() : x_trans;
      ObjectSpace::proc_mgr.retrieve_argument(x_tuple_handle, cur_trans,
					      request.tuple, 
					      x_arg_id);
      assert((x_tuple_handle.valid() && x_tuple_handle.tuple()) ||
	     (!x_tuple_handle.valid() && !x_tuple_handle.tuple()));
      reply.tupleLength((x_tuple_handle.valid() ? 
			 x_tuple_handle.tuple()->length() : 0));
      if(send_reply(reply,x_tuple_handle.tuple()) == -1) 
	declare_failure();
      if(x_trans == 0) 
	xcommit();
      break;
    case XRECOVER:
      if(x_log_flag == 0) {
	 // currently no private log; no transaction has ever committed.
	 if(send_reply(reply) == -1) {
	    declare_failure();
	 }
	 break;
      }
      if(x_in_file) {
	 assert(x_private_log == 0);
	 // recover private log.
	 assert(load_private_log(x_last_log_dir));
      } 

      if(x_private_log == 0) {
	 // checkpoint directory does not contain a snapshot for this process.
	 x_log_flag = 0;
	 if(send_reply(reply) == -1) {
	    declare_failure();
	 }
      } else {
	 assert(x_private_log);
	 reply.tupleLength(x_private_log->length());
	 if(send_reply(reply, x_private_log) == -1) {
	    declare_failure();
	 }
      }
      if(x_in_file) {
	 Tuple::destroy(x_private_log);
	 x_private_log = 0;
      }
      break;
    case LOG_FLUSH:
      // only received when we are checkpointing the global state.
      // In AUTO_FAULT_MODE case, we will ask the client to send back the
      // fault level changing information
#ifndef AUTO_FAULT_MODE
      assert(ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT) ||
	     ObjectSpace::check_ft_degree(MESSAGE_REPLAY));
#endif
      if(logging_mode() == LOGGING_ON) {
	 ObjectSpace::snapshot_mgr.complete_psnapshot(identifier());
	 logging_mode(LOGGING_OFF);
      }

      if(request.tuple) {
	 // construct a tuple.
	 if(x_private_log != 0) {
	    assert(x_in_file == 0);
	    Tuple::destroy(x_private_log);
	    x_private_log = 0;
	 }
	 x_private_log = request.tuple;
	 
#ifdef AUTO_FAULT_MODE
	 // tell Fault level manager about this process's continuation size as
	 // early as possible
	 if ( x_continuation_size == 0 ){
	    x_continuation_size = x_private_log->length();
	    ObjectSpace::ftlvl_mgr.add_one_continuation(x_continuation_size);
	 }
#endif
	 
	 if(x_private_log->length() > PL_MAX_IN_MEMORY_LOG_SZ) {
	    // write the current private log to disk.
	    store_private_log(x_cur_log_dir);
	    // now, the last private log is found in the current directory.
	    x_last_log_dir = x_cur_log_dir;
	    x_in_file = 1;
	    Tuple::destroy(x_private_log);
	    x_private_log = 0;
	 } else {
	    x_in_file = 0;
	 }

	 // turn the log flag on.
	 x_log_flag = 1;
	 
      } else {
	 if(x_private_log != 0) {
	    Tuple::destroy(x_private_log);
	    x_private_log = 0;
	    x_in_file = 0;
	 }
	 x_log_flag = 0;
      }
      

      // now the server state and the local state of this process
      // become consistent.
      x_inconsistency_flag = 0;

      // message log is flushed
      x_flush_flag = 0;
      destroy_current_request();
      break;

    case PROC_START:
      // more than one process with the same process identifier may run
      // and try to communicate with the server at the same time.
      // we need to distinguish them.
      transient_id(request.header->transientId());
      if(x_daemon_proc != 0) 
	ObjectSpace::cleanup_log(x_daemon_proc->hostname(), 
				 x_daemon_proc->username(),transient_id());
      else 
	ObjectSpace::cleanup_log(0, NULL, identifier());
      
      // inform this client whether it restarts after failure.
      if(status() == FAILURE_HANDLED) 
	reply.restartFlag(1);
      // inform this client of the current fault tolerance level.
      if(ObjectSpace::check_ft_degree(NO_SUPPORT)) {
	 reply.ftMode(Header::NO_FT);
      } else if(ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT)) {
	 reply.ftMode(Header::GLOBAL_FT);	
      } else if(ObjectSpace::check_ft_degree(MESSAGE_REPLAY)) {
	 reply.ftMode(Header::REPLAY_FT);	
      } else {
	 reply.ftMode(Header::PRIVATE_FT);	
      } 
      if(send_reply(reply) == -1) 
	declare_failure();
      // reset the status.
      status(RUNNING);
#ifdef AUTO_FAULT_MODE
      ObjectSpace::ftlvl_mgr.add_one_process();
#endif
      break;
    case PROC_END:
      // inform the link that the process has terminated.;
      status(COMPLETED);
      comm_link()->set_done();
      // shutdown the link.;
      delete comm_link();
      comm_link(0);
      // clean up the state;
      cleanup_state();
      // remove the tuple in proc_group and the current psnapshot.;
      remove_persistent_identity();
      // inform the global snapshot manager.;
      ObjectSpace::snapshot_mgr.complete_psnapshot(identifier());
#ifdef AUTO_FAULT_MODE
      ObjectSpace::ftlvl_mgr.delete_one_process();
      ObjectSpace::ftlvl_mgr.delete_one_continuation(x_continuation_size);
#endif
      break;
    default:
      assert(0);
   }
   destroy_current_request();
   return 1;
}

int ClientProcess::xcommit()
{
   if(x_trans == 0)   {
      commit_temp_trans();
      return 1;
   }
#ifndef NDEBUG       
   if(!x_trans->check_for_committability()) {
      x_trans->abort();
      ObjectSpace::trans_mgr.destroy_transaction(x_trans);
      x_trans = 0;
      declare_error(E_COMMIT_FAIL);
      return 0;
   }
#endif
   if(ObjectSpace::check_ft_degree(PRIVATE_SNAPSHOT)) { 
      if(x_cur_request.tuple) {
	 if(x_private_log) {
	    assert(x_in_file == 0);
	    Tuple::destroy(x_private_log);
	    x_private_log = 0;
	 }
	 x_private_log = x_cur_request.tuple;
#ifdef AUTO_FAULT_MODE
	 if ( x_continuation_size == 0 ){
	    x_continuation_size = x_private_log->length();
	    ObjectSpace::ftlvl_mgr.add_one_continuation(x_continuation_size);
	 }
#endif
	 if(x_private_log->length() > PL_MAX_IN_MEMORY_LOG_SZ) {
	    // write the current private log to disk.
	    store_private_log(x_cur_log_dir);
	    x_last_log_dir = x_cur_log_dir;
	    x_in_file = 1;
	    Tuple::destroy(x_private_log);
	    x_private_log = 0;
	 } else {
	    x_in_file = 0;
	 }
	 
	 // turn the log flag on.
	 x_log_flag = 1;
      } else {
	 // process has no state. 
	 // we destroy the current log, but do not bother 
	 // to destroy the log file.
	 if(x_private_log != 0) {
	    assert(x_in_file == 0);
	    Tuple::destroy(x_private_log);
	    x_private_log = 0;
	 } 
	 // no private snapshot
	 x_log_flag = 0;
      }

      // In PRIVATE_SNAPSHOT, consistency is always guaranteed.
      x_inconsistency_flag = 0;

   } else {
      // this client has not updated private log here;
      // and thus consistency is broken.
      x_inconsistency_flag = 1;
   }

   // do commit this transaction.
   x_trans->commit();
   ObjectSpace::trans_mgr.destroy_transaction(x_trans);
   x_trans = 0;
   return 1;
}

int
ClientProcess::load_private_log(CheckpointManager::ChkptDirType dir) {

   // locate the directory.where the last log is stored.
   ObjectSpace::chkpt_mgr.change_dir(dir);
   
   char name[100];
   ::sprintf(name, "%ld.log", identifier());

   int fd = ::open(name, O_RDONLY);
   if(fd == -1) {
      x_log_flag = 0;
      x_private_log = 0;
      return 0;
   }

   int size;
   if(::read(fd, (char*)&size, PL_INT_SZ) != PL_INT_SZ) return 0;
   char* buffer = new char [size];
   if(::read(fd, buffer, size) != size) {
      x_log_flag = 0;
      x_private_log = 0;
      delete[] buffer;
      ::close(fd);
      return 0;
   }
   ::close(fd);

   x_private_log = (Tuple*)buffer;
   x_private_log->updatePointers();
   assert(x_private_log->valid());

#ifdef AUTO_FAULT_MODE
   // tell Fault level manager about this process's continuation size as
   // early as possible
   if ( x_continuation_size == 0 ){
      x_continuation_size = x_private_log->length();
      ObjectSpace::ftlvl_mgr.add_one_continuation(x_continuation_size);
   }
#endif

   return 1;
}



int
ClientProcess::store_private_log(CheckpointManager::ChkptDirType dir) {
   char name[100];
   ::sprintf(name, "%ld.log", identifier());

   int fd = ::open(name, O_CREAT|O_TRUNC|O_WRONLY, 0644);
   if(fd == -1) return 0;

   if(x_private_log == 0 || x_log_flag == 0) {
      ::close(fd);
      return 0;
   }

   // locate the current log directory.
   ObjectSpace::chkpt_mgr.change_dir(dir);

   char buffer[PL_INT_SZ];
   st_int(x_private_log->length(),buffer);
   

   if(::write(fd, buffer, PL_INT_SZ) != PL_INT_SZ) {
      cerr << "PLinda Error in writing to disk...\n" << flush;
      ::close(fd);
      return 0;
   }
   assert(x_private_log->valid());
   if(::write(fd, x_private_log, x_private_log->length()) !=
      x_private_log->length()) {
      cerr << "PLinda Error in writing to disk...\n" << flush;
      ::close(fd);
      return 0;
   }

   ::close(fd);

   return 1;
}

// this function is called by ProcessManager::checkpoint
int
ClientProcess::checkpoint_private_log(void) {
   // already terminated; nothing to do any more.
   if(status() == COMPLETED) return 1;

   assert(ObjectSpace::chkpt_mgr.next_chkpt_dir() == x_cur_log_dir);

   if(x_in_file == 0) 
     store_private_log(x_cur_log_dir);


   // alternate to the other directory for private log.
   x_last_log_dir = ObjectSpace::chkpt_mgr.next_chkpt_dir();
   x_cur_log_dir = ObjectSpace::chkpt_mgr.last_chkpt_dir();

   return 1;
}


// this function is called by ProcessManager::rollback.
int 
ClientProcess::restore_private_log(void) {
   x_last_log_dir = ObjectSpace::chkpt_mgr.last_chkpt_dir();
   x_cur_log_dir = ObjectSpace::chkpt_mgr.next_chkpt_dir();

   if(ObjectSpace::chkpt_mgr.chkpt_dir_status() == 0) {
      x_log_flag = 0;
      x_in_file = 0;
      x_private_log = 0;
      return 1;
   }

   ObjectSpace::chkpt_mgr.change_dir(x_last_log_dir);

   char name[100];
   ::sprintf(name,"%ld.log",identifier());
   
   int fd;
   if((fd = ::open(name, O_RDONLY)) != -1) {
      x_log_flag = 1;
   } else {
      x_log_flag = 0;
      x_in_file = 0;
      x_private_log = 0;
      return 1;
   }
   int size;
   if(::read(fd, (char*)&size, PL_INT_SZ) != PL_INT_SZ) return 0;
   if(size > PL_MAX_IN_MEMORY_LOG_SZ) {
      // too big as in memory log tuple.
      x_in_file = 1;
      x_private_log = 0;
      ::close(fd);
      return 1;
   }
   
   char* buffer = new char[size];
   if(::read(fd, buffer, size) != size) {
      cerr << "PLinda ERROR reading from disk\n" << flush;
      delete[] buffer;
      ::close(fd);
      x_log_flag = 0;
      x_in_file = 0;
      x_private_log = 0;
      return 0;
   }

   x_private_log = (Tuple*)buffer;
   x_private_log->updatePointers();
   assert(x_private_log->valid());
   x_in_file = 0;
   ::close(fd);

   return 1;
}




// this function is called by the scheduler at any time.
int 
ClientProcess::request_psnapshot(int msg_flush) {
   // this should be called when the current state is dirty.
#ifndef AUTO_FAULT_MODE
   // In AUTO_FAULT_MODE case, we may permit the x_inconsistency_flag is 0
   assert(x_inconsistency_flag == 1);
#endif

   if(msg_flush == 0) {
      // this is called for checkpointing.
      // after replay, we may encounter (logging_mode() == LOGGING_ON) 
      // which has been delayed.  
      // assert(logging_mode() == LOGGING_OFF);

      // include this in checkpointing.
      logging_mode(LOGGING_ON);

      if(x_flush_flag == 1) {
	 // request is already sent.
	 return 1;
      }

   } else {
      // this is called for flushing the message log.
      if(x_flush_flag == 1) {
	 // request is already sent.
	 return 1;
      }
      x_flush_flag = 1;

      if(logging_mode() == LOGGING_ON) {
	 // request is already sent.
	 return 1;
      }
   }

   // in the following cases, we do not call this function.
   assert(status() != EVALED && status() != DISPATCHED && 
	  status() != COMPLETED);

   assert(run_mode() == RECORDING);

#ifndef AUTO_FAULT_MODE
   if(status() == FAILURE_DETECTED || status() == FAILURE_HANDLED) {
      assert(ObjectSpace::check_ft_degree(MESSAGE_REPLAY));
      return 1;
   }
#else
   // now we need to consider the fault tolerant mode changing
   if ( status() == FAILURE_DETECTED ){
      assert( ! ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT));
      if ( ObjectSpace::check_ft_degree(PRIVATE_SNAPSHOT)){
	 // we need not change the ft_mode, it will be set at failure_handler
	 ObjectSpace::snapshot_mgr.complete_psnapshot(identifier());
	 logging_mode(LOGGING_OFF);
      }
   }
   else if ( status() == FAILURE_HANDLED){
      assert( ! ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT));
   }
#endif

   // send a LOG_REQ request to the client process.

   Header req;
   req.clientRequest(LOG_REQ);
   req.transientId(transient_id());


#ifdef AUTO_FAULT_MODE
   if ( ObjectSpace::ftlvl_mgr.is_need_change_ft_level() ){
      switch(ObjectSpace::ftlvl_mgr.get_new_ft_level()){
       case NO_SUPPORT: req.set_no_ft(); break;
		      case GLOBAL_SNAPSHOT: req.set_global_ft(); break;
		      case MESSAGE_REPLAY: req.set_replay_ft(); break;
		      case PRIVATE_SNAPSHOT: req.set_private_ft(); break;
		     }

   } // else do not set ft_level
#endif

   if(comm_link() == 0 || status() == FAILURE_DETECTED) {
      declare_failure();
      return -1;
   }
   if(comm_link()->send(req) == -1) {
      declare_failure();
      return -1;
   }
   return 1;
}


int 
ClientProcess::send_reply(Header &header,const Tuple *tuple) {
   status(RUNNING);

#if 0
   ::printf("Process %d starts to send a reply\n", identifier());
#endif

   if(comm_link() == 0 || status() == FAILURE_DETECTED) {
#ifdef PL_DEBUG
      cout << "ClientProcess::send_reply found comm_link = 0 or already "
	<< "  a failure\n" << flush;
#endif
      return -1;
   }
   if(comm_link()->send(header,tuple) == -1)  {
#ifdef PL_DEBUG
      cout << "ClientProcess::send_reply could not use comm link to send" << 
	" a reply\n" << flush;
#endif
      return -1;
   }
   return 0;
}


void
ClientProcess::cleanup_state(void) {
   // abort the active transaction, if any.  --------------------------------

   if(x_trans != 0) {
      x_trans->abort();
      ObjectSpace::trans_mgr.destroy_transaction(x_trans);
      x_trans = 0;
   }
   if(x_temp_trans != 0) 
     abort_temp_trans();

   if(outList.length() != 0) {
      // there is a pending tuple creation/xcommit operation
      for(Pix p = outList.first(); p ; outList.next(p)) {
	 Tuple *t = outList(p);
	 Tuple::destroy(t);
      }
      outList.clear();
      assert(outList.length() == 0);
   }
   destroy_current_request();
   next_step(0);

   if(x_next_request.header != 0) {
      if(x_next_request.tuple) {
	 Tuple::destroy(x_next_request.tuple);
      }
      x_next_request.header = 0;
      x_next_request.tuple = 0;
      x_n_step = 0;
   }

   /* inform its daemon to get it off its list */
   if(x_daemon_proc != 0) {
      x_daemon_proc->complete(identifier()); // earlier it was fail(..)
   }
   x_daemon_proc = 0;


   // if blocked, then delete the blocking entry. ----------------------

   if(x_blk_group != 0) {
      x_blk_group->delete_blocked_request(this, x_blk_request);
      x_blk_group = 0;
      x_blk_request = 0;
      if(x_blocked_request.tuple) {
	 //      Tuple::destroy(x_blocked_request->patterns(0));
      }
      //    delete x_blocked_request;
      x_blocked_request.header = 0;     x_blocked_request.tuple = 0;
      x_b_step = 0;
   }

   /* destroy the commlink obj since it is owned by it */
   if(comm_link() != 0) {
      comm_link()->shutdown();
      delete comm_link();
      comm_link(0);
   }
}


void
ClientProcess::remove_persistent_identity(void) {
   // process termination also requires a sequence of operations.
   // therefore, we perform it as a transaction so that we can
   // later redo it even if we fail in middle of termination.
   {
      Transaction* end_trans;
      end_trans = ObjectSpace::trans_mgr.create_transaction(this);

      // update proc_group and arg_group.
      ObjectSpace::proc_mgr.terminate_PROCESS(end_trans, this);
      end_trans->commit();
      ObjectSpace::trans_mgr.destroy_transaction(end_trans);
   }
   // destroy the current psnapshot.
   if(x_log_flag == 1 && x_private_log != 0) {
      assert(x_in_file == 0);
      Tuple::destroy(x_private_log);
      x_private_log = 0;
      x_log_flag = 0;
   }

   // decrement reference counts of groups.
   close_groups();

}


void
ClientProcess::declare_error(ErrorType err) {
   // set the error type  
   error(err);
   status(ERROR_FOUND);
#ifdef PL_DEBUG
   cerr << "ClientProcess error found: " << err.message() << endl <<  flush;
#endif
   // shutdown the communication link.
   if(comm_link() != 0) {
      comm_link()->set_done(); 
      comm_link()->shutdown();
      delete comm_link();
      comm_link(0);
   }

}


// this process won't continue and so remove info about it.
void
ClientProcess::handle_error(void) {
   // clean up state work. 
   // daemon is also informed in this call...
   cleanup_state();

   // remove persistent information about this process.
   remove_persistent_identity();

   // if psnapshot is requested, then inform global snapshot manager.
   // the client process must have already ignored the request.
   // in the sequential mode, this process may not have been requested.
   ObjectSpace::snapshot_mgr.complete_psnapshot(identifier());

   // in any case, we consider this as terminated.
   status(COMPLETED);

}


void
ClientProcess::declare_failure(void) {
   // already found or handled.
   // assert(!failure_handled() && !failure_detected());

   // if fault tolerance is disabled, then failure is treated as error.
   // therefore, no reaction is taken.

   if(ObjectSpace::check_ft_degree(NO_SUPPORT)) {
      declare_error(E_FAIL);
      return;
   }

   status(FAILURE_DETECTED);
   if(comm_link() != 0) {
      comm_link()->shutdown();
      delete comm_link();
      comm_link(0);
   }
}


void
ClientProcess::handle_failure(void) {
   // already handled.
   assert(!failure_handled());

   // if we already receive PROC_END, then we ignore failure. 
   if(x_cur_request.header != 0) {
      if(x_cur_request.header->clientRequest() == PROC_END) {
	 status(Process::REQUEST_READY);
	 return;
      }
   }
   if(x_next_request.header != 0) {
      if(x_next_request.header->clientRequest() == PROC_END) {
	 status(Process::REQUEST_READY);
	 return;
      }
   }

   // clean up the intermediate work. 
   cleanup_state();


   // set the status. 
   status(FAILURE_HANDLED);

   
   // shutdown the communication link. 
   if(comm_link() != 0) {
      delete comm_link();
      comm_link(0);
   }


   // prepare for respawning 


   //   Transaction* spawn_trans = ObjectSpace::trans_mgr.create_transaction(this);
   assert(x_trans == 0);

   // respawn this process; move tuple from proc group to eval group.
   ObjectSpace::proc_mgr.respawn_PROCESS(identifier());

   //   spawn_trans->commit();
   //   ObjectSpace::trans_mgr.destroy_transaction(spawn_trans);


   // turn on the replay mode.
   if(ObjectSpace::check_ft_degree(MESSAGE_REPLAY)) {
      assert(0);
      run_mode(REPLAYING);
   }
#ifdef AUTO_FAULT_MODE
   ObjectSpace::ftlvl_mgr.add_one_failure();
#endif

}


int
ClientProcess::check_failure(void) {
   if(comm_link() == 0) {
      return 0;
   }
   return comm_link()->check_failure();
}



void
ClientProcess::kill(void) {
   extern const char *REMOTESH;
   if(x_daemon_proc != 0) {
      char command[1000];
      assert(x_daemon_proc);
      assert(x_daemon_proc->username());
      ::sprintf(command, "%s %s -l %s kill -9 %ld", REMOTESH ,
		x_daemon_proc->hostname(),x_daemon_proc->username(), 
		transient_id());
      cerr << command << "\n";
      ::system(command);
   }
}


void
ClientProcess::terminate(void) {
   if(completed()) return;


   // shutdown the link.
   status(COMPLETED);
   if(comm_link() != 0) {
      comm_link()->set_done();
      delete comm_link();
      comm_link(0);
   }

   // kill the running process
   kill();
   // make sure to cleanup_state after kill so we know the username!
   // clean up the local state. 
   cleanup_state();

   // remove persistent info
   remove_persistent_identity();


   // inform the global snapshot manager.
   ObjectSpace::snapshot_mgr.complete_psnapshot(identifier());

}



// -------------------------------------------------------------------------

String
ClientProcess::print(void) const {
   String hold;
   hold = "client(\n";
   hold += Process::print();

   hold += ",daemon:";
   if(x_daemon_proc != 0) {
      hold += dec(x_daemon_proc->identifier());
   } else {
      hold += "0";
   }
   
   hold += ",trans:";
   if(x_trans != 0) {
      hold += (x_trans->identifier()).print();
   } else {
      hold += "zero_transid";
   } 

   hold += ",request:\n";
   if(x_cur_request.header != 0) {
      //    hold += x_cur_request.header->print(); Peter
   } else {
      hold += "?";
   }

   hold += ",\n argument:";
   hold += x_arg_id.print();
   
   hold += ")";

   return hold;
}








