// This may look like C code, but it is really -*- C++ -*-
//
// File:       LogManager.C
// Description 
// Created:  
// Author:     Karp Joo Jeong
// Mail:       jeong@cs.nyu.edu
//

#include "plinda_ids.h"

#include "LogManager.h"
class TupleHandle;

LogManager::LogManager(void) {
  // nothing
}

LogManager::LogManager(long size) {
  initialize(size);
}

void LogManager::initialize(long size) {
  x_log_buf_size = size;
  x_log_buffer = new char[size];
  x_avail_size = x_log_buf_size;
  x_cursor = 0;
}

LogManager::~LogManager(void) {
  delete[] x_log_buffer;
}


ErrorType
LogManager::replay(void) {
  return NO_ERROR;
}


int
LogManager::start_transaction(Process* , Transaction* ) {
  return 1;
}

int
LogManager::abort_transaction(Process* , Transaction*) {
  return 1;
}

int
LogManager::commit_transaction(Process* , Transaction* ) {
  return 1;
}

int
LogManager::in_tuple(Process* ,
		     Transaction* ,
		     const TupleHandle& ) {
  return 1;
}
  
int
LogManager::rd_tuple(Process*,
		     Transaction* ,
		     const TupleHandle&) {
  return 1;
}

int
LogManager::out_tuple(Process* ,
		      Transaction* ,
		      const TupleHandle& ) {
  return 1;
};
