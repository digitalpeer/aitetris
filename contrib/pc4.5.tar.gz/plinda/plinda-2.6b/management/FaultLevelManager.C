// This may look like C code, but it is really -*- C++ -*-
//
// File:     FaultLevelManager.C
// Created:  
// Author:   Jihai Qiu
// Mail:     jihai@cs.nyu.edu
//


#ifdef AUTO_FAULT_MODE

#include "FaultLevelManager.h"
#include "Scheduler.h"
#include "ProcessManager.h"
#include "ObjectSpace.h"

#ifdef _OUTLINE_
#define inline
#include "FaultLevelManager.iC"
#endif

// invoke fault tolerent level mode check 
// will reset i_in_tuple_size, i_out_tuple_size, i_failure_processes

int  FaultLevelManager::check_change_ft_level(void ){

  cerr << " Fault tolerent level mode check \n" << flush;

#ifdef PL_DEBUG_FT_MODE_OUT
  cerr << "failed_process = " << i_failed_processes ;
  if ( ObjectSpace::check_ft_degree(PRIVATE_SNAPSHOT))
	cerr<< " current mode is PRIVATE_SNAPSHOT \n";
  else if ( ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT))
	cerr<< " current mode is GLOBAL_SNAPSHOT \n";
  else if ( ObjectSpace::check_ft_degree(MESSAGE_REPLAY))
	cerr<< " current mode is MESSAGE_REPLAY \n";
  cerr << flush;
#endif

  need_change_ft_level = 0;
  if ( total_processes == 0 ){// no client processes
  	i_failed_processes = 0;
	return need_change_ft_level;
  }

  float failure_rate = (total_processes)?
        ((float)i_failed_processes / (float)total_processes):0.0 ;
  // have client processes 
  if ( ObjectSpace::check_ft_degree(PRIVATE_SNAPSHOT) ){
      if (( failure_rate < threshold_frequent_failure_rate ) &&
          ( total_continuation_size > threshold_continuation_size )){
		new_ft_level = GLOBAL_SNAPSHOT;
                need_change_ft_level = 1;
      }
      // else no change 
  }
  else if ( ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT) ){
	  if (( failure_rate > threshold_frequent_failure_rate ) ||
              // usually, the application's continuation is not zero
              // if the first mode is GLOBAL_SNAPSHOT, then the system 
              // does not know the continuation before the first 
              // checkpoint.  So we delay the change if the continuation
              // size does know.
              (( total_continuation_size != 0 ) &&
              ( total_continuation_size < threshold_continuation_size))){
		need_change_ft_level = 1;
		new_ft_level = PRIVATE_SNAPSHOT;
          }
  }
#ifdef PL_DEBUG_FT_MODE_OUT
  cerr << "Check fault level Neeed_change= " << need_change_ft_level << "\n";
  cerr << "current continuation_size= " << total_continuation_size ;
  cerr << "current total_processes= "<< total_processes;
  cerr << "failure_rate=" << failure_rate <<"\n";
  cerr << "threshold continuation size =" << threshold_continuation_size 
	<< "threshold failure_rate = " << threshold_frequent_failure_rate
        << "\n" << flush;
#endif
  
  i_failed_processes = 0;
  return need_change_ft_level;
}

void  FaultLevelManager::set_new_ft_level(void )
{
  if (  ! need_change_ft_level )
      return;
  need_change_ft_level = 0;
  ObjectSpace::set_ft_degree(new_ft_level);
  cerr<< "set new fault tolerent mode to ";
  if ( ObjectSpace::check_ft_degree(PRIVATE_SNAPSHOT))
	cerr<< "PRIVATE_SNAPSHOT \n";
  else if ( ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT))
	cerr<< "GLOBAL_SNAPSHOT \n";
  else if ( ObjectSpace::check_ft_degree(MESSAGE_REPLAY))
	cerr<< "MESSAGE_REPLAY \n";
  cerr << flush;
}
#endif // AUTO_FLAUT_MODE
