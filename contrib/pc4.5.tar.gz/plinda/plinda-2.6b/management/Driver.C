// This may look like C code, but it is really -*- C++ -*-
//
// File:     Driver.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//

#include <stream.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#ifndef linux
#include <sgtty.h>
#endif
#include <ctype.h>

#include "C_Interface.h"
#include "plinda_ids.h"
#include "ErrorType.h"
#include "EventLog.h"

#include "Transaction.h"
#include "Process.h"
#include "ClientProcess.h"
#include "ProcessManager.h"
#include "TransactionManager.h"
#include "TupleGroupManager.h"
#include "Scheduler.h"
#include "ObjectSpace.h"
#include "CheckpointManager.h"
#include "System_Patterns.h"
#include "DaemonProcess.h"
#include "ConnectionListener.h"
#include "MonitorProcess.h"
#include "Architectures.h"
// forward declarations ----------------------------------------------------

int get_server_options(int argc, char** argv, char** env, char* main_program,
		       int& recover_system, int& concurrent_gsnapshot);

int spawn_main_process(const char* name);
int spawn_monitor_process(const char* name);
int dispatch_daemons(const char* host_file);

const int PLINDA_CLIENT_PORT = 6000;

// ---------------------------------------------------------------------------
// main function    
// ---------------------------------------------------------------------------
static int isitinteractive = 1;

main(int argc, char **argv, char**env){
  // options
  int 		recover_system;
  int           concurrent_gsnapshot;
  char		main_program[100];

  // read the command line arguments   -------------------------------
  if(!::get_server_options(argc, argv, env, main_program,
			   recover_system, concurrent_gsnapshot)) {
    ObjectSpace::event_log.fatal("main", 
				 "unable to parse the command arguments");
  }


  // change the file creation mask so that everyone can access
  // what we make
  ::umask(0011);


  // this process clones off its copy   -----------------------------
  // as a background process and exits.
//  if(!no_fork) {
//    if(!::run_as_background()) {
//      ObjectSpace::event_log.fatal("main", 
	//			   "unable to run as a background process");
//    }
//  }

  // close down all the standard I/O files ---------------------------
  //{
  //  cin.close();
  //  cout.close();
  //  cerr.close();
  //}
    

  // open the event log file ------------------------------------------

  if(recover_system) 
    ::system(form("/bin/mv %s %s~", event_log_file_name, event_log_file_name));


  ObjectSpace::event_log.open(event_log_file_name);
  if(!ObjectSpace::event_log) {
    ObjectSpace::event_log.fatal("main", "unable to create an event log file");
  }

  cout << "The PLinda runtime system is starting up....\n" <<  flush;
  // initialize the server state. 
  if(!ObjectSpace::initialize(recover_system, concurrent_gsnapshot)) {
    ObjectSpace::event_log.fatal("main", 
				 "unable to initialize the server state");
  }


  {
    char command[1000];
    ::sprintf(command,"/bin/mv %s/plinda.cleanup %s/plinda.cleanup~",
	      ObjectSpace::working_directory, ObjectSpace::working_directory);
    ::system(command);
    char uname[64];
    ::cuserid(uname);
    if(!uname) {
      cerr << "Error: system command getlogin returning NULL\n";
      assert(uname);
    }
    ObjectSpace::cleanup_log(ObjectSpace::conn_lsner.hostname(),
			     uname, ::getpid());
  }


  // recover the server, if requested          ---------------------------
  if(recover_system) {
    if(!ObjectSpace::recover()) {
      ObjectSpace::event_log.error("main", 
				   "unable to recover the server state");
      ObjectSpace::event_log.messg("main", "restart from the scratch");

      // recover_system flag is no longer effective. 
      recover_system = 0;
    }
  } 


  // dispatch one daemon process per workstation. ---------------------
  // if(ObjectSpace::host_file != 0) {
  //  if(!::dispatch_daemons(ObjectSpace::host_file)) {
  //    ObjectSpace::event_log.fatal("main", "unable to dispatch daemons");
  //  }
  // }
    

  /* it will be a "user-invoke" command ... */
  // if(ObjectSpace::dumb_monitor_flag == 1) {
  //  spawn_monitor_process(ObjectSpace::x_server_name);
  // }


  if(ObjectSpace::batch_flag == 1) {
    // the DaemonProcess will disable xterm invocation 
    // later when the process is in fact created.
    spawn_main_process(main_program);

    // the server spawns daemons in a batch mode.
    if(dispatch_daemons(ObjectSpace::host_file) == 0) exit(-1);
  }


  // currently, event_loop stops iterating   -----------------------
  // when there are no more processes running.
  ObjectSpace::scheduler.event_loop();

  // terminate processes
  ObjectSpace::proc_mgr.terminate();
  // before termination, server checkpoints the state. ---------------
  if(!ObjectSpace::chkpt_mgr.close()) {
    ObjectSpace::event_log.fatal("main", 
				"unable to checkpoint state upon termination");
  }
  {
    // remove log files
    char command[1000];
    ::sprintf(command,"/bin/mv %s/plinda.server %s/plinda.server~",
	      ObjectSpace::working_directory, ObjectSpace::working_directory);
    ::system(command);
    ::sprintf(command,"/bin/mv %s/plinda.cleanup %s/plinda.cleanup~",
	      ObjectSpace::working_directory, ObjectSpace::working_directory);
    ::system(command);
  }
  ObjectSpace::event_log.exit(0); 
}


/* -------------------------------------------------------------------

int
run_as_background(void) {
  // split off the daemon
  cout << "  server is starting as a background process ....\n";

  // clone off its copy process.
  {
    int ret;
    if((ret = fork()) == -1) {
      cerr << "> **ERROR: fork failed\n";
      return 0;
    }

    if(ret) {
      // foreground goes away.
      ::exit(0);
    }
  } 

  // disassociate from the terminal
  {
    // change process group
    ::setpgrp(0, ::getpid());

    // abandon control tty
    int f = ::open("/dev/tty", O_RDWR);
    if(f < 0) {
      cerr << "> **ERROR: unable to open /dev/tty\n";
      return 0;
    }
    ::ioctl(f, TIOCNOTTY, (char*)0);
    ::close(f);
  }
 
  return 1;
}

  ------------------------------------------------------------------- */


int
get_server_options(int argc, 
		   char** argv, 
		   char** ,
		   char* main_program,
		   int& recover_system, 
		   int& concurrent_gsnapshot) {
  extern char* optarg;
//  extern int   optind, opterr;

  // initialization
  recover_system = 0;
  concurrent_gsnapshot = 0;


  // parse the command line arguments

  int option_char;
#ifndef AUTO_FAULT_MODE
  while((option_char=getopt(argc,argv,"avrb:dj:c:nlGgepzx:w:t:i:h")) != -1)
#else
  while((option_char=(char)getopt(argc,argv,"avrb:dj:c:nlGgezpx:w:t:i:hs:f:")) != -1)
#endif

  {
      //cerr << "server option = " << option_char  << endl << flush;
    switch(option_char) {
    case 'a':
       cerr << "a option --- Trace not supported now\n";
       exit(1);
      ObjectSpace::trace_on = 1;
      break;
    case 'v':
      ObjectSpace::display_flag = 1;
      break;
    case 'r':
      recover_system = 1;
      break;
    case 'b':
      {
        ObjectSpace::batch_flag = 1;
        ::strcpy(main_program,optarg);
      }
      break;
    case 'd':
       cerr << "d option --- debugging not supported now\n";
       exit(1);
      ObjectSpace::debugging_flag = 1;
      break;
    case 'j':
      {
	 char* ptr = new char[::strlen(optarg)+1];
	 ::strcpy(ptr,optarg);
	 ObjectSpace::working_directory = ptr;
      }
      break;
    case 'c':
       ObjectSpace::chkpt_interval = atoi(optarg);
       break;
#ifdef AUTO_FAULT_MODE
     case 's':
       ObjectSpace::continuation_size = atoi(optarg);
       if(ObjectSpace::continuation_size < 0) {
	ObjectSpace::continuation_size = ObjectSpace::continuation_default_size;
      }
      break;
    case 'f':
      ObjectSpace::failure_rate = ((float)atoi(optarg)) / 100.0;
      if(ObjectSpace::failure_rate < 0.0) {
	ObjectSpace::failure_rate = ObjectSpace::failure_default_rate;
      }
      break;
#endif
    case 'n':
      ObjectSpace::fault_tolerance_level = NO_SUPPORT;
      break;
    case 'l':
      ObjectSpace::fault_tolerance_level = PRIVATE_SNAPSHOT;
      break;
    case 'p':
       ObjectSpace::piranha_flag = 1;
      break;
    case 'g':
    case 'G':
      ObjectSpace::fault_tolerance_level = GLOBAL_SNAPSHOT;
      if(option_char == 'G') concurrent_gsnapshot = 1;
      break;
    case 'e':
#ifdef AUTO_FAULT_MODE
#ifdef PL_USE_MESSAGE_REPLAY
      ObjectSpace::fault_tolerance_level = MESSAGE_REPLAY;
#else
// we will not use MESSAGE_REPLAY mode from now on. Nov 9, 95
      ObjectSpace::fault_tolerance_level = GLOBAL_SNAPSHOT;
      if(option_char == 'G') concurrent_gsnapshot = 1;
#endif
#else
      ObjectSpace::fault_tolerance_level = MESSAGE_REPLAY;
#endif
      break;
    case 'x':
      {
	char* ptr = new char[::strlen(optarg)+1];
	::strcpy(ptr, optarg);
	ObjectSpace::x_server_name = ptr;
      }	
      break;
    case 'z':
      isitinteractive = 0;
      break;
    case 'w':
      {
	char* ptr = new char[::strlen(optarg) + 1];
	::strcpy(ptr, optarg);
	ObjectSpace::host_file = ptr;
      }
      break;
    case 't':
      ObjectSpace::process_timeout = atoi(optarg);
      break;
    case 'i':
      ObjectSpace::minimum_idletime = atoi(optarg);
      break;
    case 'h':
      cerr << "usage:	" << argv[0] << " \\\n";
      cerr << "       [-v]           ; display status\n";
      cerr << "       [-b main-prgm] ; batch processing mode\n";  
      cerr << "       [-d]           ; debugging mode\n";  
      cerr << "       [-r]           ; recover from server failure\n";  
#ifdef AUTO_FAULT_MODE
      cerr << "       [-f rate]      ; threshold failure rate percentage\n";
      cerr << "       [-s size]      ; threshold continuation size\n";
#else
// #ifdef PL_USE_MESSAGE_REPLAY
      cerr << "       [-e]           ; message logging & replay\n";
//#endif
#endif 
      cerr << "       [-j dir]       ; server working directory\n";
      cerr << "       [-x x-host]    ; X server host name\n";
      cerr << "       [-z ]       ; non interactive\n";      
      cerr << "       [-w host-file] ; file for workstation names\n";
      cerr << "       [-c interval]  ; checkpoint interval\n";
      cerr << "       [-t interval]  ; failure detection interval\n";
      cerr << "       [-l]           ; process-private snapshot (default)\n";
      cerr << "       [-g]           ; synchronous global snapshot\n";
      cerr << "       [-G]           ; asynchronous global snapshot\n";
      cerr << "       [-i]           ; minimum idle time for a daemon\n";
      cerr << "       [-n]           ; no support for fault tolerance\n";
      exit(0);
      break;
 /* ---------------------------------------------------------------
    case 't':
      link_timeout = atoi(optarg);
      if(link_timeout < 0)
	link_timeout = 0;
      break;
    case 's':
      send_timeout = atoi(optarg);
      if(send_timeout < 0)
	send_timeout = 0;
      break;
    case 'c':
      max_connections = atoi(optarg);
      if(max_connections < 0)
	max_connections = default_max_connections;
      break;
    case 'd':
      // debugging so processes don't timeout
      send_timeout = ~0;
      process_timeout = ~0;
      break;
    case 'f':
      // don't fork the daemon process so we can debug using gdb
      no_fork = 1;
      break;
    case 'u':
      // create a unique timeout value
      client_port = 0;
      break;
    case 'a':
      client_port = atoi(optarg);
      if(client_port <= 0) {
	cerr << argv[0] << ":  invalid address argument to -a switch\n";
	::exit(-1);
      }
      break;
 ---------------------------------------------------------------- */
    }
  }
  

  if(recover_system == 1) {
    cerr << "> recover from server failure.\n"; 
  }
  
    
  if(ObjectSpace::working_directory != 0) {
    if(::chdir(ObjectSpace::working_directory) == -1) {
      cerr << "> can't change the working directory to " 
	   << ObjectSpace::working_directory << "\n";
      cerr.flush();
      ::exit(1);
    }
  }
  
  if(ObjectSpace::x_server_name == 0 && isitinteractive) {
      cerr << "> warning: no x server name given; \n";
      cerr << "           user invocation required for the main process.\n";
  } 

  if(ObjectSpace::check_ft_degree(NO_SUPPORT)) {
    if(ObjectSpace::display_flag == 1) {
      cerr << "> warning: all the fault tolerant functions disabled.\n";
      return 1;
    }
  }

  if(ObjectSpace::check_ft_degree(PRIVATE_SNAPSHOT)) {
    if(ObjectSpace::display_flag == 1) {
      cerr << "> execution method: process snapshot at every commit.\n";
    }
  } else if(ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT)) {
    if(ObjectSpace::display_flag == 1) {
      cerr << "> execution method: global snapshot.\n";
    }
  } else {
    if(ObjectSpace::display_flag == 1) {
      cerr << "> execution method: execution recording & replay.\n";
    }
  }

  if(ObjectSpace::chkpt_interval == 0) {
    if(ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT)) {
      cerr << "> **ERROR: global snapshot with checkpoint disabled.\n";
      cerr << "         use '-c interval' option to enable checkpoint.\n";
      exit(1);
    }

    if(ObjectSpace::display_flag == 1) {
      cerr << "> warning: checkpointing disabled; \n";
      cerr << "           use '-c interval' option to enable it.\n";
    }

  } else {
    if(ObjectSpace::display_flag == 1) {
      cerr << "> checkpoint every " << 
	   ObjectSpace::chkpt_interval << " seconds.\n";
    }
  }

  if(ObjectSpace::piranha_flag == 1) {
    if(ObjectSpace::check_ft_degree(PRIVATE_SNAPSHOT) && 
       ObjectSpace::check_ft_degree(MESSAGE_REPLAY)) {
      cerr << "> **ERROR: piranha-stype computing requires ";
      cerr << "'-l' or '-e' option.\n";
      ::exit(1);
    }

    if(ObjectSpace::display_flag == 1) {
      cerr << "> Piranha style computing is on.\n";
    }
  }

  return 1;
}


// -------------------------------------------------------------------
#ifdef linux
static const char *server_type= "linux";
#endif
#ifdef alpha
static const char *server_type= "alpha";
#endif
#ifdef solaris
static const char *server_type="solaris";
#endif
#ifdef sunos
static const char *server_type="sunos";
#endif
#ifdef irix
static const char *server_type= "irix";
#endif

int
dispatch_daemons(const char* host_file) {
   extern const char *REMOTESH;
  if(!ObjectSpace::chkpt_mgr.change_to_working_dir()) {
    ObjectSpace::event_log.error("dispatch_daemons",
			          "unable to change to the working directory");
    return 0; 
  }

  // open the given host file.
  ifstream hosts(host_file, ios::in);
  if(!hosts) {
    cerr << "> **ERROR: failed to open the host file.\n";
    ObjectSpace::event_log.error("dispatch_daemons", 
				 "unable to open host file");
    return 0;
  }


  // daemon invocation shell file.
  // ofstream daemons;
  //
  // if(ObjectSpace::piranha_flag == 1) {
  //  daemons.open("plinda.daemons", ios::out);
  //  if(!daemons) {
  //    cerr << "> error: failed to open the daemon file.\n";
  //    ObjectSpace::event_log.error("dispatch_daemons", 
  //				     "unable to open the daemon file");
  //    ::exit(1);
  //    return 0;
  //  }
  // }


  int num_hosts = 0; 
  while(1) {
      // read a host name;
      char host_name[1000]; // 1000 must be enough.;
      hosts >> host_name;
      if(!hosts) {
	  break;
      }
      char host_type[1000];
      hosts >> host_type;
      char user_name[1000];
      hosts >> user_name;
      assert(::strlen(user_name) > 0 && ::strlen(user_name) < 20);
      for(int i = 0 ; host_type[i] ; i++) 
	host_type[i] = tolower(host_type[i]);

      if(::strlen(user_name) < 1) {
	cerr << "Invalid host file must have user name in there\n";
	::exit(1);
      }
//      while(host_type[i] = tolower(host_type[i]))
//         i++;      

   if(! PLinda_Architectures::supported(host_type)) {
	 cerr << host_type << " not supported yet, Sorry" << 
	   __LINE__ << __FILE__ << endl << ::flush;
	 assert(0);
      }
      if(ObjectSpace::display_flag == 1) {
	  cerr << "> host-add: " << host_name << "\n";
      }
      
      // dispatch a daemon;

      DaemonProcess* daemon = 
	ObjectSpace::proc_mgr.create_daemon(host_name,host_type,user_name);
      if(daemon == 0) {
	ObjectSpace::event_log.error("dispatch_daemons", 
				     "unable to dispatch a daemon");
        return 0;
      }
      if(ObjectSpace::piranha_flag == 1) {
	char command[1000];
	::sprintf(command,
		  "%s %s -l %s \"~/plinda/bin/%s/plinda_daemon %ld %d %s %s %s %s \"&", 
		  REMOTESH,
		  host_name, user_name,host_type,daemon->identifier(), 
		  htons(ObjectSpace::conn_lsner.port_number()),
		  ObjectSpace::conn_lsner.hostname(),
		  (ObjectSpace::x_server_name != 0) ?
		  ObjectSpace::x_server_name : "\\?",
		  host_type,server_type);

	cout << command << "\n" << flush;

	if(system(command) != 0) {
	  cerr << "> **ERROR: failed to invoke a daemon on " << host_name 
	       << "\n" << flush;
	  ObjectSpace::proc_mgr.destroy_daemon(daemon);
	  continue;
	}
      } // ObjectSpace::piranha_flag == 1;
      ++num_hosts;
  }

  if(num_hosts == 0) {
    cerr << "> **ERROR: no machine name in the host file.\n";
    exit(1);
  }

  if(ObjectSpace::piranha_flag == 1) {
    //      daemons.close();
    //      cerr << "> RUN: /usr/bin/sh pl_daemons.sh\n" << flush;
  }

  return 1;
}


// ----------------------------------------------------------------------
// insert an eval tuple for the main program 
// and then a daemon will dispatch a process for the tuple.
// of course, do it in a transactional manner. 
int
spawn_main_process(const char* name) {
  
  Tuple* main_prgm_tuple = ::create_main_prgm_tuple(name);

  ObjectSpace::proc_mgr.spawn_PROCESS(ObjectSpace::proc_mgr.super, 
  			              main_prgm_tuple, isitinteractive);
  
  return 1;
}

//--------------------------------------------------------------------------
#if 0
int
spawn_monitor_process(const char* monitor_host_name) {
   extern const char *REMOTESH; 
  char command[1000];
  
  ::sprintf(command, " %s %s \"xterm -display %s -e ~/plinda/bin/%s %ld %d %s\" & ", REMOTESH,
	    monitor_host_name,  monitor_host_name, 
	    "monitor", MONITOR_PROCID, 
	    ObjectSpace::conn_lsner.port_number(), 
	    ObjectSpace::conn_lsner.hostname()); 
//  system(command);
  ::printf("user-invoke: %s\n", command);
  
 //ObjectSpace::monitor.spawned();
  ObjectSpace::monitor.host_name(monitor_host_name);
  
  return 1;
}
#endif
//--------------------------------------------------------------------------

