// This may look like C code, but it is really -*- C++ -*-
//
// File:        CheckpointManager.C
// Description:
// Created:
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//

#include <sys/param.h>
#include <fcntl.h>

#include "CheckpointManager.h"
#include "ErrorType.h"
#include "TupleGroup.h"
#include "Transaction.h"
#include "Process.h"
#include "ClientProcess.h"
#include "TupleGroupManager.h"
#include "ProcessManager.h"
#include "EventLog.h"
#include "ObjectSpace.h"
#include "Scheduler.h"
#include "C_Interface.h"

#ifdef _OUTLINE_
#define inline
#include "CheckpointManager.iC"
#endif

#ifdef  AUTO_FAULT_MODE
#include "FaultLevelManager.h"
#endif

// --------------------------------------------------------------------
// constructor
// --------------------------------------------------------------------

CheckpointManager::CheckpointManager(const char* left_dir_name,
				     const char* right_dir_name,
				     const char* header_name) {
   (void)left_dir_name;
   (void)right_dir_name;
   (void)header_name;
  x_activation_flag = 1;
}

// --------------------------------------------------------------------
// destructor
// --------------------------------------------------------------------

CheckpointManager::~CheckpointManager(void) {
  // do nothing.
}

// --------------------------------------------------------------------
// enable/disable checkpointing
// --------------------------------------------------------------------
ErrorType
CheckpointManager::enable(void) {
  x_activation_flag = 1;
  return checkpoint();
}

ErrorType
CheckpointManager::disable(void) {
  x_activation_flag = 0;
  return NO_ERROR;
}

// --------------------------------------------------------------------
// open and close
// --------------------------------------------------------------------
				
	
ErrorType
CheckpointManager::open(int recover_flag) {

  // open the directories      
  ::strcpy(x_header_name, "TS_chkpt_header");

  ::strcpy(x_root_dir_name,ObjectSpace::working_directory);

//  if(::getwd((char*)x_root_dir_name) == 0) {
//    cerr << "> error: " << x_root_dir_name << "\n" ;
//    cerr.flush(); 
//  } 

  ::sprintf(x_left_dir_name,"%s/%s",x_root_dir_name,"TS_chkpt_left");
  ::sprintf(x_right_dir_name,"%s/%s",x_root_dir_name,"TS_chkpt_right");

  cerr << "> checkpoint directories: " << x_root_dir_name << " " 
       << x_left_dir_name << " " << x_right_dir_name << "\n";
  cerr.flush();

  x_last_chkpt_dir = CHKPT_RIGHT_DIR;
  x_chkpt_dir_status = 0;		



//  x_root_dir = ::open(".", O_RDONLY);
  x_root_dir = ::open(x_root_dir_name, O_RDONLY);
  if(x_root_dir == -1) {
    cerr << "> error: failed to open root dir.\n";
    cerr.flush();
    return E_CHKPT_DIR;
  }
  x_current_dir = ROOT_DIR;

  x_left_dir =   ::open(x_left_dir_name, O_RDONLY);
  if(x_left_dir == -1) {
    if(recover_flag == 1) {
      cerr << "> error: no checkpoint directory.\n";
      cerr.flush();
      return E_CHKPT_DIR;
    }

    ::mkdir(x_left_dir_name, 0766);
    x_left_dir = ::open(x_left_dir_name, O_RDONLY);
    if(x_left_dir == -1) {
      cerr << "> error: failed to open left dir.\n";
      cerr.flush();
      return E_CHKPT_DIR;
    }
  } else {
    if(recover_flag == 0) {
      change_dir(CHKPT_LEFT_DIR);
      system("/bin/rm -f *");
    }
  }

  change_dir(ROOT_DIR);
  x_right_dir =  ::open(x_right_dir_name, O_RDONLY);
  if(x_right_dir == -1) {
    if(recover_flag == 1) {
      cerr << "> error: no checkpoint directory.\n";
      cerr.flush();
      return E_CHKPT_DIR;
    }

    ::mkdir(x_right_dir_name, 0766);
    x_right_dir = ::open(x_right_dir_name, O_RDONLY);
    if(x_right_dir == -1) {
      cerr << "> error: failed to open right dir.\n";
      cerr.flush();
      return E_CHKPT_DIR;
    }
  } else {
    if(recover_flag == 0) {
      change_dir(CHKPT_RIGHT_DIR);
      system("/bin/rm -f *");
    }
  }

  // we start with the left directory.
  x_last_chkpt_dir = CHKPT_RIGHT_DIR;
  x_chkpt_dir_status = 0;		
  if(change_dir(CHKPT_LEFT_DIR) == 0) { 
      cerr << "> error: failed to change to current dir.\n";
      cerr.flush();
      return E_CHKPT_DIR;
  }
  return NO_ERROR;
}


ErrorType
CheckpointManager::close(void) {
  ErrorType stat = checkpoint();
  ::close(x_root_dir);
  ::close(x_left_dir);
  ::close(x_right_dir);
  return stat;
}



// --------------------------------------------------------------------
// checkpoint
// --------------------------------------------------------------------

int
CheckpointManager::handle_timeout(const Time_Value& , 
				  const void* ) {	
  ErrorType stat;
//  ObjectSpace::event_log.get_log() << "start checkpointing the server !\n";

  if(ObjectSpace::check_ft_degree(NO_SUPPORT)) {
    return 1;
  }
#ifdef AUTO_FAULT_MODE
  if(ObjectSpace::ftlvl_mgr.is_need_change_ft_level() )
    // have not finished the last ft level change
    return 1;
  
  if(ObjectSpace::ftlvl_mgr.check_change_ft_level()  ||
     ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT) ||
#else
     if (ObjectSpace::check_ft_degree(GLOBAL_SNAPSHOT) ||
#endif
     ObjectSpace::check_ft_degree(MESSAGE_REPLAY)) {
    ObjectSpace::scheduler.activate_chkpt();
    return 1;
  }

  if(!(stat=checkpoint())) {
    ObjectSpace::event_log.fatal("CheckpointManager::checkpoint",
				 stat.message());
  }
//  ObjectSpace::event_log.get_log() << "checkpointing the server ends.!\n";

  return 1;
}


// we assume that we are already in the right directory. 
ErrorType
CheckpointManager::checkpoint(void) {
  if(x_activation_flag == 0) return NO_ERROR;

  ErrorType error_val;

// BEGINTIMING;

  cerr << "> checkpointing the server now ...\n";
  cerr.flush(); 

  assert(change_to_next_dir() != 0);

  // if we finish checkpointing successfully,
  // we will reset this.
  x_chkpt_dir_status = 0;

  // checkpoint the tuple groups -------------------------------

  // checkpoint group space 
  if(!(error_val=ObjectSpace::group_mgr.checkpoint())) {
    return error_val;
  }

  // checkpoint process space
  if(!(error_val=ObjectSpace::proc_mgr.checkpoint())) {
    return error_val;
  }

  // checkpoint tuples in transactions
  if(!(error_val=ObjectSpace::trans_mgr.checkpoint())) {
    return error_val;
  }

  // write the header.   ---------------------------------------

  // create chkpt header
  create_chkpt_header(x_chkpt_header);

  // flush the header to disk
  if(!store_chkpt_header(x_header_name, x_chkpt_header)) {
    return E_CHKPT_HEADER;
  }

  x_chkpt_dir_status = 1;

  // alternate a directory        ------------------------------
  if(!alternate_chkpt_dir()) {
    return E_CHKPT_DIR;
  }

 cerr << "> checkpointing is done ...\n" << flush;
 cerr.flush();

// ENDTIMING;

//  cout << TIMINGS << " secs, " << TIMINGMS << " msecs, "
//	 << TIMINGUS << " usecs.\n" << flush;

  return NO_ERROR;
}



// --------------------------------------------------------------------
// rollback
// --------------------------------------------------------------------
	
ErrorType
CheckpointManager::rollback(void) {
  
  ErrorType error_val;

  ObjectSpace::event_log.get_log() << "start rolling back the server !\n";
  cerr << "the server is rolling back to the last checkpointed state ...\n";
  cerr << flush;

  // recover the chkpt header          ----------------------------
  // this function moves us to the last checkpoint directory.
  if(!recover_chkpt_header()) {
    return E_CHKPT_HEADER;
  }

  // no checkpointed state.
  if(x_chkpt_dir_status == 0) { 
    return NO_ERROR;
  }

  // recover the last identifiers 
  {
    Process::set_last_procid(get_last_procid());
    Transaction::set_last_transid(get_last_transid());
    TupleGroup::set_last_physid(get_last_physid());
    TupleGroup::set_last_gid(get_last_gid());
  }

  // recover the tuple groups          ----------------------------
  if(!(error_val=ObjectSpace::group_mgr.rollback())) {
    return error_val;
  }
  
  // recover the special groups for process management -------------
  if(!(error_val=ObjectSpace::proc_mgr.rollback())) {
    return error_val;
  }

  // recover the tuples that were in transactions 

  if(!(error_val = ObjectSpace::trans_mgr.rollback())) {
    return error_val;
  }
  ObjectSpace::event_log.get_log() << "rolling back the server state ended.!\n";
  cerr << "done.\n" << flush;

  
  return NO_ERROR;
}



// --------------------------------------------------------------------
// functions for the header
// --------------------------------------------------------------------

int
CheckpointManager::recover_chkpt_header(void) {

  // load headers from two directories.     ----------------------------
  int left_flag;
  unsigned long left_mtime;
  ChkptHeader left_header;
  int right_flag;
  unsigned long right_mtime;
  ChkptHeader right_header;
  { 
    // left header.
    assert(change_dir(CHKPT_LEFT_DIR) != 0);
    if(!load_chkpt_header(left_flag, left_mtime, 
			  x_header_name, left_header)) {
      return 0;
    }

    // right header.
    assert(change_dir(CHKPT_RIGHT_DIR) != 0);
    if(!load_chkpt_header(right_flag, right_mtime, 
			  x_header_name, right_header)) {
      return 0;
    }
  }
      

  // compare them to find which is the later one.  --------------------------
  if(left_flag == 0 && right_flag == 0) {
    // none of them has a checkpointed state.
    // just record that the right directory has the lastest state.
    x_last_chkpt_dir = CHKPT_RIGHT_DIR;
    x_current_dir = CHKPT_RIGHT_DIR;
    x_chkpt_dir_status = 0;		// however, the directroy is empty.

  } else if(left_flag != 0 && right_flag != 0) {
    // both of them are not empty.
    if(left_mtime >= right_mtime) {
      x_last_chkpt_dir = CHKPT_LEFT_DIR;
      x_chkpt_header = left_header;

      if(change_dir(CHKPT_LEFT_DIR) == 0) return 0;

    } else {
      x_last_chkpt_dir = CHKPT_RIGHT_DIR;
      x_chkpt_header = right_header;

      if(change_dir(CHKPT_RIGHT_DIR) == 0) return 0;
    }
    x_chkpt_dir_status = 1;

  } else {
    // one of them is empty.
    if(left_flag != 0) {
      x_last_chkpt_dir = CHKPT_LEFT_DIR;
      x_chkpt_header = left_header;

      if(change_dir(CHKPT_LEFT_DIR) == 0) return 0;

    } else {  
      x_last_chkpt_dir = CHKPT_RIGHT_DIR;
      x_chkpt_header = right_header;

      if(change_dir(CHKPT_RIGHT_DIR) == 0) return 0;
    }
    x_chkpt_dir_status = 1;
  }
     
  return 1;
}
	

int
CheckpointManager::load_chkpt_header(int& flag,
 				     unsigned long& mtime,
			             const char* name, 
			             ChkptHeader& header) {

  struct stat stat_buf;

  int fd = ::open(name, O_RDONLY);
  if(fd == -1) {
    flag = 0;
    return 1;
  }
  if(::fstat(fd, &stat_buf) == -1) {
    flag = 0;
    return 1;
  }
  
  mtime = stat_buf.st_mtime;

  // 
  int len = ::read(fd, (char*)&header, chkpt_header_size());
  if(chkpt_header_size() != len) {
    flag = 0;
    ::close(fd);
    return 1;
  } else {
    if(!check_for_header_validity(header)) {
      flag = 0;
      ::close(fd);
      return 1;
    }
  }

  flag = 1;
  ::close(fd);

  return 1;
}


int 
CheckpointManager::create_chkpt_header(ChkptHeader& header) {

  header.head =         0; 
  header.last_procid =  Process::get_last_procid();
  header.last_transid = Transaction::get_last_transid();
  header.last_physid =  TupleGroup::get_last_physid();
  header.last_gid =     TupleGroup::get_last_gid();
  header.tail =         0;

  // -- checksum --
  unsigned char* ptr = (unsigned char*)&header;
  int sum = 0;
  for(int i=0; i<chkpt_header_size(); ++i) {
    sum += (int)*(ptr+i);
  }

  // when we load the header, we check if the head is identical to the tail.
  // then, the header is considered as valid. 
  header.head = header.tail = sum;

  return 1;

}

int
CheckpointManager::store_chkpt_header(const char* name, 
				      ChkptHeader& header) const {

  // open a header file. create it if it does not exist.
  int fd = ::open(name, O_WRONLY | O_CREAT | O_TRUNC, 0666);

  // write the header to a file.
  int len = ::write(fd, (char*)&header, chkpt_header_size());
  if(len != chkpt_header_size()) {
    ::close(fd);
    return 0;
  }

  ::close(fd);
  return len;
}



int
CheckpointManager::change_to_working_dir(void) {
  return change_dir(ROOT_DIR);
}


// we call this to the next directory 
// after checkpoint or rollback.
int
CheckpointManager::alternate_chkpt_dir(void) {
  if(x_last_chkpt_dir == CHKPT_RIGHT_DIR) {
    x_last_chkpt_dir = CHKPT_LEFT_DIR;

    // we move to the next directory in advance.
    if(change_dir(CHKPT_RIGHT_DIR) == 0) return 0;

  } else {
    x_last_chkpt_dir = CHKPT_RIGHT_DIR;

    // we move to the next directory in advance.
    if(change_dir(CHKPT_LEFT_DIR) == 0) return 0;
  }

  return 1;
}

int
CheckpointManager::change_to_next_dir(void) {
  if(x_last_chkpt_dir == CHKPT_LEFT_DIR) {
    return change_dir(CHKPT_RIGHT_DIR);
  } else {
    return change_dir(CHKPT_LEFT_DIR);
  }

  return 1;
}


int
CheckpointManager::change_dir(CheckpointManager::ChkptDirType dir) {
  // we are already in the requested directory.
  if(dir == x_current_dir) return 1;

  // we need to change the current directory.
  if(dir == CHKPT_LEFT_DIR) {
    if(::chdir(x_left_dir_name) != -1) {
      x_current_dir = CHKPT_LEFT_DIR;
    } else return 0;
  } else if(dir == CHKPT_RIGHT_DIR) {
    if(::chdir(x_right_dir_name) != -1) {
      x_current_dir = CHKPT_RIGHT_DIR;
    } else return 0;
  } else {
    if(::chdir(x_root_dir_name) != -1) {
      x_current_dir = ROOT_DIR;
    } else return 0;
  }

  return 1;
}

