// This may look like C code, but it is really -*- C++ -*-
//
// File:     TupleGroupManager.h
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//

#ifndef _TUPLE_GROUP_MANAGER_H_
#define _TUPLE_GROUP_MANAGER_H_

#include "plinda_ids.h"

#include "GNU_Interface.h"
#include <fstream.h>
#include "TupleGroup.h"


class Process;
class Transaction;
class TupleGroup;

const gid      FIRST_GID     = gid::zero(0,11);
const physid   FIRST_PHYSID  = physid::zero(0,1);
const gid      CATALOG_GID   = gid::zero(0,1);
const gid      TRACE_GID      = gid::zero(0,5);   /* gid's 2 thru 4 in ProcessManager.h*/


class TupleGroupManager {
public:

  TupleGroupManager(void);
  TupleGroupManager(const TupleGroupManager& another);
  virtual ~TupleGroupManager(void);
  
  int initialize(const gid& =FIRST_GID, const physid& =FIRST_PHYSID, 
		 const gid& =CATALOG_GID, const gid& =TRACE_GID);

  // -------------------------------------------------------------------
  // find tuple group objects.
  // -------------------------------------------------------------------
  TupleGroup* find_group(const gid& g);
  TupleGroup* find_group(const char* group_name);
  ErrorType  dump_group(const char* group_name);
  void remove_group(TupleGroup *grp); 
  // called by TupleGroup::commit_destruction

  // -------------------------------------------------------------------
  // creation of a tuple group is performed in a transactional manner.
  // the effect is made permanent by calling the member function of the group,
  // commit_creation, or aborted by calling member function abort_creation.
  // -------------------------------------------------------------------
  TupleGroup* create_group(Process*, Transaction*, const char*, 
			   const gid& g =zero_gid);

  // likewise is destruction of a tuple group.
  int destroy_group(Process*, Transaction*, TupleGroup*);

  
  // -------------------------------------------------------------------
  // checkpoint and rollback 
  // -------------------------------------------------------------------

  // checkpoint the entire user tuple space.
  ErrorType   checkpoint(void);

  // restore the entire user tuple space.
  ErrorType   rollback(void);

  // checkpoint a particular tuple group.
  ErrorType   checkpoint(TupleGroup* g_cur);

  // restore a particular tuple group.
  ErrorType   rollback(TupleGroup* g_cur);
  

  // -----------------------------------------------------------------------
  // this function loads a tuple group from a file into the in-memory strage.
  // it should be equivalent to the checkpointing function wrt functionality.
  // -----------------------------------------------------------------------

  TupleGroup* open_group(const gid&);

  // we maintain a reference counter on each tuple group, but
  // we do not swap out a tuple group with zero reference count.
  // when we run out of virtual memory space, we start to swap 
  // those with zero count out.
  int         close_group(const gid&);
  void        close_group(TupleGroup*);
  

  // ---------------------------------------------------------
  // dump
  // ---------------------------------------------------------

  void dump(ofstream&);

private:
  // this group contains an entry tuple for each tuple group.
  TupleGroup       catalog_group;


  // this group contains execution traces from the user processes (if 
  // tracing is enabled)
  TupleGroup       trace_group;


  // the list of the tuple groups.
  TupleGroupList   group_list;

};

#endif // _TUPLE_GROUP_MANAGER_H_
