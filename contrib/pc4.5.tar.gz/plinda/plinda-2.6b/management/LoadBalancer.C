// This may look like C code, but it is really -*- C++ -*-
//
// File:     LoadBalancer.C
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//


#include "LoadBalancer.h"
#include "Scheduler.h"
#include "ProcessManager.h"
#include "ObjectSpace.h"
#include "DaemonProcess.h"

#ifdef _OUTLINE_
#define inline
#include "LoadBalancer.iC"
#endif


// constructor
LoadBalancer::LoadBalancer(void) { }


// invoke failure detection 
int
LoadBalancer::handle_timeout(const Time_Value& , const void*) {
  if(ObjectSpace::piranha_flag == 1) {
    int migration_count = ObjectSpace::proc_mgr.count_idle_daemons();
    for(int i = 0; i < migration_count; ++i) {
      DaemonProcess* busy = ObjectSpace::proc_mgr.find_busy_daemon();
      if(busy == 0) 
	break;
      busy->reduce_processes();
    }
  }
  return 1;
}


