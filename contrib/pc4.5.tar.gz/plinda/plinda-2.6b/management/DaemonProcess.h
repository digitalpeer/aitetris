
// This may look like C code, but it is really -*- C++ -*-
//
// File:     DaemonProcess.h
// Created:  
// Author:   Karp Joo Jeong
// Mail:     jeong@cs.nyu.edu
//
#ifndef _DAEMON_PROCESS_H_
#define _DAEMON_PROCESS_H_

// ACE headers

// PLinda header files & forward declarations
#include "plinda_ids.h"
#include "config.h"
#include "Process.h"

#include "Header.h"

class TupleHandle;
class TupleGroup;
class ClientProcess;

class DaemonProcess : public Process {
public:
  // one DaemonProcess for each workstation.
  DaemonProcess(procid id, const char* host,const char *htype,
		const char *uname);

  virtual ~DaemonProcess(void);

  // --------------------------------------------------
  // max number of clients allowed on this daemon ...
  // --------------------------------------------------
  int max_num_clients(void) const;
  void max_num_clients(int);
  int num_clients(void) const;
  const ClientProcess* client(int) const;
  int fully_loaded(void) const;
  int allowed_load(void) const;

  // host name
  const char*hostname(void) const;
  int get_next_hostid(void);
  int host_id(void) const;
  
  // --------------------------------------------------
  // Scheduler
  // --------------------------------------------------

  int alive_flag(void) const;
  void set_alive_flag(int);
    
  virtual int ready(void);

  virtual int handle_request(void) { return 0; };

  // kill the real daemon.
  void kill(void);
  // terminate the real daemon.
  void terminate(void);

  // kill a particular process
  void kill_process(int transientId);
  // kill processes
  void kill_processes();

  static int pseudo_spawn_process(void);
  int spawn_process(void);
  int reduce_processes(void);

  // functions for load balancing
//  void set_reserved(void); 
//  int reserved(void) const; 

  // set the minimum idle time of this daemon process
  int set_minimum_idletime(int);
  
  // --------------------------------------------------
  // Threads
  // --------------------------------------------------

  virtual int block(int, TupleGroup*, Pix) { assert(0); return 1;}
  virtual int resume(const TupleGroup*, const TupleHandle&, Tuple*) {
     assert(0); return 1; }

  // --------------------------------------------------
  // Communication Link
  // --------------------------------------------------

  virtual void enqueue_request(Header*, Tuple *);
//  virtual Message* dequeue_request(void) { return 0; };
  int send_reply(Header &,const Tuple * = NULL);

  // --------------------------------------------------
  // Dummies for Failure Detection and Reaction
  // --------------------------------------------------
 
  virtual int check_failure(void);
  virtual void declare_failure(void);
  virtual void declare_client_failure(void);

  virtual void declare_error(ErrorType) {};
  virtual void handle_failure(void) {};
 

  // --------------------------------------------------
  // Spawning and Waiting for Termination
  // --------------------------------------------------

  // wait for a spawned process to terminate.
  // for now, we invoke one process on each workstation.
  void wait(ClientProcess*);

  // Spawned processes inform DaemonProcesses of completion.
  void complete(ClientProcess*);
  void complete(const procid);


  // spawn a specific client process on this host ..
  void dispatch_client(ClientProcess* proc);
  int dispatch_client(procid proc_id);

  // --------------------------------------------------
  // other monitoring information about hosts/processes
  // --------------------------------------------------
  void host_info(char *hostname,int &hostId,int &cpuLoad,int &mainMem, 
		 int &maxClients, int &numClients,int &stat);

  bool isValidClient(int c) {    return x_client[c] != 0 ; }
  void  monitor_info(int,int &,char*,char*,char*,int&,int&);

  // --------------------------------------------------
  // printing
  // --------------------------------------------------

  virtual String print(void) const;
  const char *username() { return x_username; }
private:


  // -----------------------------------------------------
  // this is used to generate hostidentifiers...
  // -----------------------------------------------------
  static int system_next_hostid;

  // ------------------------------------------------------
  // full symbolic host name
  // ------------------------------------------------------
  const char* x_hostname;

  const char *x_hosttype;
  const char *x_username;

  int   x_hostid;
  long  x_cpu_load;
  long  x_main_mem;
  int   x_alive_flag;
  int   x_last_seq_num;

  //----- NEED TO ADD STATE FOR OTHER INFO ABOUT HOSTS ----

  // ------------------------------------------------------
  // server address.  
  // ------------------------------------------------------

  unsigned short x_server_port;
  long x_server_ip;

  // ------------------------------------------------------
  // maximum number of client processes allowed on this
  // host machine ...and the no. currently active on it.
  // ------------------------------------------------------
  int  x_max_num_clients;
  int  x_num_clients;

  // ------------------------------------------------------
  // Spawning
  // ------------------------------------------------------

  Transaction* x_dsptch_trans;

  // ------------------------------------------------------
  // worker process
  // ------------------------------------------------------

  ClientProcess** x_client;
  //  Header *x_cur_request;

  // -----------------------------------------------------
  // member functions used only privately ..
  // -----------------------------------------------------
  void add_client(ClientProcess* proc);
  void del_client(const procid p);
  ClientProcess* client(const procid p);
 
};

#ifndef _OUTLINE_
#include "DaemonProcess.iC"
#endif

#endif // _DAEMON_PROCESS_H_
