// This may look like C code, but it is really -*- C++ -*-
//
// File:        config.h 
// Description: This file defines configuration options for PLinda
// Created:      
// Mail:        jeong@cs.nyu.edu
// Note:        This code is taken from the PLinda 1.0 source, written
//		by Brian G. Anderson, and modified by Karp Joo Jeong,
//		Sat Jun 25 19:13:36 EDT 1994

#ifndef _CONFIG_H_
#define _CONFIG_H_

// Every client process is required to obtain a connection to the server, 
// first and then is able to send requests. The server has a ConnectionListener
// that is always listening to connection requests. Client processes should
// know the address of the connection listener.
const int PL_CONNECTION_REQUEST_PORT = 51000;
// envirnment variable for the address
char* const PLINDA_ENV = "PLINDA_ADDRESS";

// this constant controls how long before the run-time system times out
// waiting for messages. (It can be overwritten using an argument option.)
// If nothing has happened, the system will start checkpointing tuple groups. 
const int LINK_DEFAULT_TIMEOUT = 5; // 5 seconds

// this is similar to the above but controls how long before the
// run-time system gives up on a process and considers it aborted
const int PROCESS_DEFAULT_TIMEOUT = 120; // 2 minutes

// this is similar to the above but controls how long before the
// run-time system gives up on sending a reply message and consideres
// the process as failed.
const int SEND_DEFAULT_TIMEOUT = 10; // 10 second

// the first group identifier will start at this value if the system
// is booted.  this value must be at least 10.
const int FIRST_USER_GID_INDEX = 10;

// The name of the log files.
char* const E_LOG_NAME = "PL.error.log";
char* const T_LOG_NAME = "PL.trans.log";

const int MONITOR_STRLEN = 30;

#endif // _CONFIG_H_

