// This may look like C code, but it is really -*- C++ -*-
//
// File:        Machine.C
// Description: 
// Created:      
// Mail:        jeong@cs.nyu.edu
//

#include "Machine.h"

#ifdef _OUTLINE_
#define inline
#include "Machine.iC"
#endif

#ifdef hpux
const char *REMOTESH = "remsh";
#else
const char *REMOTESH = "rsh";
#endif
