// This may look like C code, but it is really -*- C++ -*-
//
// File:        plinda_requests.h
// Description: This file defines the types of services the server provides.
// Created:      
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu

#ifndef _PLINDA_REQUESTS_H_
#define _PLINDA_REQUESTS_H_

enum ClientRequest {
  INVALID = -1,
  NO_REQUEST = 0, 
//  PROC_EVAL = 1,
//  PROC_SPAWN = 2,
  PROC_START = 3,
  PROC_END = 4, 
  CREATE_GROUP = 5,
//  DESTROY_GROUP = 6, 
  IN = 7, 
  RD = 8, 
//  OUT = 9, 
  LOG_REQ = 13,
  LOG_FLUSH = 14,
  XRECOVER = 15,
  ARG_RDP = 16,
//  XSTART = 17, 
  XCOMMIT = 18,
  TUPLE_CREATIONS = 19,
  NUM_MACHINES = 20
  };

enum PL_Syncrony { BLOCK = 1, NOBLOCK = 2};

typedef ClientRequest RequestType;



#endif // _PLINDA_REQUESTS_H_
