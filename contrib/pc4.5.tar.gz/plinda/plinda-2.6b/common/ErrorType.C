// This may look like C code, but it is really -*- C++ -*-
//
// File:        ErrorType.C
// Description: 
// Created:      
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//

#include "ErrorType.h"

#ifdef _OUTLINE_
#define inline
#include "ErrorType.iC"
#endif

#ifndef __GNUG__
#include <string.h>
#endif
//////////////////////////////////////////////////////////////////////
// Define STATIC data members of class ErrorMessage.
//////////////////////////////////////////////////////////////////////
const int ErrorMessage::MAX_ERRORS = 100; // we are limited to 100 errors.
char** ErrorMessage::message_table = new char* [(ErrorMessage::MAX_ERRORS)];
// index zero is reserved for NO ERROR.
unsigned char ErrorMessage::next_index = 1; 

///////////////////////////////////////////////////////////////////////
// Define constants to represent errors.
///////////////////////////////////////////////////////////////////////

const ErrorType NO_ERROR("NO ERROR", 0);

const ErrorType E_FAIL("general failure");

const ErrorType E_NOT_OPEN("the client requests a group that is not open");

const ErrorType E_IN_USE("group cannot be deleted becuase it is in use");

const ErrorType E_INV_PATTERN("an invalid pattern was passed");

const ErrorType E_INV_IO_DATA("the client received invalid data in tuple field");

const ErrorType E_INV_MESSAGE("an inconsistent message was passed as an argument to a function or received as a message by the client");

const ErrorType E_PARTIAL_MESSAGE("only a portion of a message was sent or received over a communication link");

const ErrorType E_IMPROPER_REPLY("server replied with an incorrect request type");

const ErrorType E_CREATE_GROUP("the group could not be created");

const ErrorType E_OPEN_GROUP("the group could not be opened");

const ErrorType E_INV_STATUS("the process is in an invalid status");

const ErrorType E_INV_GROUP("the group is invalid");

const ErrorType E_INV_GID("the gid is invalid");

const ErrorType E_SEND_FAIL("could not send a message");

const ErrorType E_RECEIVE_FAIL("didn't receive a message");

const ErrorType E_NOT_REGISTERED("the client program is not registered with the server (this is probably because the server timed the client out)");

const ErrorType E_ALREADY_REGISTERED("the client program is attempting to register twice with the server");

const ErrorType E_COMMIT_FAIL("an attempt to commit a transaction failed");

const ErrorType E_NO_TRANS("a transaction operation was attempted by a process with no active transaction");

const ErrorType E_ALREADY_TRANS("a client is trying to start a transaction when it already has one active");

const ErrorType E_INV_LIFETIME("the lifetime argument for group creation is invalid");

const ErrorType E_DUP_PHYSID("the physical identifier passed to an out command is already in use in the table");

const ErrorType E_ADDR_DIFFERS("the client used a address that is different than that expected by the process table");

const ErrorType E_INV_ABORT_SIG("the client received abort signal with an invalid transid from the server");

const ErrorType E_INV_TRANSID("the client got the wrong transid from the server");

const ErrorType E_ALREADY_FAIL("the client was already declared as failed");

const ErrorType E_CHKPT_DIR("unable to switch to a chkpt directory");

const ErrorType E_CHKPT_HEADER("failed either to open or to read a chkpt header");



const ErrorType E_INV_PHYSID("invalid physical id");

const ErrorType E_INV_UNLOCK("invalid release of lock");

const ErrorType E_IO_FAIL("disk file operation failed");

const ErrorType E_CHKPT_FILE_OPEN("cant open checkpoint file");

const ErrorType E_CHKPT_FILE_READ("read failed on checkpoint file");

const ErrorType E_CHKPT_FILE_WRITE("write failed on checkpoint file");

const ErrorType E_CHKPT_FILE_CLOSE("cant close checkpoint file");

const ErrorType E_TUPLE_TOO_BIG("tuple too big to fit into checkpoint buffer");

const ErrorType E_INV_TUPLE_HANDLE("invalid tuple handle.");

const ErrorType E_IO_TO_TUPLE("error in IO_pattern to tuple conversion.");

const ErrorType E_CHECKPT_GROUP("error in tuple group checkpoint.");

const ErrorType E_INV_PROCESS("manipulating an invalid process.");

const ErrorType E_INV_HOST("invalid host.");

const ErrorType E_OVER_LOADED("host being over loaded.");

const ErrorType E_DAEMON_PRESENT("host has a daemon already.");

// ***** for Griffin *******

const ErrorType E_NOT_FOUND("there is no matching object");

const ErrorType E_NULL_PTR("no pointer is provided");

const ErrorType E_DANGLING_PTR("the object pointed to by given a pointer doesn't exist");

const ErrorType E_UPDATE_FAIL("the attempted update failed");

const ErrorType E_CREATE_NAMESPACE_FAIL("the creation of a namespace failed");

const ErrorType E_CREATE_DIRECTORY_FAIL("the creation of a directory failed");

const ErrorType E_DESTROY_NAMESPACE_FAIL("the destruction of a namespace failed");

const ErrorType E_DESTROY_DIRECTORY_FAIL("the destruction of a directroy failed");

const ErrorType E_INACTIVE_SERVER("the server is not active or its address is not properly set");

const ErrorType E_SOCKET_FAIL("a socket is broken");

const ErrorType E_ABORT("an abort signal is received");

const ErrorType E_KILL("a kill signal is received");

const ErrorType E_PING("a ping signal is received");

const ErrorType E_PONG(" a pong signal is received");

const ErrorType E_UNINITIALIZED("attempted to read a uninitialized value");


/////////////////////////////////////////////////////////////
// Member functions
/////////////////////////////////////////////////////////////

// error index may be specified for some errors such as NO_ERROR.
ErrorType::ErrorType(const char* e_msg, int idx) {
  if(e_msg == 0) {
    error_index = 0;  // NO_ERROR.
  } else {
    error_index = ErrorMessage::get_next_index(e_msg, idx);
  }
}

unsigned int 
ErrorMessage::get_next_index(const char* e_msg, int idx) {
  if(idx == -1) {
    assert(next_index <= MAX_ERRORS); // make sure that is less than
    // the amount an unsigned char can hold
    idx = next_index++;
  } else {
    assert(idx >= 0);
  }
  int len = ::strlen(e_msg) + 1;
  char* ptr = new char[len];
  ::strcpy(ptr, e_msg);
  message_table[idx] = ptr;
  return idx;
}
