#if 0
// This may look like C code, but it is really -*- C++ -*-
//
// File:        GNU_Interface.h
// Description: The current implementation uses the GNU class library
//		for major data structures. In order to maintain
//		our code as independent of the GNU class library as possible,
//		we gather all declarations related to the class in this file.
// Created:  
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//
#endif
#ifndef _GNU_INTERFACE_H_
#define _GNU_INTERFACE_H_

// GNU template for doubly linked lists 
#include <DLList.h>

// PLinda headers

#include "TupleHandle.h"

class Process;
class Transaction;
class TupleGroup;
class OperationRec;
class TransHistory;

typedef DLList<Process*>     ProcessList;
typedef ProcessList*         ProcessListPtr;

typedef DLList<Transaction*> TransactionList;
typedef TransactionList*     TransactionListPtr;

typedef DLList<TupleGroup*>  TupleGroupList;
typedef TupleGroupList*      TupleGroupListPtr;

typedef DLList<TupleHandle>  TupleHandleList;
typedef TupleHandleList*     TupleHandleListPtr;

typedef DLList<OperationRec*>  OperationRecList;
typedef OperationRecList*     OperationRecListP;

typedef DLList<TransHistory*>  TransHistoryList;
typedef TransHistoryList*     TransHistoryListP;

#endif // _GNU_INTERFACE_H_
