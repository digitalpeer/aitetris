// This may look like C code, but it is really -*- C++ -*-
//
// File:        Timer.h 
// Description: This file defines macro definitions for timers.
// Created:	      
// Author:	Karpjoo Jeong
// Mail:        jeong@cs.nyu.edu

#ifndef _TIMER_H_
#define _TIMER_H_

#include <stdio.h>
#ifdef __GNUG__
#include <time.h>
#include <sys/time.h>
#endif
// GNU
#include "String.h"

class Timer {
public:
  // constructor and destructor
  Timer(void); 
  ~Timer(void);
  void clear(void); 

  // start and stop a timer.
  void start(void); 
  void stop(void);
    
  // elapsed time of the last event
  int last_etime(long& secs, long& usecs);

  // elapsed time of the entire session.
  int total_etime(long& sum_secs, long& sum_usecs);

  // average elapsed time 
  int average_etime(long& secs, long& usecs);

  String print(int newline=0);
  
private:
  // data structure for timer info.
  struct ETime {
    struct timeval begin_time;
    struct timeval end_time;
  };
  struct ETimeNode {
    ETime time;
    ETimeNode* next;
  };

  // convert elapsed time to seconds and micro seconds.
  void etime2sec(const ETime&, long& secs, long& usecs);

  // event list 
  ETimeNode* x_head;
  ETimeNode* x_tail;
  int x_num_etimes;
};

#endif /* _TIMER_H_ */

