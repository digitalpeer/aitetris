// This may look like C code, but it is really -*- C++ -*-
//
// File:        timer.h 
// Description: This file defines macro definitions for timers.
// Created:	      
// Author:	Karpjoo Jeong
// Mail:        jeong@cs.nyu.edu

#ifndef _TIMER_H_
#define _TIMER_H_
#ifdef __GNUG__
#include <time.h>
#include <sys/time.h>
#endif


//char *ctime(time_t *clock);
//int gettimeofday(struct timeval* tp, struct timezone *tzp);
extern "C" {
	char *ctime();
//	int gettimeofday();
}

#define TIMER 			struct timeval

#define TIME_MS(t)              (t.tv_usec)

#define GET_TIME(t) 		::gettimeofday(&t, NULL)

#define PRINT_TIME(t) 		::ctime((time_t*)(&t.tv_sec))

#define ELAPSED_TIMES(s, f) 	( (s.tv_usec > f.tv_usec) ? \
			          ((f.tv_sec--) - s.tv_sec) : \
				  (f.tv_sec - s.tv_sec) )

#define ELAPSED_TIMEMS(s, f) 	( ELAPSED_TIMES(s, f)*1000 + \
			 	  ((s.tv_usec > f.tv_usec) ? \
  		          	  (((f.tv_usec + 1000000) - s.tv_usec)/1000) : \
			          ((f.tv_usec - s.tv_usec)/1000)) )

#define ELAPSED_TIMEUS(s, f) 	( ELAPSED_TIMES(s, f)*1000000 + \
			 	  ((s.tv_usec > f.tv_usec) ? \
	  		          ((f.tv_usec + 1000000) - s.tv_usec) : \
			          (f.tv_usec - s.tv_usec)) )


#endif /* _TIMER_H_ */
