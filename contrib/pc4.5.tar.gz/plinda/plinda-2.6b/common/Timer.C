// This may look like C code, but it is really -*- C++ -*-
//
// File:        timer.C
// Description: 
// Created:	      
// Author:	Karpjoo Jeong
// Mail:        jeong@cs.nyu.edu


#include "C_Interface.h"
#include "Timer.h"

#ifndef __GNUG__
#include <string.h>
#endif

// constructor
Timer::Timer(void) {
  x_head = 0;
  x_tail = 0;
  x_num_etimes = 0; 
}   

// destructor
Timer::~Timer(void) { 
  clear(); 
} 


// clear this timer
void 
Timer::clear(void) {
  ETimeNode* cur;
  ETimeNode* next;
  cur = x_head;
  while(cur != 0) {
    next = cur->next;
    delete cur;
    cur = next;
  }
  x_num_etimes = 0;
}


// start this timer.
void 
Timer::start(void) { 
  ETimeNode* node = new ETimeNode;
  ::gettimeofday(&(node->time.begin_time), NULL);
  
  node->time.end_time.tv_usec = node->time.begin_time.tv_usec;
  node->time.end_time.tv_sec = node->time.begin_time.tv_sec;
  node->next = 0;
  
  if(x_head == 0) {
    x_head = node;
    x_tail = node;
  } else {
    x_tail->next = node;
    x_tail = node;
  }
  ++x_num_etimes;
}
   

// stop the timer.
void 
Timer::stop(void) {
  if(x_tail == 0) return;
  ::gettimeofday(&(x_tail->time.end_time), NULL);
}
    

void 
Timer::etime2sec(const ETime& t, long& secs, long& usecs) {
  if(t.end_time.tv_usec < t.begin_time.tv_usec) {
    usecs = t.end_time.tv_usec - t.begin_time.tv_usec + 1000000;
    secs = t.end_time.tv_sec - t.begin_time.tv_sec - 1;
  } else {
    usecs = t.end_time.tv_usec - t.begin_time.tv_usec;
    secs = t.end_time.tv_sec - t.begin_time.tv_sec;
  }
}
    

int 
Timer::last_etime(long& secs, long& usecs) {
  if(x_head == 0) return 0;
  etime2sec(x_tail->time, secs, usecs);
  return 1;
}


int 
Timer::total_etime(long& sum_secs, long& sum_usecs) {
  if(x_head == 0) return 0;
    
  ETimeNode* node = x_head;
  sum_secs = 0;
  sum_usecs = 0;
  while(node != 0) {
    long secs, usecs;
    etime2sec(node->time, secs, usecs);
    
    sum_usecs += usecs;
    sum_secs += secs;
    
    if(sum_usecs > 1000000) {
      sum_usecs -= 1000000;
      sum_secs += 1;
    }

    node = node->next;
  }

  return 1;
}


int 
Timer::average_etime(long& average_secs, long& average_usecs) {
  if(x_head == 0) return 0;
  
  long sum_secs;
  long sum_usecs;
  total_etime(sum_secs, sum_usecs);
  
  average_secs = sum_secs/x_num_etimes;
  
  float res = float(sum_secs)/float(x_num_etimes) - float(average_secs);
  average_usecs = sum_usecs/x_num_etimes + long(res*float(1000000));
  
  return 1;
}


String 
Timer::print(int newline) {
  String hold = "[";
  if(newline != 0) {
    hold += "\n";
  }

  ETimeNode* cur = x_head;
  while(cur != 0) {
    char* ptr;
    char* nl;
    
    hold += "<";  // <
    ptr = ::ctime((const long int *)(&(cur->time.begin_time.tv_sec)));
    nl = (char*)::index(ptr,'\n'); *nl = '\0';
    hold += ptr;
    hold += ",";  // ,
    ptr = ::ctime((const long int *)(&(cur->time.end_time.tv_sec)));
    nl = (char*)::index(ptr,'\n'); *nl = '\0';
    hold += ptr;
    hold += ">";  // >
    if(newline != 0) {
      hold += "\n";
    }
    
    cur = cur->next;
  }
  
  hold += "]";
  return hold;
}

