// This may look like C code, but it is really -*- C++ -*-
//
// File:        plinda_ids.h 
// Description: This file defines identifier types to be shared 
//              by the server and clients.
// Created:      
// Mail:        jeong@cs.nyu.edu
// Note:	Most code in this file is taken from the PLinda 1.0 
//		source, written by Brian G. Anderson, and modified
//		by Karp Joo Jeong, Sat Jun 25 19:15:23 EDT 1994

#ifndef _PLINDA_IDS_H_
#define _PLINDA_IDS_H_

#ifndef _OUTLINE_
#define INLINE inline
#else
#define INLINE
#endif
// The class definitions for the identifier types of PLinda.
// The server, client-libraries, and application programs need these
// definitions.

#include <stream.h>


class Header;
class Tuple;
class TupleField;

// the double precision base class.  all id types are double word
// items.  these classes cannot have constructors because they appear
// in unions in other files.
class double_precision {
  friend INLINE ostream& operator<<(ostream&, const double_precision&);
  friend INLINE istream& operator>>(istream&, double_precision&);
  friend INLINE int operator==(const double_precision&, const double_precision&);
  friend INLINE int operator!=(const double_precision&, const double_precision&);
  friend  INLINE int operator>(const double_precision& f, const double_precision& s);
  friend  INLINE int operator>=(const double_precision& f, const double_precision& s);
  friend  INLINE int cmp(const double_precision&, const double_precision&);
protected:
  unsigned int high,low;
public:
   INLINE void set(unsigned int i);
   INLINE void inc(void);
   INLINE int hash(void) const;
   INLINE int operator !(void) const;
   INLINE char* print(void) const;
};

// the id types just inherit the double_precision stuff.
class gid: public double_precision {
  friend class Header;
  friend class Tuple;
  friend class TupleField;
public:
   INLINE gid& operator++(void);
   INLINE char* name(void) const;
   INLINE static gid zero(int x=0, int y=0);
};

class transid: public double_precision {
public:
  INLINE transid& operator++(void);
  INLINE static transid zero(int x=0, int y=0);

};

class physid: public double_precision {
friend class Tuple;
friend class TupleField;
public:

  INLINE physid& operator++(void);
  INLINE static physid zero(int x=0, int y=0);

};

// process id type.
typedef unsigned long 	procid;


#ifndef _OUTLINE_
#include "plinda_ids.iC"
#endif 

// null id's.
const gid     zero_gid       = (gid::zero());
const physid  zero_physid    = (physid::zero());
const transid zero_transid   = (transid::zero());
const procid  zero_procid    = 0;

#endif // _PLINDA_IDS_H_
