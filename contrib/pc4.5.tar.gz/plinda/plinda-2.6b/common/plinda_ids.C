// This may look like C code, but it is really -*- C++ -*-
//
// File:        plinda_ids.C 
// Description: This file defines member functions of PLinda identifier classes
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
// Note:	This file is taken from the source of PLinda 1.0
//		which Brian G Anderson wrote.

#include "plinda_ids.h"

#ifdef _OUTLINE_
#define inline
#include "plinda_ids.iC"
#endif
