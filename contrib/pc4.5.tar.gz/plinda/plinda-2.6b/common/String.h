
#ifndef _PLSTRING_H
#define _PLSTRING_H  1

#include <string.h>
#include <stream.h>
#include <strstream.h>

extern "C" char *strcat(char *dst, const char *src);



class String {
public:
  // friend functions
friend String operator+(const String& s1, const String& s2)  {
  char* str = new char[::strlen(s1.str) + ::strlen(s2.str) + 1];
  ::strcpy(str, s1.str);
  ::strcat(str, s2.str);
  String tmp(str);
  return tmp;
}

friend String operator+(const String& s1, const char* s2) {
  char* str = new char[::strlen(s1.str) + ::strlen(s2) + 1];
  ::strcpy(str, s1.str);
  ::strcat(str, s2);
  String tmp(str);
  return tmp;
}
friend String operator+(const String& s1, const char s2) {
  char* str = new char[::strlen(s1.str) + 2];
  ::strcpy(str, s1.str);
  ::strcat(str, &s2);
  String tmp(str);
  return tmp;
}

friend String operator+(const char* s1, const String& s2) {
  char* str = new char[::strlen(s1) + ::strlen(s2.str) + 1];
  ::strcpy(str, s1);
  ::strcat(str, s2.str);
  String tmp(str);
  return tmp;
}

friend ostream& operator<<(ostream& o, const String& s) {
  return (o << s.str);
}
friend int operator==(const String& x, const char* y) {
  return (::strcmp(x.str, y) == 0);
}
friend int operator==(const String& x, const String& y) {
  return (::strcmp(x.str, y.str) == 0);
}
friend int operator==(const char* x, const String& y) {
  return (::strcmp(x, y.str) == 0);
}
friend int operator!=(const String& x, const char* y) {
  return (::strcmp(x.str, y) != 0);
}
friend int operator!=(const String& x, const String& y) {
  return (::strcmp(x.str, y.str) != 0);
}
friend int operator!=(const char* x, const String& y) {
  return (::strcmp(x, y.str) != 0);
}
#if 0
friend  String operator+(const String& s1, const char* s2);
friend  String operator+(const char* s1, const String& s2);
friend  String operator+(const String& s1, const char s2) ;
friend  ostream& operator<<(ostream& o, const String& s);
friend  int operator==(const String& x, const char* y);
friend  int operator==(const String& x, const String& y);
friend  int operator==(const char* x, const String& y);
friend  int operator!=(const String& x, const char* y);
friend  int operator!=(const String& x, const String& y);
friend  int operator!=(const char* x, const String& y);
#endif
  String() { 
    str = new char[1];  
    str[0] = '\0';
  }
  String(const char* s) {
    str = new char[::strlen(s) + 1];
    ::strcpy(str, s);
  }
  // copy constructor
  String(const String& s) {
    str = new char[::strlen(s.str) + 1];
    ::strcpy(str, s.str);
  }
  String(const char c) {
    str = new char[2];
    str[0] = c;
    str[1] = '\0';
  }
  String(const int ic) {
    // not possible for a 32-bit integer to occupy more than 20 digits in print.
    str = new char[20];
    ostrstream ostr(str, 20);
    ostr << ic;
  }
  // destructor
  ~String() { delete[] str; }

  int length() { return ::strlen(str); }

  // assignment operators
  String& operator=(const char* s) {
    if(str != 0) delete [] str;

    str = new char[::strlen(s)+1];
    ::strcpy(str, s);
    return *this;
  }
  String& operator=(const String& s) {
    if(str != 0) delete[] str;

    str = new char[::strlen(s.str)+1];
    ::strcpy(str, s.str);
    return *this;
  }
  String& operator+=(const String& s) {
    *this = *this + s;
    return *this;
  }
  String& operator+=(const char* s) {
    *this = *this + s;
    return *this;
  }
  String& operator+=(const char s) {
    *this = *this + s;
    return *this;
  }

  char* chars(void) { return str; }
  void chars(char* ptr) { str = ptr; }

  // data type conversion operator
  operator char*() { return str; }

private: 
  char* str;
};



#endif // _STRING_H
