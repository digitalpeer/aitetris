// This may look like C code, but it is really -*- C++ -*-
//
// File:        Architectures.h
// Description: This file defines the types of architectures PLinda runs on
// Created:	      
// Author:	Peter Wyckoff
// Mail:        wyckoff@cs.nyu.edu

#ifndef _ARCHITECTURE_H_
#define _ARCHITECTURE_H_

#include <stdlib.h>
#include <bool.h>

class PLinda_Architectures { 
 public:
   static const bool supported(const char *type) 
     {
	if(strcmp(type,"alpha") == 0)
	  return true;
	if(strcmp(type,"linux") == 0)
	  return true;
	if(strcmp(type,"solaris") == 0)
	  return true;
	else if(strcmp(type,"sunos") == 0)
	  return true;
	else if(strcmp(type,"irix") == 0)
	  return true;
	else if(strcmp(type,"hpux") == 0)
	  return true;
	// add new architectures here please
	// also for now add them to the file tk/system.tk as this is
	// tk code. Specifically on line 129.
	else return false;
     }

   static const bool need_to_convert(const char *you, const char *server)
     {
       if(strcmp(you,"alpha") == 0 || strcmp(you,"linux") == 0) {
	 // you are a little endian machine
	 if(strcmp(server,"alpha") == 0 || strcmp(server,"linux") == 0)
	   return false;
	 return true;
       }
       // you are a big endian machine
       if(strcmp(server,"alpha") == 0 || strcmp(server,"linux") == 0)
	 return true;
       return false;
     }

};

#endif

