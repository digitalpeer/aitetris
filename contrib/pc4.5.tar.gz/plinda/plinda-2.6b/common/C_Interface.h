// This may look like C code, but it is really -*- C++ -*-
//
// File:        C_Interface.h
// Description: defines C library functions.
// Created:
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//

#ifndef _C_INTERFACE_H_
#define _C_INTERFACE_H_
 
#include <sys/types.h>
#ifdef __GNUG__
#include <sys/time.h>
#endif
#ifndef alpha
#include <sys/resource.h>
#endif
#ifdef alpha
#include <sys/wait.h>
#endif

extern "C" {
  int fchdir(int);
#ifdef __GNUG__
  int getopt(int argc, char* const*argv, const char* optstring);
#endif
#if defined(sunos)
  int setpgrp(int, int);
#endif
  char* getwd(char*);
  int close(int);
#ifdef __GNUG__
  int open(const char*, int ...);
 // void bcopy(char*, char*, int);
#if !defined(alpha) && !defined(linux)
  char *rindex(char *, char);
  char *index(char *,char);
#endif
#endif
  off_t lseek(int, off_t, int);
#if !defined(hpux) && !defined(irix) && !defined(linux)
  int wait3(int*, int, struct rusage *rusage); 
#endif
#ifndef hpux
  int getdtablesize(void);
#endif
  char *strcat(char *dst, const char *src);
}

#endif // _C_INTERFACE_H_
