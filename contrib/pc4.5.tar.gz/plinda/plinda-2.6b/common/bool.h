#ifndef _bool_h_
#define _bool_h_ 1

#ifndef __GNUG__
typedef int bool;
enum { false = 0, true = 1};
#endif

#endif
