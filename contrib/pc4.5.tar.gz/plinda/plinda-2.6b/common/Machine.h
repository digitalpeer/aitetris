// This may look like C code, but it is really -*- C++ -*-
//
// File:        Machine.h
// Description: This defines machine-dependent functions.
// Created:      
// Author:      Brian G. Anderson
// Mail:        jeong@cs.nyu.edu
//

#ifndef _MACHINE_H_
#define _MACHINE_H_

#include <stream.h>
#include <fstream.h>
#include <sys/types.h>

#include "String.h"

#include "plinda_ids.h"
#include "ErrorType.h"

#ifndef _OUTLINE_
#define INLINE inline
#else
#define INLINE
#endif
// define data object sizes of base types.
const int PL_INT_SZ = sizeof(int);
const int PL_LONG_SZ = sizeof(long);
const int PL_SHORT_SZ = sizeof(short);
const int PL_CHAR_SZ = sizeof(char);
const int PL_DOUBLE_SZ = sizeof(double);
const int PL_FLOAT_SZ = sizeof(float);
const int PL_GID_SZ = sizeof(gid);
const int PL_TRANSID_SZ = sizeof(transid);
const int PL_PHYSID_SZ = sizeof(physid);
const int PL_PROCID_SZ = sizeof(procid);
//const int PL_PATTERN_TYPE_SZ = sizeof(Pattern_Type);
const int PL_ERROR_TYPE_SZ = sizeof(ErrorType);
const int PL_PTR_SZ = sizeof(void*);

// functions for (efficient) block memory copy/compare.

INLINE void bmv(const void* a, void* b, int sz);
INLINE int bcm(const void* a, const void* b, int sz);

// machine independent loads and stores.

// primitive data types
INLINE int ld_int(const void* p);
INLINE void st_int(int x, void* p);
INLINE char ld_char(const void* p);
INLINE void st_char(char x, void* p);
INLINE short ld_short(const void* p);
INLINE void st_short(short x, void* p);
INLINE long ld_long(const void* p);
INLINE void st_long(long x, void* p);
INLINE float ld_float(const void* p);
INLINE void st_float(float x, void* p);
INLINE double ld_double(const void* p);
INLINE void st_double(double x, void* p);

// identifiers
INLINE gid ld_gid(const void* p);
INLINE void st_gid(const gid& x, void* p);
INLINE transid	ld_transid(const void* p);
INLINE void	st_transid(const transid& x, void* p);
INLINE physid ld_physid(const void* p);
INLINE void st_physid(const physid& x, void* p);
INLINE procid ld_procid(const void* p);
INLINE void st_procid(procid x,void* p);


// ErrorType
INLINE ErrorType ld_error_type(const void* p);
INLINE void st_error_type(const ErrorType& x, void* p);

INLINE String dump_bytes(const void* ptr, int len);
INLINE void dump_bytes(ofstream& ds, const void* ptr, int len);

#ifndef _OUTLINE_
#include "Machine.iC"
#endif // _OUTLINE_

extern const char *REMOTESH;

#endif // _MACHINE_H_

