// This may look like C code, but it is really -*- C++ -*-
//
// File:        ErrorType.h 
// Description: This file defines errors. 
// Created:      
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
//

#ifndef _ERROR_TYPE_H_
#define _ERROR_TYPE_H_

// These are definitions for errors.
#ifdef __GNUG__
#include <assert.h>
#endif


class ErrorType {
public:
  ErrorType(const char* msg =0, int =-1);
  unsigned int index(void) const;
#ifndef _OUTLINE_
  inline
#endif
  const char* message(void) const;
  int ok(void) const; 
  int fail(void) const;
  int operator !(void) const;
  ErrorType& operator =(const ErrorType& x);
private:
  unsigned char error_index;
};

class ErrorMessage {
public:
  static unsigned int get_next_index(const char* e_msg, int =-1);
#ifndef _OUTLINE_
  inline
#endif
  static const char* message(int e_idx);
private:
  static const MAX_ERRORS; 
  static unsigned char next_index;
  static char** message_table;
};

////////////////////////////////////////////////////////
// Declaration of errors.
////////////////////////////////////////////////////////
extern const ErrorType NO_ERROR;
extern const ErrorType E_FAIL;
extern const ErrorType E_NOT_OPEN;
extern const ErrorType E_IN_USE;
extern const ErrorType E_INV_PATTERN;
extern const ErrorType E_INV_IO_DATA;
extern const ErrorType E_INV_MESSAGE;
extern const ErrorType E_INV_STATUS;
extern const ErrorType E_PARTIAL_MESSAGE;
extern const ErrorType E_IMPROPER_REPLY;
extern const ErrorType E_CREATE_GROUP;
extern const ErrorType E_OPEN_GROUP;
extern const ErrorType E_INV_GROUP;
extern const ErrorType E_INV_GID;
extern const ErrorType E_INV_TRANSID;
extern const ErrorType E_SEND_FAIL;
extern const ErrorType E_RECEIVE_FAIL;
extern const ErrorType E_COMMIT_FAIL;
extern const ErrorType E_NOT_REGISTERED;
extern const ErrorType E_ALREADY_REGISTERED;
extern const ErrorType E_NO_TRANS;
extern const ErrorType E_ALREADY_TRANS;
extern const ErrorType E_INV_LIFETIME;
extern const ErrorType E_DUP_PHYSID;
extern const ErrorType E_ADDR_DIFFERS;
extern const ErrorType E_INV_ABORT_SIG;
extern const ErrorType E_ALREADY_FAIL;
extern const ErrorType E_CHKPT_DIR;
extern const ErrorType E_CHKPT_HEADER;

extern const ErrorType E_INV_PHYSID;
extern const ErrorType E_INV_UNLOCK;
extern const ErrorType E_IO_FAIL;
extern const ErrorType E_CHKPT_FILE_OPEN;
extern const ErrorType E_CHKPT_FILE_READ;
extern const ErrorType E_CHKPT_FILE_WRITE;
extern const ErrorType E_CHKPT_FILE_CLOSE;
extern const ErrorType E_TUPLE_TOO_BIG;
extern const ErrorType E_INV_TUPLE_HANDLE;
extern const ErrorType E_IO_TO_TUPLE;
extern const ErrorType E_CHECKPT_GROUP;
extern const ErrorType E_INV_PROCESS;
extern const ErrorType E_INV_HOST;
extern const ErrorType E_OVER_LOADED;
extern const ErrorType E_DAEMON_PRESENT;


// ***** for Griffin *******

extern const ErrorType E_NOT_FOUND;
extern const ErrorType E_NULL_PTR;
extern const ErrorType E_DANGLING_PTR;
extern const ErrorType E_UPDATE_FAIL;
extern const ErrorType E_CREATE_NAMESPACE_FAIL;
extern const ErrorType E_CREATE_DIRECTORY_FAIL;
extern const ErrorType E_DESTROY_NAMESPACE_FAIL;
extern const ErrorType E_DESTROY_DIRECTORY_FAIL;
extern const ErrorType E_INACTIVE_SERVER;
extern const ErrorType E_SOCKET_FAIL;
extern const ErrorType E_ABORT;
extern const ErrorType E_KILL;
extern const ErrorType E_PING;
extern const ErrorType E_PONG;
extern const ErrorType E_UNINITIALIZED;

#define assertif(x,y) assert(((x)?(y):1))

#ifndef _OUTLINE_
#include "ErrorType.iC"
#endif

#endif // _ERROR_TYPE_HH_





