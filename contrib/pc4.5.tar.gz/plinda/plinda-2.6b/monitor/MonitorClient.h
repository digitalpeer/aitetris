#ifndef _MonitorClient_H_
#define _MonitorClient_H_ 1


#include <iostream.h>
#include <strstream.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

#include "MonitorRequest.h"
#include "ClientCommLink.h"
#include "Header.h"

typedef struct hl_type {
    char   name[60];
    int    id;
    long   cpu_load;
    long   mem;
    int    num_clients;
    int    max_clients;
    char    status[30];
}  HostType;

typedef struct ps_type {
    procid pid;
    char   status[30];
    char   host[60];
    int    line;
    char   file[100];
    char   exec[100];
} ProcStatusType;


typedef DLList<HostType*>        HostList;
typedef DLList<ProcStatusType*>  ProcStatusList;

#define MAX_LINE_LEN     500

#ifdef MIGRATION_TEST
void 
add_host(const char* host_name, unsigned short server_port, 
	 const char* server_host, const char *host_type,char *uname,
	 int busy_interval);
#else
void 
add_host(const char* host_name, unsigned short server_port, 
	 const char* server_host, const char *host_type,char *uname) ;
#endif


extern HostList        g_hostlist;  
extern ProcStatusList  g_pinfo_list;

extern Header   request;
extern Header   reply;
extern ClientCommLink   server_agent;

extern procid my_pid;
extern long   my_transient_id;
extern int    server_port_int ;
extern int    connected_to_server;

extern char*  status_name[];
extern char*  xhost_name;
extern int server_failure;
#endif  // _MonitorClient_H_
