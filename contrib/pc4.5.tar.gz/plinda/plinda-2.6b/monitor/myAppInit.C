
#include "myAppInit.h"


/*****************************************************************/
/* This function installs all the PLinda specific commands in the*/
/* PLinda/Tcl interpreter we generate. This function is called by*/
/* Tcl_AppInit function in the tkAppInit.C file                  */
/*****************************************************************/
int PLinda_Init(Tcl_Interp* interp)
{

    /* The template for adding new commands is :: 
       Tcl_CreateCommand(interp, "tcl_command_name", 
           function_which_implements_the_command, 
           NULL, NULL);
    */
    
    Tcl_CreateCommand(interp, "pl_server_state", 
		      server_state_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_add_host",
		      add_host_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_del_host",
		      del_host_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_kill_process",
		      kill_process_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_process_info",
		      process_info_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_migrate_process",
		      migrate_process_cmd,
		      NULL, NULL);
#if 0
    Tcl_CreateCommand(interp, "pl_list_groups",
		      list_groups_cmd,
		      NULL, NULL);

    Tcl_CreateCommand(interp, "pl_dump_group",
		      dump_group_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_single_step",
		      single_step_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_end_step",
		      end_step_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_next_step",
		      next_step_cmd,
		      NULL, NULL);
#endif
    Tcl_CreateCommand(interp, "pl_main_process",
		      main_process_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_create_daemons",
		      create_daemons_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_host_list",
		      host_list_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_monitor_info",
		      monitor_info_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_spawn_server",
		      spawn_server_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_check_server",
		      check_server_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_state",
		      current_state_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_open",
		      open_conn_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_close",
		      close_conn_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_cleanup",
		      cleanup_cmd,
		      NULL, NULL);
    Tcl_CreateCommand(interp, "pl_set_config",
		      set_config_cmd,
		      NULL, NULL);
#if 0
    Tcl_CreateCommand(interp, "pl_traces",
		      get_traces_cmd,
		      NULL, NULL);
#endif
    return TCL_OK;
}

/*---------------------------------------------------------------------*/
int 
server_state_cmd(ClientData , Tcl_Interp *interp, int argc, char *argv[]){
    int state;
    CHECK_ARGS(1);
    Tcl_GetInt(interp, argv[1], &state);
    //PUTD(state);
    set_server_state((MonitorRequest)state);
    return TCL_OK;
}
/*---------------------------------------------------------------------*/
#ifdef MIGRATION_TEST
int 
add_host_cmd(ClientData , Tcl_Interp *interp, int argc, char *argv[]){
    CHECK_ARGS(6);
    PUTS(argv[1]);
    PUTD((unsigned short)(atoi(argv[2])));
    PUTS(argv[3]);
    PUTS(argv[4]);
    PUTS(argv[5]);
    PUTD(argv[6]);
    add_host(argv[1],(unsigned short)(atoi(argv[2])),argv[3],argv[4],argv[5],
	     atoi(argv[6]));
    return TCL_OK;
}
#else
int 
add_host_cmd(ClientData , Tcl_Interp *interp, int argc, char *argv[]){
    CHECK_ARGS(5);
    PUTS(argv[1]);
    PUTD((unsigned short)(atoi(argv[2])));
    PUTS(argv[3]);
    PUTS(argv[4]);
    PUTS(argv[5]);
    add_host(argv[1],(unsigned short)(atoi(argv[2])),argv[3],argv[4],argv[5] );
    return TCL_OK;
}
#endif
/*---------------------------------------------------------------------*/
int 
del_host_cmd(ClientData , Tcl_Interp *interp, int argc, char *argv[]){
    CHECK_ARGS(1);
    PUTS(argv[1]);
    del_host(argv[1]);
    return TCL_OK;
}
/*---------------------------------------------------------------------*/
int 
set_config_cmd(ClientData , Tcl_Interp *interp, int argc, char *argv[]){
  extern void set_server_config(int param, long value);
  CHECK_ARGS(2);
  PUTD(atoi(argv[1])); 
  PUTD((int)atol(argv[2])); 
  set_server_config(atoi(argv[1]), atol(argv[2]));
  return TCL_OK;
}
/*---------------------------------------------------------------------*/
int 
kill_process_cmd(ClientData , Tcl_Interp *interp, int argc, char *argv[]){
    int pid;
    CHECK_ARGS(1);
    Tcl_GetInt(interp, argv[1], &pid);
    PUTD(pid);
    kill_proc((long)pid);
    return TCL_OK;
}
/*---------------------------------------------------------------------*/
int 
migrate_process_cmd(ClientData , Tcl_Interp *interp, 
		    int argc, char *argv[]){
    int pid;
    CHECK_ARGS(2);
    Tcl_GetInt(interp, argv[1], &pid);
    PUTD(pid);
    PUTS(argv[2]);
    migrate_proc((long)pid, argv[2]);
    return TCL_OK;
}
/*---------------------------------------------------------------------*/
int 
list_groups_cmd(ClientData , Tcl_Interp *interp, 
		int argc, char *argv[]){
    CHECK_ARGS(0);
    list_tuplegroups();
    return TCL_OK;
}
/*---------------------------------------------------------------------*/
int 
dump_group_cmd(ClientData , Tcl_Interp *interp, 
	       int argc, char *argv[]){
    CHECK_ARGS(1);
    PUTS(argv[1]);
    dump_group(argv[1]);
    return TCL_OK;
}
/*---------------------------------------------------------------------*/
int 
single_step_cmd(ClientData, Tcl_Interp *interp, 
		int argc, char *argv[]){
    int pid;
    CHECK_ARGS(1);
    Tcl_GetInt(interp, argv[1], &pid);
    PUTD(pid);
//    start_stepping_proc((long)pid);
    return TCL_OK;
}
/*---------------------------------------------------------------------*/
int 
end_step_cmd(ClientData , Tcl_Interp *, int , char *[]){
   return 1;
}
/*---------------------------------------------------------------------*/
int 
next_step_cmd(ClientData , Tcl_Interp *, int , char *[]){
   return 1;
}
/*---------------------------------------------------------------------*/
int 
main_process_cmd(ClientData , Tcl_Interp *interp, 
		 int argc, char *argv[]){
    CHECK_ARGS(2);
    PUTS(argv[1]); PUTS(argv[2]);
    /* program_name, host_name */
    spawn_prog(argv[1], argv[2]);
    return TCL_OK;
}
/*---------------------------------------------------------------------*/
int 
create_daemons_cmd(ClientData , Tcl_Interp *, int, char *[]){
   return 1; 
}
/*---------------------------------------------------------------------*/
int 
host_list_cmd(ClientData , Tcl_Interp *interp, 
	      int argc, char *argv[]){

    HostType *hinfo;
    char  cmd[1000];

    CHECK_ARGS(0);
    get_hostlist();
    Tcl_Eval(interp, "HW_clear");
    for(Pix p = g_hostlist.first(); p!=0; g_hostlist.next(p)){
      hinfo = g_hostlist(p);
      sprintf(cmd, "HW_update_entry %s %s %d %s", hinfo->name,
	      hinfo->status, hinfo->num_clients, "Y");
      Tcl_Eval(interp, cmd);
    }
    return TCL_OK;
}
/*---------------------------------------------------------------------*/
int 
monitor_info_cmd(ClientData , Tcl_Interp *interp, 
		 int argc, char *argv[]){
//    int i;
    ProcStatusType *pinfo;
    Pix p;
    char  cmd[1000];
    extern int app_started;

    CHECK_ARGS(0);
    get_monitor_info();
    Tcl_Eval(interp, "PW_clear");
    if (app_started==1 && g_pinfo_list.length()==0) {
	app_started = 0;
	Tcl_Eval(interp, "notify_trace");
    }
    for(p = g_pinfo_list.first(); p!=0; g_pinfo_list.next(p)){
	pinfo = g_pinfo_list(p);
	sprintf(cmd, "add_entry end %ld %s %s %d %s %s ", pinfo->pid,
		pinfo->status, pinfo->host, pinfo->line, pinfo->file,
		pinfo->exec);
	Tcl_Eval(interp, cmd);
	sprintf(cmd, "update_view %ld %s %d", pinfo->pid, pinfo->file, 
		pinfo->line);
	Tcl_Eval(interp, cmd);
	app_started = 1;
    }
    return TCL_OK;
}
/*---------------------------------------------------------------------*/
int
current_state_cmd(ClientData , Tcl_Interp *interp, 
		   int argc, char *argv[]){

  // full path name of the connection file (plinda.server)
  CHECK_ARGS(1);  

  // -----------------------
  //  INIT : 0
  //  NORMAL : 1
  //  DETECT_FAIL : 2
  //  INVALID : -1
  // -----------------------;
  

  if (connected_to_server == 0){
      if (server_failure == 0) {
	  interp->result = "0";
      } else {
	  // not possible ;
	  interp->result = "-1";
      }
  } else {
      check_server();
      if (server_failure == 0){
	  if (conn_file_present(argv[1]) == 1){
	      // normal state;
	      interp->result = "1";
	  } else {
	      // not possible;
	      interp->result = "-1";
	  }
      } else {
	  // detect failure;
	  interp->result = "2";
      }
  }
  return TCL_OK;
}
/*----------------------------------------------------------------------*/
int 
conn_file_present(char* f){
  FILE* fp = fopen(f, "r");
  if (fp == NULL) {
      fclose(fp);
      return 0;
  }
  fclose(fp);
  return 1;
}
/*----------------------------------------------------------------------*/
int
open_conn_cmd(ClientData , Tcl_Interp *interp, 
		   int argc, char *argv[]){
  
  extern ClientCommLink server_agent;
  procid my_pid;
  unsigned   short server_port;
  char server_host[200];
  extern int connected_to_server, server_port_int;

  // need to give the full path name of plinda.server
  CHECK_ARGS(1);
  
  // get server port & host 
  {
    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL){
      // no plinda.server file => error
      //::printf("no plinda.server file! \n");
      fflush(stdout);
      interp->result = "-1";
      return TCL_OK;
    }
    fscanf(fp,"%d", &server_port_int);
    server_port = (unsigned short)server_port_int;
    fscanf(fp, "%s", server_host);
    fflush(stdout);
    fclose(fp);
  }
      
  my_pid = procid(2);

  server_agent.initialize(my_pid, server_port, server_host,0);
  if (server_agent.request_link() == -1) {
    ::printf("cannot connect to server on %s \n", server_host);
    fflush(stdout);
    server_failure = 0;
    connected_to_server = 0;
    interp->result = "0";
    return TCL_OK;
  }

  ::printf("connected to server on %s  at port = %d\n", server_host, (int)server_port);
  fflush(stdout);
  connected_to_server = 1;
  server_failure = 0;
  interp->result = "1";
  return TCL_OK;

}
/*----------------------------------------------------------------------*/
int
close_conn_cmd(ClientData , Tcl_Interp *interp, 
	       int argc, char *argv[]){
  extern ClientCommLink server_agent;

  CHECK_ARGS(0);
  //assert(connected_to_server);
  server_agent.close();
  connected_to_server = 0;
  server_failure = 0;
  interp->result = "1";
  return TCL_OK;
}
/*----------------------------------------------------------------------*/
int 
spawn_server_cmd(ClientData , Tcl_Interp *interp, 
		 int argc, char *argv[]){
   extern const char *REMOTESH;
    char  cmd[2000];

    // the server host and the server options...
    CHECK_ARGS(3);
    PUTS(argv[1]);
    PUTS(argv[2]);
    PUTS(argv[3]);

    ::system("rm plinda.lock");
    sprintf(cmd, "%s %s \"~/plinda/bin/%s/plinda_server %s \" & ", REMOTESH,
	    argv[1], argv[2], argv[3]);

    ::system(cmd);
    ::printf(" %s \n", cmd); fflush(stdout);
    
    while(1) {
	if(open("plinda.lock",O_RDONLY) > 0) break;
	sleep(1);
	::printf("> check if the server is running !\n");
    }
     
    //system("sleep 8");

    signal(SIGPIPE,signal_catcher);
    interp->result = "1";
    return TCL_OK;
    
}
/*-----------------------------------------------------------------*/
int
cleanup_cmd(ClientData , Tcl_Interp *interp, 
	       int argc, char *argv[]){
  extern ClientCommLink server_agent;
  char cmd[1000];

  CHECK_ARGS(1);
  server_agent.close();
  ::sprintf(cmd, "/bin/sh %s", argv[1]);
  ::system(cmd);
  ::printf("cleanup :: %s \n", argv[1]); fflush(stdout);
  ::sprintf(cmd, "/bin/rm %s", argv[1]);
  ::system(cmd);
  server_failure = 0;
  connected_to_server = 0;
  return 1;
}
 
/*-----------------------------------------------------------------*/
int
get_traces_cmd(ClientData , Tcl_Interp *interp, 
	       int argc, char *argv[]){
    CHECK_ARGS(0);
    get_traces();
    return TCL_OK;
}

/*-----------------------------------------------------------------*/
int 
check_server_cmd(ClientData , Tcl_Interp *interp, 
		 int argc, char *argv[]){
    CHECK_ARGS(0);
    check_server();
    return TCL_OK;
}
/*-----------------------------------------------------------------*/
int
process_info_cmd(ClientData , Tcl_Interp *interp, 
		 int argc, char *argv[]){

    ProcStatusType *pinfo;
    int pid;
    char res[2000];

    CHECK_ARGS(1);
    Tcl_GetInt(interp, argv[1], &pid);
    for(Pix p = g_pinfo_list.first(); p!=0; g_pinfo_list.next(p)){
      pinfo = g_pinfo_list(p);
      if (pinfo->pid == (unsigned)pid){
	  ::sprintf(res, "%ld %s %s %d %s %s", pinfo->pid, pinfo->status, 
		    pinfo->host, pinfo->line, pinfo->file, pinfo->exec);
	  Tcl_SetResult(interp, res, TCL_VOLATILE);
      }
    }
    return TCL_OK;
}
