
#include <sys/types.h>
#include <assert.h>

// PLinda header files
#include "ErrorType.h"
#include "ServerCommLink.h"

#include "plinda_ids.h"
#include "MonitorProcess.h"
#include "Transaction.h"
#include "TupleGroup.h"
#include "ProcessManager.h"
#include "TransactionManager.h"
#include "TupleGroupManager.h"
#include "ObjectSpace.h"
#include "Header.h"
#include "DaemonProcess.h"

#ifdef _OUTLINE_
#define inline
#include "MonitorProcess.iC"
#endif



/*--------------------------------------------------------------*/

MonitorProcess::MonitorProcess(const char* host)
: Process(MONITOR, MONITOR_PROCID) {

  x_cur_request.header = 0;
  x_cur_request.tuple = 0;
  x_update_flag = 0;
  set_update_interval(ObjectSpace::monitor_update_interval);
  status(RUNNING);

  if (host != 0) {
      x_host_name = new char [ ::strlen(host) + 1];
      ::strcpy(x_host_name, host);
  }
  x_host_name  = 0;
}
    
MonitorProcess::~MonitorProcess(void) {
  if (comm_link() != 0) {
      // shutdown the communication link.
      comm_link()->shutdown();
      comm_link(0);
  }
  if (x_host_name != 0) delete [] x_host_name;
  x_host_name = 0;
}

void 
MonitorProcess::enqueue_request(Header *header,Tuple *tuple) {
    assert(x_cur_request.header == 0 && x_cur_request.tuple == 0);
    current_request(header,tuple);
    next_step(1);
    status(REQUEST_READY);
}

void
MonitorProcess::destroy_current_request() {
    assert(x_cur_request.header != 0);
    delete x_cur_request.header;
    if(x_cur_request.tuple) 
      Tuple::destroy(x_cur_request.tuple);

    /* clear the cur request for new message */
    x_cur_request.header = 0;
    x_cur_request.tuple = 0;

    /* now it is ready to take more requests (=> RUNNING status) */
    if(status() == REQUEST_READY) {
	status(RUNNING);
    }

}


/*--------------------------------------------------------------*/
int
MonitorProcess::handle_request(void) {

    /*this function should be called when there is a request to handle. */
    assert(current_request().header != 0);

    Header* header = current_request().header;
    Tuple *tuple =  current_request().tuple;

    /*prepare  reply */
    Header reply;
    reply.monitorMsgType(header->monitorMsgType());
    reply.transientId(transient_id());

    /* check if the current message and its sender are okay. */
    {
	ErrorType stat;
	if(!(stat = check_for_errors(header,tuple))) {
	   reply.status(stat);
	   send_reply(reply);
	   return 0;
	}
    }
    /* service the requests and pack the replies into "reply" */
    switch(header->monitorMsgType()) {
      case DUMMY_REQUEST:
	{
	  reply.status(NO_ERROR);
	  send_reply(reply);
	}
	break;
      case SUSPEND_SERVER:
	{
	  ObjectSpace::state(ObjectSpace::SUSPENDED);
	  reply.status(NO_ERROR);
	  send_reply(reply);
	}
	break;
      case RESUME_SERVER:
	{
	  ObjectSpace::state(ObjectSpace::RUNNING);
	  reply.status(NO_ERROR);
	  send_reply(reply);
	}
	break;
      case SHUTDOWN_SERVER:
	{
	  ObjectSpace::state(ObjectSpace::SHUTDOWN_SERVER);
	  reply.status(NO_ERROR);
	  send_reply(reply);
	}
	break;
      case DEBUGGING:
	{
	   assert(0); // not doing this
	  ObjectSpace::mode(ObjectSpace::DEBUGGING);
	  reply.status(NO_ERROR);
	  send_reply(reply);
	}
	break;
      case TRACE_LIST:
	cerr << "get_traces not currently supported\n";
	assert(0);
	// look at plinda 2.0 code to see how to do this

      case HOST_LIST:
	{
	   Tuple *hlist = ObjectSpace::proc_mgr.host_list();
	   assert(hlist);
	   reply.tupleLength(hlist->length());
	   reply.status(NO_ERROR);
	   send_reply(reply,hlist);


	   Tuple::destroy(hlist);
	}
	break;
      case KEEP_STATISTICS:
	assert(0);
      case GET_STATISTICS:
	assert(0);
      case MONITOR_INFO:
	{
	  /* this is just a DLList of IO_patterns*/
	  Tuple *mlist = NULL;
	  
	  /* get the info list from process manager*/
	  mlist = ObjectSpace::proc_mgr.monitor_info();
	  assert(mlist);
	  reply.status(NO_ERROR);
	  reply.tupleLength(mlist->length());
	  send_reply(reply, mlist);
	  Tuple::destroy(mlist);
	}
	break;
      case ADD_HOST:
	{

	  DaemonProcess* dproc; 
	  procid id;
	  /* the usr needs to specify the new host name */

	  
//	  const char *hname = header->hostName();	  
//	  const char *htype = header->hostType();

	  char hname[30], htype[30],uname[30];

	  assert(tuple && tuple->numOfFields() == 3);
	  tuple->read(0, TupleField::PLchar, hname, 30);
	  tuple->read(1, TupleField::PLchar, htype, 30);
	  tuple->read(2, TupleField::PLchar, uname, 30);

	  /* check if the host is already in the list. */
	  dproc = ObjectSpace::proc_mgr.find_daemon(hname);

	  if(dproc == 0) {
	     /* ask the process manager to create a new daemon for
		that host */
	     dproc = ObjectSpace::proc_mgr.create_daemon(hname,htype,uname);
	     if(dproc != 0) {
	      id = dproc->identifier();

	      reply.status(NO_ERROR);
	    } else {
	      id = zero_procid;
	      reply.status(E_INV_HOST);
	    }
	  } else {
	      // if there was a daemon and it has failed then it is
	      // OK to add_host (that_host)...
	      if (dproc->status() == Process::FAILURE_DETECTED) {
		  if(ObjectSpace::piranha_flag == 1) 
		      dproc->status(DISPATCHED);
		  else 
		      dproc->status(REQUEST_READY);
		  reply.status(NO_ERROR);
	      } else {
		  reply.status(E_DAEMON_PRESENT);
	      }
	      id = dproc->identifier();
	   }
	  // send the procid assigned by server for this daemon
	  // to monitor so it can spawn a daemon on the host...
	  reply.processId(id);
	  send_reply(reply);
       }
	break;
      case DEL_HOST:
	{
	   char name[30];
	   assert(tuple && tuple->numOfFields() == 1);
	   tuple->read(0, TupleField::PLchar, name, 30);
	   ErrorType stat = ObjectSpace::proc_mgr.delete_host(name);
	   reply.status(stat);
	   send_reply(reply);
	}
	break;
      case DUMP_GROUP:
	cerr << "dump_group not currently supported\n";
	assert(0);
	// look at plinda2.0 code to see how to fix this
      case KILL_PROCESS:
	{
	  procid pid = header->processId();
	  ErrorType stat = ObjectSpace::proc_mgr.kill_PROCESS(pid);
	  reply.status(stat);
	  send_reply(reply);
	}
	break;
      case MIGRATE_PROCESS:
	{
	  procid pid = header->processId();
	  char new_host[30];
	  assert(tuple && tuple->numOfFields() == 1);
	  tuple->read(0, TupleField::PLchar, new_host, 30);
	  ErrorType stat = ObjectSpace::proc_mgr.migrate_PROCESS(pid,new_host);
	  reply.status(stat);
	  send_reply(reply);
	}
	break;
      case PROCESS_INFO:
	{
	  /* as of now nothing much... */
	  reply.status(NO_ERROR);
	  send_reply(reply);
	}
	break;
      case SET_CONFIG:
	{
	  int param_num = header->paramNum();
	  unsigned param_value = header->paramValue();
	  ObjectSpace::set_config((ObjectSpace::ConfigParam)param_num, 
				  param_value);
	  reply.status(NO_ERROR);
	  send_reply(reply);
	}
	break;
      case SET_MAINPROGRAM:
	{
	  char exec_name[100], host[100];
	  assert(tuple && tuple->numOfFields() == 2);
	  tuple->read(0, TupleField::PLchar, exec_name, 100);
	  tuple->read(1, TupleField::PLchar, host, 100);
	  ErrorType stat =
	    ObjectSpace::proc_mgr.spawn_main_program(exec_name, host);
	  reply.status(stat);
	  send_reply(reply);
	}
	break;
      case UPDATE_INTERVAL:
	assert(0);
      case SINGLE_STEP:
	assert(0);
      case END_STEPPING:
	assert(0);
      case NEXT_STEP:
	assert(0);
      case LIST_TUPLEGROUPS:
	cerr << "Listing tuple groups is currently not supported\n";
	assert(0);
	// look at plinda2.0 code to see how to fix this
      default:
	assert(0);
    }
    /* reset the update_flag so that the next reply goes only
       after the timer expires */
    x_update_flag = 0;
    return 1;
}


/*-----------------------------------------------------------------*/
int 
MonitorProcess::send_reply(Header &header, Tuple *tuple) {
    status(RUNNING);

    if(comm_link() == 0 || status() == FAILURE_DETECTED) {
	declare_failure();
	destroy_current_request();
	return -1;
    }

    if(comm_link()->send(header,tuple) == -1)  {
	declare_failure();
	// destroy the current request. ;
	destroy_current_request();
	return -1;
    }

    // destroy the current request.;
    destroy_current_request();
    return 0;
}

/*-----------------------------------------------------------------*/
void
MonitorProcess::declare_failure(void) {
  status(FAILURE_DETECTED);
  if(comm_link() != 0) {
    comm_link()->shutdown();
    comm_link(0);
  }
}

/*-----------------------------------------------------------------*/
void
MonitorProcess::handle_failure(void) {

  if(x_cur_request.header != 0) {
      destroy_current_request();
  }

  status(FAILURE_HANDLED);
  if (comm_link() != 0){
      delete comm_link();
  }
  comm_link(0);

}

/*-----------------------------------------------------------------*/
int
MonitorProcess::check_failure(void) {
  if(comm_link() == 0) {
    return 0;
  }
  return comm_link()->check_failure();
}


/*-----------------------------------------------------------------*/
// we check if the status of the current message is consistent
// with that of this process. we deduce the status of the sender
// process from that of its message.
ErrorType
MonitorProcess::check_for_errors(const Header *h, const Tuple *t) {

  if(!(h->status())) {
    return h->status();
  }
  
  /* process only receive requests in the RUNNING status.*/
  if(status() == REQUEST_BLOCKED || status() == COMPLETED) {
    return E_INV_STATUS;
  }
  assert((h->tupleLength() == 0 && t == 0) ||
	 (t && t->length() == h->tupleLength()));

  return NO_ERROR;
}

void
MonitorProcess::kill(void) {
   extern const char *REMOTESH;
  if(completed() || error_found()) return;

  char command[1000];
 
  ::sprintf(command, "%s %s kill -9 %ld", REMOTESH, x_host_name, 
	    transient_id());
  ::system(command);

  cerr << "> kill the monitor process \n";
  cerr.flush();

  // shutdown the link.
  status(COMPLETED);
  if(comm_link() != 0) {
    comm_link()->set_done();
    delete comm_link();
    comm_link(0);
  }
}

/*-----------------------------------------------------------------*/
// need to provide a print function ...
/*----------------------------------------------------------------*/
