

/*---------------   MonitorMessage Type   ------------------------*/

#ifndef _MonitorRequest_H_
#define _MonitorRequest_H_


enum MonitorRequest {
    
    DUMMY_REQUEST = 0,
    
    SUSPEND_SERVER = 1,
    RESUME_SERVER = 2,
    SHUTDOWN_SERVER = 3,
    
    HOST_LIST = 4,
    ADD_HOST = 5,
    DUMP_GROUP = 6,

    MONITOR_INFO = 7,
    KILL_PROCESS = 8,
    MIGRATE_PROCESS = 9,
    PROCESS_INFO = 10,

    SET_CONFIG = 11,
    SET_MAINPROGRAM = 12,
    
    KEEP_STATISTICS = 13,
    GET_STATISTICS = 14,
     
    LIST_TUPLEGROUPS = 15,
    DEL_HOST = 16,

    SINGLE_STEP = 17,       
    END_STEPPING = 18,
    NEXT_STEP = 19,

    TRANSACTION_STATUS = 20,
    MONITOR_XABORT = 21,
    MONITOR_XSTART = 22,
    MONITOR_XCOMMIT = 23,
    
    TUPLEGROUP_DATA = 24,
    MONITOR_IN = 25,
    MONITOR_OUT = 26,
    MONITOR_RD = 27,
    UPDATE_INTERVAL = 28,
    
    IN_CONDITIONTUPLE = 29,
    OUT_CONDITIONTUPLE = 30,
    
    ABORT_USERTRANS = 31,
    DEBUGGING = 32,
    CREATE_DAEMONS = 33,
    TRACE_LIST = 34
	
    };


#endif  // _MonitorRequest_H_
