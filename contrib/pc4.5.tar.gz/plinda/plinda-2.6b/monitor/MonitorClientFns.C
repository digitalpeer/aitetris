#include "Machine.h"
#include "MonitorClient.h"
#include "Architectures.h"
#include "config.h"
/*----------------------------------------------------------------------*/




Header   request;
Header   reply;
Tuple    *requestTuple = NULL;
Tuple    *replyTuple = NULL;

ClientCommLink   server_agent;


int
communicate(){


   assert(replyTuple == NULL);
   assert(request.type() == Header::SEND_MONITOR_MESSAGE);
   if (server_agent.send(request,requestTuple) == -1){
      return -1;
   }
   reply.init();
   if (server_agent.receive(reply,replyTuple) == -1){
      reply.init();
      replyTuple = NULL;
      cerr << "error: no server reply !\n";
      return -1;
   }
   
   if(request.myProcessId() != reply.myProcessId() ||
	  request.myProcessId() != my_pid ||
      request.monitorMsgType() != reply.monitorMsgType() ||
      (reply.tupleLength() == 0 && replyTuple != 0) ||
      (reply.tupleLength() > 0 && replyTuple == 0) ||
      (reply.tupleLength() > 0 && replyTuple->length() != reply.tupleLength())){
     cerr << "error: incorrect reply type from server !\n";
     return 1;
   }
   if (!reply.status()){ 
      cerr << "error reply status from server !\n";
      return 1;
   }
   return 1;
}
extern int server_failure;

/*--------------------------------------------------------------------*/
void 
signal_catcher(int ) {

   server_failure = 1;
   cerr << "\nerror: server failed !\n";
}

/*--------------------------------------------------------------------*/
void 
get_hostlist()
{
   int i;
   extern HostList  g_hostlist;
   extern char *status_name[];

   assert(replyTuple == NULL);
   request.init();
   request.monitorMsgType((MonitorRequest)HOST_LIST);
   request.transientId(my_transient_id);


   if(communicate() == -1) {
      server_failure = 1;
      return; 
   }
   for(i=0; i<g_hostlist.length(); i++){
      delete g_hostlist.remove_rear();
   }
   g_hostlist.clear();

   assert(replyTuple);
   assert(replyTuple->length() == reply.tupleLength());
   assert(replyTuple->numOfFields() == 8);
   //cout << "\n",
   //cout << "--  NAME  -- P# -- Max P# -- STATUS\n"; 
   int howMany;
   replyTuple->read(0,TupleField::PLint,howMany);
   char *hostNames;
   replyTuple->read(1,TupleField::PLchar, hostNames);

   int  *hostIds;
   replyTuple->read(2,TupleField::PLint,  hostIds);
   int  *cpuLoads;
   replyTuple->read(3,TupleField::PLint,  cpuLoads);
   int  *mainMems;
   replyTuple->read(4,TupleField::PLint,  mainMems);
   int  *maxClients;
   replyTuple->read(5,TupleField::PLint, maxClients);
   int  *numClients;
   replyTuple->read(6,TupleField::PLint, numClients);
   int  *statuses;
   replyTuple->read(7,TupleField::PLint, statuses);


   assert((replyTuple->readLength(1)/PL_CHAR_SZ)/MONITOR_STRLEN == howMany);
   assert(replyTuple->readLength(2)/PL_INT_SZ == howMany);
   assert(replyTuple->readLength(3)/PL_INT_SZ == howMany);
   assert(replyTuple->readLength(4)/PL_INT_SZ == howMany);
   assert(replyTuple->readLength(5)/PL_INT_SZ == howMany);
   assert(replyTuple->readLength(6)/PL_INT_SZ == howMany);
   assert(replyTuple->readLength(7)/PL_INT_SZ == howMany);

   for(i=0; i< howMany; i++){
      HostType *hinfo = new HostType;
      ::strcpy(hinfo->name, &(hostNames[i * MONITOR_STRLEN]));
      hinfo->id = hostIds[i];
      hinfo->cpu_load = cpuLoads[i];
      hinfo->mem = mainMems[i];
      hinfo->num_clients = numClients[i];
      hinfo->max_clients = maxClients[i];
      ::strcpy(hinfo->status, status_name[statuses[i]]);
      g_hostlist.append(hinfo);
   }
   Tuple::destroy(replyTuple);
   replyTuple = NULL;
}
/*--------------------------------------------------------------------*/

void 
set_server_state(MonitorRequest req){
   assert(replyTuple == NULL);
   request.init();
   request.monitorMsgType((MonitorRequest)req);
   request.transientId(my_transient_id);

   if(communicate() == -1) {
      server_failure = 1;
      return; 
   }

   if(!reply.status()) {
      cerr << "error: request failed.\n" << flush;
   } 
}

/*-------------------------------------------------------------------------*/

void 
get_monitor_info(){
   int i;
   extern ProcStatusList  g_pinfo_list;
   extern char *status_name[];
   int lineno, hid;
   const char *hname, *exec, *file;
   procid pid;  int st;
   
   assert(replyTuple == NULL);
   request.init();
   request.monitorMsgType((MonitorRequest)MONITOR_INFO);
   request.transientId(my_transient_id);





   if(communicate() == -1) {
      server_failure = 1;
      return; 
   }
   //cout << "\n--  ID  --   EXEC   --  HOST -- STATUS\n"; 

   ProcStatusType  *pinfo;

   for(i=0; i<g_pinfo_list.length(); i++){
      delete g_pinfo_list.remove_rear();
   }
   g_pinfo_list.clear();


   //Format
   // int HowManyProcesses
   // int *ids
   // char *execs One every MONITOR_STRLEN characters
   // char *hosts One every MONITOR_STRLEN characters
   // char *files One every MONITOR_STRLEN characters
   // int  *lineNums
   // int *statuses
   // Tuple is created in ProcessManager::monitor_info

   assert(replyTuple && replyTuple->valid());
   assert(replyTuple->numOfFields() == 7);

   int howMany;
   replyTuple->read(0,TupleField::PLint,howMany);
   int *ids;
   replyTuple->read(1,TupleField::PLint, ids);
   char *execsTemp;
   replyTuple->read(2,TupleField::PLchar,  execsTemp);
   char *hostsTemp;
   replyTuple->read(3,TupleField::PLchar, hostsTemp);
   char *filesTemp;
   replyTuple->read(4,TupleField::PLchar, filesTemp);
   int *lineNums;
   replyTuple->read(5,TupleField::PLint, lineNums);
   int *statuses;
   replyTuple->read(6,TupleField::PLint, statuses);

   assert(replyTuple->readLength(1)/PL_INT_SZ == howMany);
   assert((replyTuple->readLength(2)/PL_CHAR_SZ)/MONITOR_STRLEN == howMany);
   assert((replyTuple->readLength(3)/PL_CHAR_SZ)/MONITOR_STRLEN == howMany);
   assert((replyTuple->readLength(4)/PL_CHAR_SZ)/MONITOR_STRLEN == howMany);
   assert(replyTuple->readLength(5)/PL_INT_SZ == howMany);
   assert(replyTuple->readLength(6)/PL_INT_SZ == howMany);

   char *execs[howMany];
   char *hosts[howMany];
   char *files[howMany];

   for(i = 0 ; i < howMany ; i++) {
      execs[i] = execsTemp;
      hosts[i] = hostsTemp;
      files[i] = filesTemp;
      assert(execs[i][MONITOR_STRLEN-1] == '\0' && 
	     hosts[i][MONITOR_STRLEN-1] == '\0' &&
	     files[i][MONITOR_STRLEN-1] == '\0');
      execsTemp += MONITOR_STRLEN;
      hostsTemp += MONITOR_STRLEN;
      filesTemp += MONITOR_STRLEN;
   }


   for(i=0; i< howMany; i++){	  
      hname = hosts[i];
      hid = ids[i];
      exec = execs[i];
      file = files[i];
      lineno = lineNums[i];
      pid = ids[i];
      st = statuses[i];

      pinfo = new ProcStatusType;
      pinfo->pid = pid;
      ::strcpy(pinfo->status, status_name[st]);
      ::strcpy(pinfo->host, hname);
      pinfo->line = lineno;
      ::strcpy(pinfo->file, file);
      ::strcpy(pinfo->exec, exec);
      g_pinfo_list.append(pinfo);
      //::printf("  %-6d  %-10s   %-7s  (%s:%d) %s\n", 
      //pid, exec, hname, file,lineno,status_name[st]);
   }


   Tuple::destroy(replyTuple);
   replyTuple = NULL;
   request.init();
}


/*-------------------------------------------------------------------------*/
void 
del_host(const char* host_name){
   int host_present(const char* host);   
   if (host_present(host_name) == 0){
      cerr << "host : " << host_name << " has no daemon.\n" << flush;
      return;
   }
   request.init();
   request.monitorMsgType((MonitorRequest)DEL_HOST);
   request.transientId(my_transient_id);

//   request.hostName((char*)host_name);

   assert(requestTuple == 0);
   requestTuple = Tuple::create(1,strlen(host_name) + 1);
   requestTuple->setActual(0,TupleField::PLchar, (char*)host_name, 
		     strlen(host_name) + 1);

   request.tupleLength(requestTuple->length());
   if(communicate() == -1) {
      server_failure = 1;
      return; 
   }
   Tuple::destroy(requestTuple);
   requestTuple = NULL;
}

/*---------------------------------------------------------------*/


#ifdef linux
static const char *server_type= "linux";
#endif
#ifdef alpha
static const char *server_type ="alpha";
#endif
#ifdef solaris
static const char *server_type ="solaris";
#endif
#ifdef sunos
static const char *server_type ="sunos";
#endif
#ifdef irix
static const char *server_type ="irix";
#endif

#ifdef MIGRATION_TEST
void 
add_host(const char* host_name, unsigned short server_port, 
	 const char* server_host, const char *host_type,char *uname,
	 int busy_interval){
#else
void 
add_host(const char* host_name, unsigned short server_port, 
	 const char* server_host, const char *host_type,char *uname) {

#endif

   assert(replyTuple == NULL);
   request.init();
   request.monitorMsgType((MonitorRequest)ADD_HOST);
   request.transientId(my_transient_id);

   assert(requestTuple == NULL);
   assert(host_name);
   assert(host_type);

   char s[64];
   if(strcmp(uname, "__null__") == 0) {
     ::cuserid(s);
     uname = s;
     if(!uname) {
       cerr << "PLinda error: system command getlogin returning NULL\n" ;
       assert(uname);
     }
   }     
   requestTuple = Tuple::create(3,strlen(host_name) + strlen(host_type) + 
				strlen(uname) + 3);
   requestTuple->setActual(0, TupleField::PLchar, (char*)host_name, 
			   strlen(host_name) + 1);
   requestTuple->setActual(1, TupleField::PLchar, (char*)host_type, 
			   strlen(host_type) + 1);
   requestTuple->setActual(2, TupleField::PLchar, (char*)uname, 
			   strlen(uname) + 1);

   request.tupleLength(requestTuple->length());

   if(communicate() == -1) {
      server_failure = 1;
      return; 
   }
   Tuple::destroy(requestTuple);
   requestTuple = NULL;
   if(!reply.status()) {
      cout << "ERROR: " << (reply.status()).message() << endl << flush;
      return;
   }
   
   {
     procid daemon_id = reply.processId();
      
      char command[1000];
      extern const char *REMOTESH;

      if(! PLinda_Architectures::supported(host_type)) {
	 cout << "Sorry, " <<host_type << " is not supported, Sorry" << endl;
	 return;
      }
      server_port = htons(server_port);
      // put it in the correct type before sending it over!!
#ifndef MIGRATION_TEST
      ::sprintf(command, "%s %s -l %s plinda/bin/%s/plinda_daemon %d %d %s %s %s %s &",
		REMOTESH, host_name, uname, host_type, daemon_id, server_port, 
		server_host, xhost_name, host_type,server_type);
#else
      ::sprintf(command, "%s %s -l %s plinda/bin/%s/plinda_daemon %d %d %s %s %s %s %d &",
		REMOTESH, host_name, uname, host_type, daemon_id, server_port, 
		server_host, xhost_name, host_type,server_type,busy_interval);
#endif
      if(::system(command) != 0) {
	  cerr << "> **ERROR: failed to invoke a daemon on " << host_name 
	       << "\n" << flush;
	  del_host(host_name);
      } else {
      cerr << command << endl << flush;
      cerr << "> daemon is created on " << host_name << "\n";
      cerr.flush();
      }
   }
}

/*---------------------------------------------------------------*/
void 
set_server_config(int param, long value)
{

   assert(replyTuple == NULL);
   request.init();
   request.monitorMsgType((MonitorRequest)SET_CONFIG);
   request.transientId(my_transient_id);

   request.paramNum(param);
   request.paramValue(value);


   if(communicate() == -1) {
      server_failure = 1;
      return; 
   }
}
/*---------------------------------------------------------------*/
void 
kill_proc(long pid){

   assert(replyTuple == NULL);
   request.init();
   request.monitorMsgType((MonitorRequest)KILL_PROCESS);
   request.transientId(my_transient_id);

   request.processId(pid);

   if(communicate() == -1) {
      server_failure = 1;
      return; 
   }

}
/*---------------------------------------------------------------*/
void migrate_proc(long pid, const char* host_name){
   assert(replyTuple == NULL);
   request.init();
   request.monitorMsgType((MonitorRequest)MIGRATE_PROCESS);
   request.transientId(my_transient_id);

//   request.hostName((char*)host_name);

   assert(requestTuple == NULL);
   requestTuple = Tuple::create(1, strlen(host_name) + 1);
   requestTuple->setActual(0, TupleField::PLchar,(char*)host_name, 
			   strlen(host_name) + 1);

   request.tupleLength(requestTuple->length());

   request.processId(pid);
   if(communicate() == -1) {
      server_failure = 1;
      return; 
   }
   Tuple::destroy(requestTuple);
   requestTuple    = NULL;

}
/*---------------------------------------------------------------*/
void spawn_prog(const char* prog_name,const char* host_name){
   assert(replyTuple == NULL);
   request.init();
   request.monitorMsgType((MonitorRequest)SET_MAINPROGRAM);
   request.transientId(my_transient_id);

   assert(requestTuple == NULL);
   requestTuple = Tuple::create(2,strlen(prog_name) + strlen(host_name) + 2);
   requestTuple->setActual(0, TupleField::PLchar,(char*) prog_name, 
			   strlen(prog_name) + 1);
   requestTuple->setActual(1, TupleField::PLchar,(char*) host_name, 
			   strlen(host_name) + 1);

   request.tupleLength(requestTuple->length());

   if(communicate() == -1) {
      server_failure = 1;
      return; 
   }
   Tuple::destroy(requestTuple);
   requestTuple = NULL;
}
/*--------------------------------------------------------------------*/
void 
list_tuplegroups(){

   cerr << "Listing tuple groups is currently not supported\n";
   assert(0);
   // look at plinda2.0 code to see how to fix this

}
/*--------------------------------------------------------------------*/
void display_tuplegroup_list(){
   assert(0);
}
/*--------------------------------------------------------------------*/
void dump_group(const char* group_name){

   cerr << "dump_group not currently supported\n";
   (void)group_name; // keep compiler quiet
   assert(0);
   // look at plinda2.0 code to see how to fix this
}
/*--------------------------------------------------------------------*/	
void start_stepping_proc(procid pid){
   assert(replyTuple == NULL);
   request.init();
   request.monitorMsgType((MonitorRequest)SINGLE_STEP);
   request.transientId(my_transient_id);

   request.processId(pid);

   if(communicate() == -1) {
      server_failure = 1;
      return; 
   }

}
/*--------------------------------------------------------------------*/	
void end_stepping_proc(procid pid){
   assert(replyTuple == NULL);
   request.init();
   request.monitorMsgType((MonitorRequest)END_STEPPING);
   request.transientId(my_transient_id);

   request.processId(pid);

   if(communicate() == -1) {
      server_failure = 1;
      return; 
   }
}
/*--------------------------------------------------------------------*/	
//void step_proc(procid pid, int num_steps){
//  assert(0);
//}
/*--------------------------------------------------------------------*/	
void
create_daemons(){
}
/*--------------------------------------------------------------------*/	
int 
check_server(){
   assert(replyTuple == NULL);
   request.init();
   request.monitorMsgType((MonitorRequest)DUMMY_REQUEST);
   request.transientId(my_transient_id);

   if(communicate() == -1) {
      server_failure = 1;
      return 1; 
   } else {
      server_failure = 0;
   }
   return 1;
}

/*--------------------------------------------------------------------*/
void
get_traces(void){
   cerr << "get_traces not currently supported\n";
   assert(0);
   // look at plinda 2.0 code to see how to do this
}
/*--------------------------------------------------------------------*/
int
host_present(const char* host){
   extern HostList g_hostlist;

   for(Pix p = g_hostlist.first(); p != 0; g_hostlist.next(p)){
      HostType *h = g_hostlist(p);
      if (::strcmp(h->name, host) == 0){
	 return 1;
      }
   }
   return 0;
}

