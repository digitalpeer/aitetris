#include "MonitorClient.h"

HostList        g_hostlist; 
ProcStatusList  g_pinfo_list;

procid   my_pid = 2;
long     my_transient_id;
int      server_port_int;
int      connected_to_server = 0;
int      server_failure = 0;
int      app_started = 0;
char*    xhost_name = 0;

/*--------------------------------------------------------------*/
char* status_name[] = {
    "EVALED", 
    "DISPATCHED", 
    "RUNNING", 
    "SLEEPING",
    "READY", 
    "BLOCKED",
    "XABORTED", 
    "FAILED", 
    "FAIL_HANDLED",
    "ERROR_FOUND", 
    "COMPLETED" 
    };

