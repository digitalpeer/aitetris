
#include <assert.h>
#include <tcl.h>
#include <tk.h>
#include "MonitorClient.h"

void set_server_state(MonitorRequest req);
void signal_catcher(int sig);
int  check_server();
//void start_stepping_proc(procid pid);
//void end_stepping_proc(procid pid);
//void step_proc(procid pid, int num_steps);
void get_hostlist();
void get_monitor_info();
void add_host(const char* host_name, unsigned short server_port, const char* server_host, const char *host_type,char *uname);
void spawn_prog(const char* prog_name,const char* host);
void dump_group(const char* group_name);
void kill_proc(long pid);
void migrate_proc(long pid, const char* host_name);
void del_host(const char* host_name);
void list_tuplegroups();
void get_traces(void);

#define TCL_CALL(expr) \
  {if (expr != TCL_OK) return TCL_ERROR;}

#define CHECK_ARGS(n) \
  if (argc-1 != n) { \
    Tcl_AppendResult(interp, "wrong # args: ", argv[0], NULL); \
    return TCL_ERROR; \
  }
 
#define CHECK_ARGS2(low, high) \
  if (argc-1 < low || argc-1 > high) { \
    Tcl_AppendResult(interp, "wrong # args: ", argv[0], NULL); \
    return TCL_ERROR; \
  }
    
#define PUTD(x) \
   printf(" > %d \n", x); \
   fflush(stdout);

#define PUTS(x) \
   printf(" > %s \n", x); \
   fflush(stdout);


// the call functions in Tcl/tk should have the following format :
#define TCL_SIG (ClientData cd, Tcl_Interp *interp, int argc, char *argv[])




int PLinda_Init(Tcl_Interp* interp);

int server_state_cmd TCL_SIG;
int add_host_cmd TCL_SIG;
int del_host_cmd TCL_SIG;
int kill_process_cmd TCL_SIG;
int migrate_process_cmd TCL_SIG;
int list_groups_cmd TCL_SIG;
int dump_group_cmd TCL_SIG;
int single_step_cmd TCL_SIG;
int end_step_cmd TCL_SIG;
int next_step_cmd TCL_SIG;
int main_process_cmd TCL_SIG;
int create_daemons_cmd TCL_SIG;
int host_list_cmd TCL_SIG;
int monitor_info_cmd TCL_SIG;
int spawn_server_cmd TCL_SIG;
int current_state_cmd TCL_SIG;
int open_conn_cmd TCL_SIG;
int close_conn_cmd TCL_SIG;
int cleanup_cmd TCL_SIG;
int set_config_cmd TCL_SIG;
int get_traces_cmd TCL_SIG;
int check_server_cmd TCL_SIG;
int process_info_cmd TCL_SIG;

int conn_file_present(char* f);

