
#ifndef _MonitorProcess_H_
#define _MonitorProcess_H_

// communication/timing library..
#include "Reactor.h"

// PLinda header files & forward declarations
#include "plinda_ids.h"
#include "ErrorType.h"
#include "MonitorRequest.h"
#include "Process.h"
#include "TupleHandle.h"
#include "Header.h"


class MonitorProcess;
class ServerCommLink;
class Transaction;

// GNU
#include "GNU_Interface.h"



class MonitorProcess : public Process {

  public:	

    struct Statistics {
	long  num_msgs;
	long  num_trans;
	long  max_ts_used;
	long  num_chkpts;
	long  max_chkpt_time;
    };

    enum StatisticsType { NUM_MESSAGES, NUM_TRANSNS, MAX_TS_USED,
			  NUM_CHKPTS, MAX_CHKPT_TIME};

    MonitorProcess(const char* host=0);
    ~MonitorProcess();

    const char* host_name(void) const;
    void host_name(const char* host);

    /* ---------------------------------------------------
       communication stuff ... 
       ------------------------------------------------ */
    virtual void enqueue_request(Header*,Tuple*);

    HeaderAndTuple current_request() { return x_cur_request; }
    void current_request(Header *h,Tuple *t) {
       assert(x_cur_request.header == NULL);
       x_cur_request.header = h;
       x_cur_request.tuple = t;
    }
    void destroy_current_request();


    /* --------------------------------------------------
       Threads
       ------------------------------------------------*/
    virtual int block(int, TupleGroup*, Pix){
       assert(0);
       return 1; }
    virtual int resume(const TupleGroup*, const TupleHandle&, 
		       Tuple*) {
       assert(0); return 1; }


    /* -------------------------------------------------
       Forced Termination
       ------------------------------------------------- */
    void kill(void);
 

    /* ------------------------------------------------------
       "handle_request" is the one which handles all requests
       from the monitor_client (which the user sends).
       --------------------------------------------------- */
    virtual int ready(void);
    virtual int handle_request(void);


    /* -------------------------------------------------------
       monitor mode :should the UI be updated with every event
       or periodically or only upon demand?
       ----------------------------------------------------- */
    void  set_update_interval(long);
    virtual int handle_timeout(const Time_Value&, const void*);
    int update_flag(void) const;

    /* ------------------------------------------------------
       break points ... 
       ----------------------------------------------------- 
    int  check_for_breakpt(Tuple*,int line_no,
			   const char* file, gid);
    int  set_breakpt(Tuple*,int line_no =0,
		     const char* file ="", gid g = zero_gid);
    void  del_breakpoint(int breakpt_no);
    */

    /* ------------------------------------------------------------
       statistics related to the current run ...
       ----------------------------------------------------------- */
    void  update_statistics(StatisticsType){}; 
    void  init_statistics(void){}

    /* ----------------------------------------------------------
       Reply to Requests 
       ------------------------------------------------------- */
    int send_reply(Header &,Tuple * = NULL);
//    MonitorMessage* make_reply(MonitorRequest, int);


    /* ----------------------------------------------------------
       error checking 
       ------------------------------------------------------- */
    ErrorType check_for_errors(const Header *, const Tuple *);
    void declare_failure(void) ;
    void handle_failure(void);
    int check_failure(void) ;
    // if there is a program error in a process, ;
    // then we just remove the process instead of restarting it. ;
    virtual void declare_error(ErrorType){};
    int alive(void) const;


  private:
    
    struct Statistics  x_statistics;

    HeaderAndTuple    x_cur_request;
    

    /*------------------------------------------------*/
    /* a breakpoint is <IO_pattern ,line#,file> ...   */
    /*------------------------------------------------*/
    //BreakPointList     x_breakpt_list;
    //int                x_num_breakpts;

    /*------------------------------------------------*/
    /* for updating the UI ... with the server status */
    /*------------------------------------------------*/
    int                x_update_flag;
    Time_Value         x_update_timeout;

    Tuple* statistics_pattern();

    //---------------------------------------------------
    // host of the monitor
    //---------------------------------------------------
    char*      x_host_name;

};


#ifndef _OUTLINE_
#include "MonitorProcess.iC"
#endif // _OUTLINE_


#endif  // _MonitorProcess_H_
 
