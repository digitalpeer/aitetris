/* -*- C++ -*- */
/* Defines the member functions for the base class of the SOCK
   abstraction. */  

#if !defined (ACE_SOCK_H)
#define ACE_SOCK_H

#include "Addr.h"
#include "IPC_SAP.h"

class SOCK : public IPC_SAP
{
public:
  int open (int type, int protocol_family, int protocol);
  int close (void);
  int  set_option (int level, int option, void *optval, int optlen) const;
  int  get_option (int level, int option, void *optval, int &optlen) const;

  int get_local_addr (Addr &) const;

protected:
  SOCK (void);
  SOCK (int type, int protocol_family, int protocol = 0);
};

#ifndef _OUTLINE_
#define INLINE inline
#include "SOCK.iC"
#else
#define INLINE
#endif 


#endif /* _SOCK_H */
