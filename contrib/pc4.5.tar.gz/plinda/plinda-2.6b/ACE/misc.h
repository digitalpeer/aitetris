/* Miscellaneous functions for the SOCK abstraction */

extern int bind_port (int);
