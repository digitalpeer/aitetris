/* -*- C++ -*- */
/* Wait on multiple file descriptors until a condition occurs. */

#if !defined (ACE_Reactor_H)
#define ACE_Reactor_H
#include <stream.h>

#include "Event_Handler.h"
#include "Timer_Queue.h"
#include "sysincludes.h"

class Reactor
{
public:
  enum {DEFAULT_SIZE = 256};
  Reactor (void);
  ~Reactor (void);

  int        register_handler (const Event_Handler *);
  int        remove_handler (const Event_Handler *);
  int        schedule_timer (const Event_Handler *, const void *arg,
			     const Time_Value &delta,
			     const Time_Value &interval = Timer_Queue::zero);
  int        cancel_timer (const Event_Handler *);
  
  int        handle_events (Time_Value &tv);

  int	     unblock (void);
  int	     open (int size = DEFAULT_SIZE, int restart = 0);
  void	     close (void);
  static int verify_ready(int fd)  ;
private:
  int        register_handler (int fd, const Event_Handler *);
  int        attach (int fd, const Event_Handler *);
  int        detach (int fd);
  int        handle_events (Time_Value *);
  int        any_ready (void) const;
  Time_Value *calculate_timeout (Time_Value *) const;
  int        handle_error (void);
  int        check_connections (void);
  
  int        wait_for (fd_set &, Time_Value *);
  void       dispatch (int, const fd_set&);
  class Null_Callback : public Event_Handler
  {
    public:
       int handle_input (int fd);
  } null_callback;
    
  int          pipe_fds[2]; /* Used to unblock reactor when changes are made dynamically */
  int	       is_blocked;
  int          restart; /* Restart automatically when interrupted */
  Timer_Queue  *timer_queue; /* Defined as a pointer to allow overriding by derived classes... */
  int          max_size;
  int          max_fdp1;
  const Event_Handler **event_handlers;
  fd_set       readfd_mask;
  Reactor (const Reactor &);
  Reactor &operator = (const Reactor &);
};

#ifndef _OUTLINE_
#include "Reactor.iC"
#else
#define INLINE
#endif 

#endif /* _Reactor_H */


