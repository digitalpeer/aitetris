#include "Event_Handler.h"

#ifdef _OUTLINE_
#include "Event_Handler.iC"
#endif



/* Called when input becomes available on fd. */

int 
Event_Handler::handle_input (int)
{
  return -1;
}


/* Returns the file descriptor associated with this I/O device. */

int
Event_Handler::get_fd (void) const
{
  return -1;
}


/* Called when timer expires, TV stores the current time. */

int
Event_Handler::handle_timeout (const Time_Value &, const void *)
{
  return -1;
}






