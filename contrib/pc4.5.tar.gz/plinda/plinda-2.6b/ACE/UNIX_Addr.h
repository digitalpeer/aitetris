/* -*- C++ -*- */
/* Defines the ``UNIX domain address family'' address format. */

#if !defined (ACE_UNIX_ADDR_H)
#define ACE_UNIX_ADDR_H
#include "Addr.h"

class UNIX_Addr : public Addr
{
public:
  UNIX_Addr (void);
  UNIX_Addr (const UNIX_Addr &sa);
  UNIX_Addr (const char rendezvous_point[]);

  void set (const char rendezvous_point[]);

  virtual void *get_addr (void) const;
  virtual int  operator == (const Addr &SAP) const;
  virtual int  operator != (const Addr &SAP) const;

  const char *get_path_name (void) const; 

private:
  sockaddr_un unix_addr;
};

#ifndef _OUTLINE_
#define INLINE inline
#include "UNIX_Addr.iC"
#else
#define INLINE 
#endif 

#endif /* _UNIX_ADDR_H */
