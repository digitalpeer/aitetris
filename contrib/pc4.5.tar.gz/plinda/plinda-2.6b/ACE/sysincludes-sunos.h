#ifndef _sysincludes_h_
#define _sysincludes_h_ 1

#include <sys/param.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <stdio.h>
#include <errno.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <sys/un.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>  

extern "C" {
  int gethostname(char*, int);
  struct hostent *gethostbyname(char *);
  struct servent *getservbyname (char *,char *);
  struct hostent *gethostbyaddr (char *,int ,int) ;
  void bzero(char*, int);
  int connect(int, const struct sockaddr*, int);
  int bind(int s, const struct sockaddr*, int);
  int setsockopt(int,int, int,char*,int);
  int ioctl (int, int, char*);
  int gettimeofday(struct timeval*, struct timezone*);
  int setrlimit(int, struct rlimit*);
  int getrlimit(int, struct rlimit*);
  int select (int, fd_set *, fd_set *, fd_set *, struct timeval *);
  int shutdown(int, int);
  int getpeername(int, struct sockaddr*, int*);
  int accept(int, struct sockaddr*, int*);
  int send (int, const char*, int, int);
  int listen(int, int);
  int socket(int, int, int);
  int readv (int, struct iovec *, int);
  int writev (int, struct iovec *, int);
  int recv(int, char*, int, int);
  int getsockopt(int,int,int,char*,int*);
  int getsockname(int, struct sockaddr*, int *namelen);
}
#ifndef O_NONBLOCK
#define O_NONBLOCK 0x4000
#endif /* O_NONBLOCK */

int set_fl (int fd, int flags);
int clr_fl (int fd, int flags);
int raise_file_limit (int new_limit = -1);

inline int  BIT_ENABLED (unsigned long word, int bit = 1) { return (word & bit) != 0; }
inline int  BIT_DISABLED (unsigned long word, int bit = 1) { return (word & bit) == 0; }
inline void SET_BIT (unsigned long &word, int bit) { word |= bit; }
inline void CLR_BIT (unsigned long &word, int bit) { word &= ~bit; }

#endif



