/* -*- C++ -*- */
/* Interface to timers. */

#if !defined (ACE_TIMER_QUEUE_H)
#define ACE_TIMER_QUEUE_H

#include "Event_Handler.h"
#include "Time_Value.h"
#if defined (MT_SAFE)
#include "Synch.h"
#endif /* MT_SAFE */

/* Note, this should be a nested class, but some compilers don't like these yet... */

struct Timer_Node
{
friend class Timer_Queue;
private:
  Timer_Node (const Event_Handler *h, const void *a, const Time_Value &t, const Time_Value &i, Timer_Node *n);

  const Event_Handler *handler;
  const void          *arg;
  Time_Value	      timer_value;
  Time_Value	      interval;
  Timer_Node	      *next;
};

class Timer_Queue
{
public: 
  static const Time_Value zero;

public:
  Timer_Queue (void);
  ~Timer_Queue (void);

  int 			  is_empty (void) const;
  const Time_Value        &earliest_time (void) const;
  static const Time_Value &current_time (void);

  int schedule (const Event_Handler *, const void *a, const Time_Value &, const Time_Value & = Timer_Queue::zero);
  int cancel (const Event_Handler *);
  int expire (const Time_Value &);

private:
  void reschedule (Timer_Node *);

  Timer_Node *head; /* Pointer to linked list of Timer_Nodes. */


#if defined (MT_SAFE)
  Mutex_Rec<Mutex> lock; /* Synchronization variable for the MT_SAFE Reactor */
#endif /* MT_SAFE */
};

#ifndef _OUTLINE_
#define INLINE inline
#include "Timer_Queue.iC"
#else
#define INLINE
#endif

#endif /* _TIMER_QUEUE_H */
