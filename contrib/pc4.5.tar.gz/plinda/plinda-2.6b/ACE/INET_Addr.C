/* Defines the Internet domain address family address format. */

#include "INET_Addr.h"

#ifdef _OUTLINE_
#include "INET_Addr.iC"
#endif 



void *
INET_Addr::get_addr (void) const
{
  return (void *) &this->inet_addr;
}

/* Compare two addresses for equality. */

int
INET_Addr::operator == (const Addr &sap) const
{
  return ::memcmp ((void *) &this->inet_addr.sin_addr, 
		   (void *) &((INET_Addr &) sap).inet_addr.sin_addr, 
		   sizeof (this->inet_addr.sin_addr)) == 0;
}

/* Compare two addresses for inequality. */

int
INET_Addr::operator != (const Addr &sap) const
{
  return !((*this) == sap);	/* This is lazy, of course... ;-) */
}
