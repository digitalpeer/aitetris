#ifndef _sysincludes_alpha_
#define _sysincludes_alpha_ 1

#include <sys/param.h>
#include <sys/time.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/ioctl.h>

extern "C" {
  int gethostname(char*, int);
}

#include <sys/resource.h>
#include <memory.h>
#include <sys/socket.h>
#include <stdio.h>
#include <errno.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <sys/un.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>  

// message queues & shared memory
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/sem.h>
#include <sys/shm.h>

#endif // _sysincludes_alpha_


