#ifndef _sysincludes_h_
#define _sysincludes_h_ 1

#include <sys/param.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <stdio.h>
#include <errno.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <sys/un.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>  


extern "C" {
  int gethostname(char*, int);
  void bzero(char*, int);
}


#ifndef O_NONBLOCK
#define O_NONBLOCK 0x4000
#endif /* O_NONBLOCK */

int set_fl (int fd, int flags);
int clr_fl (int fd, int flags);
int raise_file_limit (int new_limit = -1);

inline int  BIT_ENABLED (unsigned long word, int bit = 1) { return (word & bit) != 0; }
inline int  BIT_DISABLED (unsigned long word, int bit = 1) { return (word & bit) == 0; }
inline void SET_BIT (unsigned long &word, int bit) { word |= bit; }
inline void CLR_BIT (unsigned long &word, int bit) { word &= ~bit; }

int (*signal(int sig, int (*func)(int, ...)))(int, ...);

#endif



