/* -*- C++ -*- */
/* Operations on timeval structures. */

#if !defined (ACE_TIME_VALUE_H)
#define ACE_TIME_VALUE_H

#include "sysincludes.h"
#ifndef _OUTLINE_
#define INLINE inline
#else
#define INLINE
#endif
class Time_Value
{
public:
  INLINE Time_Value (long sec = 0, long usec = 0);
  INLINE Time_Value (const timeval &t);
  INLINE Time_Value (const Time_Value &tv);

  INLINE void set (const timeval &t);
  INLINE long get_sec (void) const;
  INLINE void set_sec (long sec);
  INLINE long get_usec (void) const;
  INLINE void set_usec (long usec);
  INLINE operator timeval () const;

  INLINE friend Time_Value operator + (Time_Value tv1, Time_Value tv2);
  INLINE friend Time_Value operator - (Time_Value tv1, Time_Value tv2);
  INLINE friend int	    operator < (Time_Value tv1, Time_Value tv2);
  INLINE friend int	    operator > (Time_Value tv1, Time_Value tv2);  
  INLINE friend int	    operator <= (Time_Value tv1, Time_Value tv2);
  INLINE friend int	    operator >= (Time_Value tv1, Time_Value tv2);  
  INLINE friend int	    operator == (Time_Value tv1, Time_Value tv2);  
  INLINE friend int	    operator != (Time_Value tv1, Time_Value tv2);  

private:
  INLINE static void normalize_pos (Time_Value &num);
  INLINE static void normalize_neg (Time_Value &num);
  long tv_sec;
  long tv_usec;
};

#ifndef _OUTLINE_
#define INLINE inline
#include "Time_Value.iC"
#else
#define INLINE
#endif 
#endif /* TIME_VALUE */
