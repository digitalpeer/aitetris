/* Defines the ``UNIX domain address family'' address format. */

#include "UNIX_Addr.h"

#ifdef _OUTLINE_
#include "UNIX_Addr.iC"
#endif




/* Return the address. */

void *
UNIX_Addr::get_addr (void) const
{
  return (void *) &this->unix_addr;
}

/* Compare two addresses for equality. */

int
UNIX_Addr::operator == (const Addr &sap) const
{
  return ::strcmp (this->unix_addr.sun_path, 
		   ((const UNIX_Addr &) sap).unix_addr.sun_path) == 0;
}

/* Compare two addresses for inequality. */

int
UNIX_Addr::operator != (const Addr &sap) const
{
  return !((*this) == sap);	/* This is lazy, of course... ;-) */
}
