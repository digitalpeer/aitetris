/* -*- C++ -*- */
/* Derived classes read input on a file number, write output on a file
   number, handle an exception raised on a file number, or handle a
   timer's expiration. */

#if !defined (ACE_EVENT_HANDLER_H)
#define ACE_EVENT_HANDLER_H

#include "Time_Value.h"

class Event_Handler 
{
public:
  virtual ~Event_Handler (void) { };
  virtual int  get_fd (void) const;
  virtual int  handle_input (int fd);
  int  handle_output (int ) { return -1; }
  int  handle_exception (int ) { return -1; }
  int  handle_signal (int signum);
  virtual int  handle_timeout (const Time_Value &tv, const void *arg = 0);
  int  handle_close (int  ) { return -1; }
protected:
  Event_Handler (void);
};

#ifndef _OUTLINE_
#define INLINE inline
#include "Event_Handler.iC"
#else
#define INLINE
#endif

#endif /* EVENT_HANDLER_H */





