/* -*- ++ -*- */
/* Defines the member functions for connection-oriented SOCK 
   abstractions. */

#if !defined (ACE_SOCK_CONNECT_H)
#define ACE_SOCK_CONNECT_H

#include "SOCK.h"

class SOCK_Connect : public SOCK
{
public:
  int get_remote_addr (Addr &) const;

  int send (const void *buf, int n, int flags = 0) const;
  int recv (void *buf, int n, int flags = 0) const;
  int send (const iovec iov[], int n) const;
  int recv (iovec iov[], int n) const;
#if 0
  int send (int n, ...);
  int recv (int n, ...);
#endif
protected:
  SOCK_Connect (void);
  SOCK_Connect (int type, int protocol_family, int protocol = 0);
};

#ifndef _OUTLINE_
#define INLINE inline
#include "SOCK_Connect.iC"
#else
#define INLINE
#endif



#endif /* _SOCK_CONNECT_H */
