
#if defined(solaris)
#include "sysincludes-solaris.h"
#endif

#if defined(alpha)
#include "sysincludes-alpha.h"
#endif

#if defined(hpux)
#include "sysincludes-hpux.h"
#endif

#if defined(sunos)
#include "sysincludes-sunos.h"
#endif

#if defined(irix)
#include "sysincludes-irix.h"
#endif

#if defined(linux)
#include "sysincludes-linux.h"
#endif
