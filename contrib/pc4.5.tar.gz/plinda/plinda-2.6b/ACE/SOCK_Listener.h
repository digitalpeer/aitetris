/* -*- C++ -*- */
/* Defines the format and interface for an SOCK Stream listener. */

#if !defined (ACE_SOCK_LISTENER_H)
#define ACE_SOCK_LISTENER_H


#include "SOCK.h"
#include "SOCK_Stream.h"

class SOCK_Listener : public SOCK
{
public:
  SOCK_Listener (void);
  SOCK_Listener (const Addr &local_sap, int reuse_addr = 0, int micro_sec_delay = -1, int protocol_family = PF_INET, int backlog = 5, int protocol = 0);
  
  int open (const Addr &local_sap, int reuse_addr = 0, int micro_sec_delay = -1, int protocol_family = PF_INET, int backlog = 5, int protocol = 0);
  
  int accept (SOCK_Stream &new_ipc_sap, Addr *remote_addr = 0, int restart = 1) const;
  int operator () (SOCK_Stream &new_ipc_sap, Addr *remote_addr = 0, int restart = 1) const;

protected:
  int micro_second_delay;	/* Number of micro seconds to wait for arriving connection requests. -1 means block forever, 0 means poll. */
  
protected:
  int shared_open (const Addr &local_sap, int reuse_addr, int backlog);
  int shared_accept (Addr *remote_addr, int restart) const;
  int handle_timed_wait (int restart) const;
};


#ifndef _OUTLINE_
#define INLINE inline
#include "SOCK_Listener.iC"
#else
#define INLINE
#endif



#endif /* _SOCK_LISTENER_H */
