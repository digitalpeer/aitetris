/* Defines the member functions for connection-oriented SOCK 
   abstractions. */

#include "SOCK_Connect.h"

#ifdef _OUTLINE_
#include "SOCK_Connect.iC"
#endif
#if 0
/* Send N char *ptrs and int lengths.  Note that the char *'s 
   precede the ints (basically, an varargs version of writev). 
   The count N is the *total* number of trailing arguments, 
   *not* a couple of the number of tuple pairs! */

int
SOCK_Connect::send (int n, ...)
{

  va_list argp;  
  int	  total_tuples = n / 2;
  int	  result;
#if defined (__GNUG__) 
  iovec   iovp[total_tuples];
#elif defined (_HAVE_ALLOCA)
  iovec   *iovp = (iovec *) alloca (total_tuples);
#else
  iovec	  *iovp = new iovec[total_tuples];
#endif /* !defined (__GNUG__) && !defined (_HAVE_ALLOCA) */

  va_start (argp, n);

  for (int i = 0; i < total_tuples; i++)
    {
      iovp[i].iov_base = va_arg (argp, char *);
      iovp[i].iov_len  = va_arg (argp, int);
    }

  result = ::writev (this->get_fd (), (struct iovec*)iovp, total_tuples);
#if !defined (__GNUG__) && !defined (_HAVE_ALLOCA)
  delete iovp;
#endif /* !defined (__GNUG__) && !defined (_HAVE_ALLOCA) */
  va_end (argp);
  return result;
}

/* This is basically an interface to ::readv, that doesn't
   use the struct iovec explicitly.  The ... can be passed
   as an arbitrary number of (char *ptr, int len) tuples.
   However, the count N is the *total* number of trailing
   arguments, *not* a couple of the number of tuple pairs! */

int
SOCK_Connect::recv (int n, ...)
{

  va_list argp;  
  int	  total_tuples = n / 2;
  int	  result;
#if defined (__GNUG__) 
  iovec   iovp[total_tuples];
#elif defined (_HAVE_ALLOCA)
  iovec   *iovp = (iovec *) alloca (total_tuples);
#else
  iovec	  *iovp = new iovec[total_tuples];
#endif /* !defined (__GNUG__) && !defined (_HAVE_ALLOCA) */

  va_start (argp, n);

  for (int i = 0; i < total_tuples; i++)
    {
      iovp[i].iov_base = va_arg (argp, char *);
      iovp[i].iov_len  = va_arg (argp, int);
    }

  result = ::readv (this->get_fd (), iovp, total_tuples);
#if !defined (__GNUG__) && !defined (_HAVE_ALLOCA)
  delete iovp;
#endif /* !defined (__GNUG__) && !defined (_HAVE_ALLOCA) */
  va_end (argp);
  return result;
}

#endif
