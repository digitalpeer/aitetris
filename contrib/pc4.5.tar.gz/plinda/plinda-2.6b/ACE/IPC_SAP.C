/* Defines the member functions for the base class of the IPC_SAP
   abstraction. */ 

#include "IPC_SAP.h"


#ifdef _OUTLINE_
#include "IPC_SAP.iC"
#endif 

/* Make the IPC_SAPet available for asynchronous I/O (SIGIO),
   urgent data (SIGURG), or non-blocking I/O (O_NONBLOCK). */

int
IPC_SAP::enable (int signum) const
{
  static int pid = 0;

  /* First-time in initialization. */
  if (pid == 0)
    pid = int (::getpid ());

  switch (signum)
    {
    case SIGURG:
#ifdef F_SETOWN
      if (::fcntl (this->s_fd, F_SETOWN, pid) < 0)
#else
#ifdef __GNU__
 # warning not setting up for F_SETOWN signalyour system does not have it.     
#endif
#endif

	return -1;
      break;
    case SIGIO:
#ifdef F_SETOWN
      if (::fcntl (this->s_fd, F_SETOWN, pid) == -1)
#else
#ifdef __GNU__
 # warning not setting up for F_SETOWN signal your system does not have it.     
#endif
#endif
	return -1;
#ifdef FASYNC
      if (set_fl (this->s_fd, FASYNC) == -1)
#else
#ifdef __GNU__
 # warning not setting up for F_ASYNC signal your system does not have it.     
#endif
#endif
	return -1;
      break;
#ifndef linux
    case O_NONBLOCK:
#endif
    case O_NDELAY:
#if defined (solaris)
      if (set_fl (this->s_fd, O_NONBLOCK) == -1)
#else
      if (set_fl (this->s_fd, O_NDELAY) == -1)
#endif /* solaris */
	return -1;
      break;
    default:
      return -1;
    }
  return 0;
}

/* Restore the IPC_SAPet by turning off synchronous I/O or urgent delivery. */

int
IPC_SAP::disable (int signum) const
{
  switch (signum)
    {
    case SIGURG:
#ifdef F_SETOWN
      if (::fcntl (this->s_fd, F_SETOWN, 0) == -1)
#else
#ifdef __GNU__
 # warning not setting up for F_SETOWN signal your system does not have it.     
#endif
#endif
	return -1;
      break;
    case SIGIO:
#ifdef F_SETOWN
      if (::fcntl (this->s_fd, F_SETOWN, 0) == -1)
	return -1;
#else
#ifdef __GNU__
 # warning not setting up for F_SETOWN signal your system does not have it.     
#endif
#endif
#ifdef FASYNC
      if (clr_fl (this->s_fd, FASYNC) == -1)
#else
#ifdef __GNU__
 # warning not setting up for F_ASYNC signal your system does not have it.     
#endif
#endif
	return -1;
      break;
#ifndef linux
    case O_NONBLOCK:
#endif
    case O_NDELAY:
#if defined (solaris)
      if (clr_fl (this->s_fd, O_NONBLOCK) == -1)
	return -1;
#else
      if (clr_fl (this->s_fd, O_NDELAY) == -1)
	return -1;
#endif /* solaris */
      break;
    default:
      return -1;
    }
  return 0;
}






