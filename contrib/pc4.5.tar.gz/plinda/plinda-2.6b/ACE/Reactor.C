
/* Reactor provides an interface to the select() or poll() system call. */

#include "Reactor.h"

#ifdef _OUTLINE_
#include "Reactor.iC"
#endif

