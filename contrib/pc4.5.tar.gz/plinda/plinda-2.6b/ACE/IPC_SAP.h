/* -*- C++ -*- */
/* Defines the member functions for the base class of the IPC_SAP
   abstraction. */  

#if !defined (ACE_IPC_SAP_H)
#define ACE_IPC_SAP_H

#include "sysincludes.h"

class IPC_SAP
{
public:
  IPC_SAP (void);

  int  control (int cmd, void *) const;
  int  enable (int signum) const;
  int  disable (int signum) const;

  int  get_fd (void) const;
  void set_fd (int fd);

private:
  int s_fd;
};

#ifndef _OUTLINE_
#define INLINE inline
#include "IPC_SAP.iC"
#else
#define INLINE
#endif 

#endif /* _IPC_SAP_H */
