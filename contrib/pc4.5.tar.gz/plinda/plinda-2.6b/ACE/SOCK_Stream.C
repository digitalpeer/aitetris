/* Defines the member functions for the SOCK Stream abstraction. */

#include "SOCK_Stream.h"

#ifdef _OUTLINE_
#include "SOCK_Stream.iC"
#endif 

/* This constructor is used by a client when it wants to connect to the 
   specified REMOTE_SAP address. */

SOCK_Stream::SOCK_Stream (const Addr &remote_sap, int protocol_family, int protocol)
			       : SOCK_Connect (SOCK_STREAM, protocol_family, protocol)
{
  if (::connect (this->get_fd (), (sockaddr *) remote_sap.get_addr (), remote_sap.get_size ()) == -1)
    {
      this->set_fd (-1);
      perror ("connect");
    }
}

int
SOCK_Stream::open (const Addr &remote_sap, int protocol_family, int protocol)
{
  this->set_fd (SOCK_Connect::open (SOCK_STREAM, protocol_family, protocol));
  if (this->get_fd () < 0)
    return -1;
  else if (::connect (this->get_fd (), (sockaddr *) remote_sap.get_addr (), remote_sap.get_size ()) == -1)
    {
      this->set_fd (-1);
      return -1;
    }
  return this->get_fd ();
}

