/* -*- C++ -*- */
/* Defines the ``address family independent'' address format. */

#if !defined (ACE_ADDR_H)
#define ACE_ADDR_H

#include "sysincludes.h"

class Addr 
{
public:
  Addr (void);
  Addr (int type, int size);

  void set (int type, int size);

  int	  get_size (void) const;
  void	  set_size (int size);
  int	  get_type (void) const;
  void	  set_type (int type);
  virtual void *get_addr (void) const;
  virtual int operator == (const Addr &sap) const;
  virtual int operator != (const Addr &sap) const;

protected:
  int addr_type; /* e.g. AF_UNIX or AF_INET. */
  int addr_size; 
};

extern const Addr sap_any;


#ifndef _OUTLINE_
#define INLINE inline
#include "Addr.iC"
#else
#define INLINE 
#endif 

#endif /* _ADDR_H */


