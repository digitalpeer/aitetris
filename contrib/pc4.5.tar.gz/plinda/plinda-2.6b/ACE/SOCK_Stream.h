/* -*- C++ -*- */
/* Defines the member functions for the SOCK Stream abstraction. */

#if !defined (ACE_SOCK_STREAM_H)
#define ACE_SOCK_STREAM_H

#include "SOCK_Connect.h"
#include "Addr.h"
#include <assert.h>

class SOCK_Stream : public SOCK_Connect
{
friend class SOCK_Listener;
public:
  SOCK_Stream (void);
  SOCK_Stream (const Addr &remote_sap, int protcol_family = PF_INET, int protocol = 0);

  int open (const Addr &remote_sap, int protcol_family = PF_INET, int protocol = 0);

  int  close_reader (void);
  int  close_writer (void);

  int  send_n (const void *buf, int n, int flags = 0) const; /* Send n bytes, keep trying until n are sent. */
  int  recv_n (void *buf, int n, int flags = 0) const;	      /* Recv n bytes, keep trying until n are received. */
  int  send_urg (void *ptr, int len = sizeof (char));
  int  recv_urg (void *ptr, int len = sizeof (char));
};

#ifndef _OUTLINE_
#define INLINE inline
#include "SOCK_Stream.iC"
#else
#define INLINE
#endif


#endif /* _SOCK_STREAM_H */
