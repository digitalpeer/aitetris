/* Defines the member functions for the base class of the SOCK
   abstraction. */ 

#include "SOCK.h"

#ifdef _OUTLINE_
#include "SOCK.iC"
#endif 

int
SOCK::open (int type, int protocol_family, int protocol)
{
  this->set_fd (::socket (protocol_family, type, protocol));
  return this->get_fd ();
}

/* Close down a SOCK. */

int
SOCK::close (void)
{
  int result = ::close (this->get_fd ());
  this->set_fd (-1);
  return result;
}

/* General purpose constructor for performing server SOCK creation. */

SOCK::SOCK (int type, int protocol_family, int protocol)
{
  this->set_fd (this->open (type, protocol_family, protocol));

  if (this->get_fd () == -1)
    ::perror ("SOCK::SOCK");
}
