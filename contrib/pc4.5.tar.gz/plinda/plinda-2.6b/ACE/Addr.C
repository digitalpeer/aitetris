/* Defines the ``address family independent'' address format. */

#include "Addr.h"

/* This is a global variable. */
const Addr sap_any;

#ifdef _OUTLINE_
#include "Addr.iC"
#endif 




/* Return the address of the address. */
void *
Addr::get_addr (void) const
{
  return 0;
}

int 
Addr::operator == (const Addr &sap) const
{
  return sap.addr_type == 0;
}

int
Addr::operator != (const Addr &sap) const
{
  return sap.addr_type != 0;
}
