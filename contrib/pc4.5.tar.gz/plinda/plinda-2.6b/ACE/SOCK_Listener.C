/* Defines the member functions for the listener
   portion of the SOCK Stream abstraction. */

#include "SOCK_Listener.h"

#ifdef _OUTLINE_
#include "SOCK_Listener.iC"
#endif 

/* Code shared by constructor and open. */

int
SOCK_Listener::shared_open (const Addr &local_sap, int reuse_addr, int backlog)
{
  int one = 1;

  if (reuse_addr && this->set_option (SOL_SOCKET, SO_REUSEADDR, &one, sizeof one) == -1)
    this->close ();      
  else if (::bind (this->get_fd (), (sockaddr *) local_sap.get_addr (), local_sap.get_size ()) == -1
      || ::listen (this->get_fd (), backlog) == -1)
    this->close ();
  return this->get_fd ();
}

/* General purpose routine for performing server SOCK creation. */

SOCK_Listener::SOCK_Listener (const Addr &local_sap, int reuse_addr, int micro_sec_delay, int protocol_family,
			      int backlog, int protocol)
			      : SOCK (SOCK_STREAM, protocol_family, protocol), 
			        micro_second_delay (micro_sec_delay)
{

  if (this->shared_open (local_sap, reuse_addr, backlog) == -1)
    perror ("SOCK_Listener");
}

/* General purpose routine for performing server SOCK creation. */

int
SOCK_Listener::open (const Addr &local_sap, int reuse_addr, int micro_sec_delay,
		     int protocol_family, int backlog, int protocol)
{

  this->micro_second_delay = micro_sec_delay;

  this->set_fd (SOCK::open (SOCK_STREAM, protocol_family, protocol));
  if (this->get_fd () < 0)
    return -1;
  else
    return this->shared_open (local_sap, reuse_addr, backlog);
}
    
int
SOCK_Listener::handle_timed_wait (int restart) const
{
  fd_set  read_fds;
  timeval tv;
  int	  n;

  FD_ZERO (&read_fds);
  FD_SET (this->get_fd (), &read_fds);
  tv.tv_sec  = this->micro_second_delay / 1000000;
  tv.tv_usec = this->micro_second_delay % 1000000;

  do
    {
#if defined( hpux) & 0
      if ((n = ::select (this->get_fd () + 1, (int*)(&read_fds), 0, 0, &tv)) == -1)
#else
      if ((n = ::select (this->get_fd () + 1, (fd_set*)&read_fds, 
			 (fd_set*)NULL,(fd_set*)NULL, (timeval*)&tv)) == -1)
#endif
	{
	  if (errno == EINTR && restart)
	    continue;
	  else
	    return -1;
	}
      else if (n == 0)
	{
	  errno = this->micro_second_delay == 0 ? EAGAIN : ETIMEDOUT;
	  return -1;
	}
    }
  while (n != 1);
  return 0;
}


/* Performs the timed accept operation. */

int
SOCK_Listener::shared_accept (Addr *remote_addr, int restart) const
{
  sockaddr *addr    = 0;
  int	   *len_ptr = 0;
  int	   len;
  int	   new_fd;

  if (remote_addr != 0)
    {
      len     = remote_addr->get_size ();
      len_ptr = &len;
      addr    = (sockaddr *) remote_addr->get_addr ();
    }

  /* Handle the timeout case */

  if (this->micro_second_delay > -1 && this->handle_timed_wait (restart) == -1)
    return -1;
  else
    {
      /* Accept the connection! */
  
      do
	new_fd = ::accept (this->get_fd (), addr, len_ptr);
      while (new_fd == -1 && restart && errno == EINTR);

      /* Reset the size of the addr (really only necessary for the UNIX domain sockets)! */
      if (remote_addr != 0)
	remote_addr->set_size (*len_ptr);
    }

  return new_fd;
}

