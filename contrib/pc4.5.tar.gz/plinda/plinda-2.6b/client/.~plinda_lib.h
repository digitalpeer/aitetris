// This may look like C code, but it is really -*- C++ -*-
//
// File:        plinda.h
// Description: This file declares the client library routines.
// Created:      
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
// Note:        This code is largely inspired by the design 
//		of Brian Anderson's client library for PLinda 1.0.

#ifndef _PLINDA_LIB_H_
#define _PLINDA_LIB_H_

// These are the client routines.  The plinda pre-processor converts
// language statements to these run-time calls.  The names and types
// of these routines cannot change without migrating the changes to
// the PLinda translator.

#include <sys/types.h>

#include "plinda_requests.h"
#include "plinda_ids.h"
#include "Tuple.h"

extern Tuple *_PLtemp;

// --------------------------------------------------------------------
// process anouncements
// --------------------------------------------------------------------

void PL_proc_eval(Tuple*, int, const char*);
bool PL_arg_rdp(Tuple* pat, int line, const char* file);

// --------------------------------------------------------------------
// group manipulation
// --------------------------------------------------------------------

const gid PL_create_group(const char*, int, const char*);
void PL_destroy_group(gid&, int, const char*);

// --------------------------------------------------------------------
// transaction stuff
// --------------------------------------------------------------------
void pl_exit(int val);
void PL_xstart(int, const char*); 
void PL_xcommit(Tuple*, int, const char*);

// --------------------------------------------------------------------
// tuple manipulation
// --------------------------------------------------------------------

void PL_out(gid&, Tuple*, int, const char*);
void PL_in(gid&, Tuple*, int, const char*);
bool PL_inp(gid&, Tuple*, int, const char*);
void PL_rd(gid&, Tuple*,  int, const char*);
bool PL_rdp(gid&, Tuple*, int, const char*);


bool PL_xrecover(Tuple* , int line, const char* file);

// -----------------------------------------------------------------
// MARCRO functions
// -----------------------------------------------------------------

#define create_group(string)	PL_create_group(string, __LINE__, __FILE__)
#define destroy_group(ts)	PL_destroy_group(ts, __LINE__, __FILE__)
#define xstart			PL_xstart(__LINE__, __FILE__)

#define pl_proc_eval(tuple) 	PL_proc_eval(tuple, __LINE__, __FILE__)
#define pl_arg_rdp(tuple)	PL_arg_rdp(tuple, __LINE__, __FILE__)

#define xrecover(tuple)	        PL_xrecover(tuple, __LINE__, __FILE__)
#define xcommit(tuple)		PL_xcommit(tuple, __LINE__, __FILE__)

#define pl_out(ts,tuple)  PL_out(ts, tuple, __LINE__, __FILE__)
#define pl_in(ts, tuple)  PL_in(ts,  tuple, __LINE__, __FILE__)
#define pl_inp(ts,tuple)  PL_inp(ts, tuple, __LINE__, __FILE__)
#define pl_rd(ts, tuple)  PL_rd(ts,  tuple, __LINE__, __FILE__)
#define pl_rdp(ts,tuple)  PL_rdp(ts, tuple, __LINE__, __FILE__)


#endif // _PLINDA_LIB_H_





