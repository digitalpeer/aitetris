
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <errno.h>


// GNU 
#include <DLList.h>


// PLinda
#include "C_Interface.h"
#include "plinda_daemon.h"
#include "ClientCommLink.h"
#include "Architectures.h"

// polling frequency
int minimum_idle_time = 30;
int idle_check_interval = 30;
int busy_check_interval = 2;
int poll_interval = 0;
int idle_flag = -1;
int msg_seq_num = 0;
int exit_flag = 0;


// worker info          ---------------------------------------------
class WorkerType {
public:
  // constructor.
  WorkerType(procid id,
             const char* name, 
	     int pid) {
    ::strcpy(x_workername,name); 
    x_identifier = id;
    x_pid = pid;
  }

  const char* name(void) { return x_workername; }
  procid identifier(void) { return x_identifier; }
  int UNIX_pid(void) { return x_pid; }

private:
  // data members.
  procid x_identifier;
  char x_workername[100];
  int x_pid;
};

typedef DLList<WorkerType*> WorkerListType;

WorkerListType worker_list;


// forward declaration  --------------------------------------------
int check_idleness(void);

int create_worker(procid, const char*, int);
WorkerType* remove_worker(int);
int terminate_workers(void);  // let defunct workers go...
int kill_workers(int);        // kill workers
int kill_all_workers(void);   // kill all the workers.

int handle_server_request(int);
int send_notice(int);


// global variables -------------------------------------------------

// hostname             
char hostname[100];

// info about this daemon.
procid my_pid;
int    my_temp_id;

// server address info;
unsigned short server_port;
const char* server_host = 0;
const char* x_server_host = 0;
const char *x_host_type = 0;
const char *x_server_host_type = 0;
int x_need_to_convert = 0;
int busy_interval = 0;

// local communication link.
ClientCommLink server_agent;

int main(int argc, char** argv, char**) {

  // establish a connection to the server -------------------

  // argv[1]: process id.
  // argv[2]: server port.
  // argv[3]: server symbolic address.
  // argv[4]: server_host
  // argv[5]: host_type of this machine
  // argv[6]: host_type of the server

#ifdef MIGRATION_TEST
   if(argc != 8) {
      cerr << "Internal PLinda ERROR not enough arguments." << endl << flush;
      exit(1);
   }
   busy_interval = atoi(argv[7]);
   assert(busy_interval >= 0);
#else
   if(argc != 7) {
      cerr << "Internal PLinda ERROR not enough arguments." << endl << flush;
      exit(1);
   }
#endif
  my_pid = procid(atol(argv[1]));
  server_port = (unsigned short)atoi(argv[2]);
  server_host = argv[3];
  x_server_host = argv[4];
  if(::strcmp(x_server_host,"?") == 0) x_server_host = 0;
  my_temp_id = ::getpid();
  x_host_type = argv[5];
  x_server_host_type = argv[6];
  
   if(! PLinda_Architectures::supported(x_host_type)) {
      cout << "Daemon was not passed correct architecture type:" << x_host_type
	<< endl;
      assert(0);
   }
   if(! PLinda_Architectures::supported(x_server_host_type)) {
      cout << "Daemon was not passed correct architecture type:" << x_server_host_type
	<< endl;
      assert(0);
   }
   x_need_to_convert = 
     PLinda_Architectures::need_to_convert(x_host_type,x_server_host_type);
   
  // initialize the local communication link.
  ::gethostname((char*)hostname, 100);
  server_port = ntohs(server_port);
   server_agent.initialize(my_pid, server_port, server_host, x_need_to_convert);
  // set up a temporary connection to the server.
   if(server_agent.request_link() == -1) {
    cerr << "> ***ERROR: daemon on " << hostname 
	 << " failed to set up a link to the server !\n";
    ::exit(1);
  }

  {
    Header msg;
    msg.daemonMsgType(REGISTER);
    msg.sequenceNum(msg_seq_num);
    msg.transientId(my_temp_id);
    if(server_agent.send(msg) == -1) {
      cerr << "***ERROR: daemon on " << hostname
	   << " failed to send a message to the server !\n";
      ::exit(1);
    }
  }

  // main loop -------------------------------------------

  poll_interval = idle_check_interval;

  worker_list.clear();

#ifdef MIGRATION_TEST
  if(busy_interval == 0) {
    send_notice(IDLE_NOTICE);
    cerr << "> " << hostname << " is idle forever\n";
    while(!exit_flag) {
      if(handle_server_request(poll_interval) == -1) 
	break;
      terminate_workers();    
    }
  }
  srand48(my_pid);
  while(!exit_flag) {
    if(handle_server_request(poll_interval) == -1) 
      break;
    terminate_workers();

    send_notice(IDLE_NOTICE);
    double idle_time = drand48() * busy_interval * 2;
    cerr << "> " << hostname << " is idle " << idle_time << endl << flush;
    sleep((int)idle_time);

    send_notice(BUSY_NOTICE);
    double busy_time = drand48() * busy_interval * 2;
    cerr << "> " << hostname << " is busy for " << busy_time << endl << flush;
    kill_all_workers();
    sleep((int)busy_time);
  }
#else
  while(!exit_flag) {
    sleep(1);
    if(check_idleness()) {
      if(idle_flag != 1) {
	  cerr << "> " << hostname << " is idle !\n";
	  cerr.flush();

          // set idle flag to be on.
	  idle_flag = 1;
	  // change the polling interval.
	  poll_interval = busy_check_interval;
	  
	  // send idle notice to the server.
	  send_notice(IDLE_NOTICE);
      }
	
    } else { // !check_idleness()
      // kill all the processes.
      kill_all_workers();

      if(idle_flag != 0) {
	  cerr << "> " << hostname << " is busy !\n";
	  cerr.flush();

	  // set idle flag to be off.
	  idle_flag = 0;
	  // change the polling interval.
	  poll_interval = idle_check_interval;
	  
	  // send busy notice to the server.
	  send_notice(BUSY_NOTICE);
      }
    }
    
    // handle requests from the server, if any.
    if(handle_server_request(poll_interval) == -1) break;
    
    // check if there is any worker that has recently terminated.
    terminate_workers();

  } // while(1)
#endif
}



int handle_server_request(int timeout) {
  Header message;
  Tuple *tuple = NULL;
  int msg_flag;

  while(1) {
    msg_flag = server_agent.async_receive(message, tuple, timeout);
    if(msg_flag == -1) {
      cerr << "> daemon on " << hostname << 
	" : received an invalid message.\n";
      return -1;
    }
    
    if(msg_flag == 0) return 0;
    
    // interrrupted.
    if(msg_flag == -2) continue;
    
    int request = message.daemonMsgType();
    switch(request) {
    case TERMINATE:
      assert(tuple == NULL);
      kill_all_workers();
      exit_flag = 1;
      break;

    case CREATE_WORKER: 
      assert(tuple);
      if(idle_flag == 0) {
	Tuple::destroy(tuple);
	tuple = NULL;
	// busy, and so ignore a process creation request.
	break;
      }
      {
      int  interactive = message.interactive();
      procid identifier = message.processId();
      char fileName[100];
      tuple->read(0, TupleField::PLchar, fileName, 100);
      create_worker(identifier, fileName,interactive);
      Tuple::destroy(tuple);
      tuple = NULL;
      }
      break;
      
    case KILL_WORKER: 
      assert(tuple == NULL);
      {
      int pid = message.transientId();
      kill_workers(pid);
      }
      break;
      
    case SET_INTERVAL:
      assert(tuple == NULL);
      minimum_idle_time = message.idleTime();
      if(minimum_idle_time > 0) {
	 poll_interval = busy_check_interval;
      } else {
	 poll_interval = idle_check_interval;
      }
      cerr << "> daemon on " << hostname << 
	" : set minimum idle time to " << minimum_idle_time << ".\n";
      cerr.flush();
      break;
      
    case TEST_FAILURE:
      assert(tuple == NULL);
      {
	send_notice(ALIVE_NOTICE);
      }
      break;
      
    default:
      tuple = NULL;
      cerr << "> daemon on " << hostname << 
	" : received an invalid message.\n";
      kill_all_workers();
      return -1;
    }
    
    timeout = 0;
 }
  return 1;
}


int 
send_notice(int notice) {
  int res;

  Header message;
  message.daemonMsgType(notice);
  message.sequenceNum(msg_seq_num);
  if(notice != ALIVE_NOTICE) {
    ++msg_seq_num;
  }
  assert(message.tupleLength() == 0);
  if((res=server_agent.send(message)) == -1) {
    cerr << "> daemon on " << hostname << " : failed to send a message.\n";
  }

  return res;
}


// checkc idleness  -----------------------------------------------
int
check_idleness(void) {
  if(minimum_idle_time == 0) return 1;

  long idle_time;

  struct stat stat_buf;
  struct timeval cur_time;

  gettimeofday(&cur_time, NULL);

  ::stat("/dev/kbd", &stat_buf); 
  idle_time = cur_time.tv_sec - stat_buf.st_atime;

  ::stat("/dev/mouse", &stat_buf);
  if(idle_time > (cur_time.tv_sec - stat_buf.st_atime)) {
    idle_time = cur_time.tv_sec - stat_buf.st_atime;
  }

  ::stat("/dev/console", &stat_buf);
  if(idle_time > (cur_time.tv_sec - stat_buf.st_atime)) {
    idle_time = cur_time.tv_sec - stat_buf.st_atime;
  }

  return (idle_time >= minimum_idle_time);
}


// create a worker process.
int create_worker(procid identifier, const char* workername, int interactive) {
  int worker_pid;
  // create worker
  if((worker_pid = fork()) == 0) {
    // close the parent's connection.
    server_agent.close();

    if(interactive) {
      if(x_server_host == 0) {
	cerr << "> ***ERROR: interactive process but no x server host info.\n";
	cerr.flush();
	return 0;
      }

      char command[1000];
      ::sprintf(command,"plinda/lib/%s/%s %ld %d %s %s %d; cat",x_host_type,
		workername, identifier, server_port, server_host, 
		"interactive",x_need_to_convert);
      char xterm[100];
      ::sprintf(xterm,"plinda/bin/%s/xterm",x_host_type);
      if(::execl(xterm,"xterm","-display",x_server_host,"-e",
		 "/bin/sh", "-c", command, 0) == -1) {
	 cerr << "> ****ERROR: daemon on " << hostname 
	   << " failed to create a process to run " << workername << "\n";
	 cerr << "either plinda/lib/" << x_host_type << "/" << workername
	   << " or plinda/lib/" << x_host_type << "/xterm is not executable"
	     << endl;
	 cerr.flush();
      }

    } else {
      char name[100];
      ::sprintf(name, "plinda/lib/%s/%s", x_host_type,workername);
      char cidentifier[100];
      ::sprintf(cidentifier, "%ld", identifier);
      char cport[100];
      ::sprintf(cport, "%d", server_port);
      char need_to_convert[10];
      ::sprintf(need_to_convert,"%d",x_need_to_convert);
      if(::execl(name, workername, cidentifier, cport, server_host, 
		 "noninteractive",need_to_convert,0) == -1) {
	cerr << "> *** ERROR: daemon on " << hostname 
	  << " failed to create a process to run " << workername << "\n";
	 cerr << "plinda/lib/" << x_host_type << "/" << workername
	   << " does not seem to be executable" << endl;
	cerr.flush();
      }
    }
  }

  // register this new worker.
  WorkerType* worker = new WorkerType(identifier, workername, worker_pid);
  worker_list.prepend(worker);

  // report this.
  cerr << "> daemon on " << hostname << " created (" 
    << workername << "," << identifier << "," << worker_pid << ")\n";
  cerr.flush();

  return 1;
}


// kill the process which the server pointed to.

int kill_workers(int pid) {
  ::kill(pid, SIGKILL);
  return 1;
}


// this host becomes busy, and leave it alone to the owner 
// by killing all the workers immediately.

int kill_all_workers(void) {

//  cerr << hostname << " is killing workers !!\n";

  for(Pix cur=worker_list.first(); cur != 0; worker_list.next(cur)) {
    WorkerType* worker = worker_list(cur);
    ::kill(worker->UNIX_pid(), SIGKILL);

// cerr << hostname << " killed worker(" 
//     << worker->identifier() << "," << worker->UNIX_pid() << ")\n"; 
     
  }

  cerr.flush();

  return worker_list.length();
}



// remove the entry for a worker process with given pid from the list.
WorkerType* remove_worker(int id) {
  Pix cur;
  for(cur=worker_list.first(); cur!=0; worker_list.next(cur)) {
    WorkerType* worker = (WorkerType*)worker_list(cur);
    if(worker->UNIX_pid() == id) {
      worker_list.del(cur);
      return worker;
    }
  }
  return 0;
}


// forked processes stay around as defunct 
// until 'wait' is explicitly called for them.
// here, we call wait for them and delete the corresponding entries.
int terminate_workers(void) {

  while(1) {
    int pid = ::wait3(0, WNOHANG, 0);

    if(pid <= 0) return 1;

    WorkerType* worker = remove_worker(pid);
    if(worker == 0) {
      cerr << "> *** ERROR: daemon on " << hostname << " can't find an entry "
	   << "for process " << pid << ".\n";
      cerr.flush();
    } else {
      cerr << "worker " << worker->identifier() << " on " 
           << hostname << " terminated.\n";
      cerr.flush();
    }

    delete worker;
  }

  return 1;
}



