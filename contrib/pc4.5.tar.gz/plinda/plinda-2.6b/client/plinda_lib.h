// This may look like C code, but it is really -*- C++ -*-
//
// File:        plinda.h
// Description: This file declares the client library routines.
// Created:      
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
// Note:        This code is largely inspired by the design 
//		of Brian Anderson's client library for PLinda 1.0.

#ifndef _PLINDA_LIB_H_
#define _PLINDA_LIB_H_

// These are the client routines.  The plinda pre-processor converts
// language statements to these run-time calls.  The names and types
// of these routines cannot change without migrating the changes to
// the PLinda translator.

#include <sys/types.h>

#include "plinda_requests.h"
#include "plinda_ids.h"
#include "Tuple.h"

extern Tuple *_PLtemp;
extern bool interactive;

// --------------------------------------------------------------------
// process anouncements
// --------------------------------------------------------------------
int PL_num_machines(int, const char*);
void PL_proc_eval(Tuple*, int, const char*);
bool PL_arg_rdp(Tuple* pat, int line, const char* file);

// --------------------------------------------------------------------
// group manipulation
// --------------------------------------------------------------------

const gid PL_create_group(const char*, int, const char*);
void PL_destroy_group(gid&, int, const char*);

// --------------------------------------------------------------------
// transaction stuff
// --------------------------------------------------------------------

void PL_xstart(int, const char*); 
void PL_xcommit(Tuple*, int, const char*);

// --------------------------------------------------------------------
// tuple manipulation
// --------------------------------------------------------------------

void PL_out(gid&, Tuple*, int, const char*);
void PL_in(gid&, Tuple*, int, const char*);
bool PL_inp(gid&, Tuple*, int, const char*);
void PL_rd(gid&, Tuple*,  int, const char*);
bool PL_rdp(gid&, Tuple*, int, const char*);


bool PL_xrecover(Tuple* , int line, const char* file);

#endif // _PLINDA_LIB_H_





