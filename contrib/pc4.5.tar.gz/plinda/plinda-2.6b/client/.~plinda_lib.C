// This may look like C code, but it is really -*- C++ -*-
//
// File:        plinda_lib.C 
// Description: the client library routines. 
// Created:      
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu
// Note: 	The code is largely inspired by the client library  
//		that Brian E. Anderson wrote for PLinda 1.0.
//
// The PLinda pre-compiler "plc" converts PLinda language statements 
// to these run-time calls. Therefore, updates to these routines and 
// the pre-compiler should be coordinated so that they are always 
// consistent with each other.  
//     PL_proc_start
//     PL_proc_end
//     PL_create_group
//     PL_destroy_group
//     PL_xstart
//     PL_xcommit
//     PL_xabort
//     PL_reserve_physid
//     PL_out
//     PL_in
//     PL_rd
//     PL_physrdp
//     PL_physinp
//     PL_log_inout
//     PL_log_rdp
//     PL_rdp_args
//
// Changes to the number and type of arguments must be migrated to the
// preprocessor also.
//

#include <iostream.h>
//#include "plinda_lib.h"
#include "plinda_requests.h"
#include "ErrorType.h"
#include "Machine.h"
#include "Header.h"
#include "ClientCommLink.h"
#include "C_Interface.h"


// the server agent -- bind to any port
static ClientCommLink server_agent;
static procid  my_pid 		= zero_procid;
static procid  my_temp_id 	= 0;

static bool inTransaction = false;
static bool needToStartTransaction = false;
// the die message.  if anything goes wrong the client dies reporting who
// he is and what the problem is.

char hostname[1000];
const char* execname;

#define die_if(x) if(!x) die(x)
void die(const ErrorType& x) {
  cerr << "> error: process (" << execname << "," << my_pid << ") on " 
    << hostname << "\n";
  cerr << "         " << x.message() << ".\n";
  ::exit(1);
}

void pl_exit(int val)
{
   PL_proc_end(__LINE__, __FILE__);
   ::exit(val);
}


// our abort handler when we are in an evaled sub-process of a transaction
void client_die() {
  cerr << "Process (" << my_pid << ") caught an abort.\n";
  ::exit(1);
}

void client_kill() {
#ifdef PL_DEBUG
  cerr << "Process (" << my_pid << "( got a kill.\n";
#endif
  ::exit(-1);
}


Tuple *_PLtemp = NULL; // the tuple that is used by the client programs

// --------------------------------------------------------------------------
// forward declaration of the routines to actually communicate with the server.
// --------------------------------------------------------------------------
Tuple *PL_execute_request(ClientRequest req, int line, const char* file,
			  Tuple * = NULL,
			  long synchrony_type = NOBLOCK,
			  gid &g = (gid&)zero_gid);

void PL_receive_reply(Header &replyHeader, Tuple *&replyTuple) ;


// ----------------------------------------------------------------
// restart flag
// ----------------------------------------------------------------

static long restart_flag = 0;


// ----------------------------------------------------------------
// fault tolerance mode
// ----------------------------------------------------------------


static Header::FT_ModeType ft_mode = Header::PRIVATE_FT;
// static int logging_flag = 1;

static Tuple* private_log = 0;
void PL_proc_start(int, const char*);
void PL_proc_end(int, const char*);


// ----------------------------------------------------------------
// PLinda main.
// ----------------------------------------------------------------

// user's main.
int real_main(int, char**, char**);

#ifndef alpha
char *rindex(char *s, char c);
#endif
int main(int argc, char** argv, char** env) {
  if(argc < 3) {
    cerr << "error: too few arguments, need to run from the plinda server!!\n";
    ::exit(1);
  }
  execname = ::rindex(argv[0], '/');
  if(execname == 0) {
    execname = argv[0];
  } else {
    ++execname;
  }
  ::gethostname(hostname,1000);

  // read the process id.
  // the first argument should contain the process id 
  // that the PLinda server assigns to this process.
  my_pid = procid(atol(argv[1])); 
  my_temp_id = ::getpid();

  // read the address info about the server.
  // The second and third should contain the port number and the ip
  // address of the server whose forms the address. The client
  // will look for the server at the address first and then run a
  // connection protocol.
  unsigned short server_port = (unsigned short)atoi(argv[2]);
  const char* server_host = argv[3];
  server_agent.initialize(my_pid, server_port, server_host);

  if(server_agent.request_link() == -1) {
#ifdef PL_DEBUG
    cerr << "error: failed to set up a link to the server !\n";
#endif // PL_DEBUG
    ::exit(1);
  }
  PL_proc_start(__LINE__, __FILE__);
  // call the user's main function.
  int val = real_main(argc, argv, env);

  // wait for all the spawned processes to terminate;
  // a client process does not spawn children.
  while(wait(0) != -1);

  // inform the server of termination.
  pl_exit(val);
  assert(0);
  return 0;
}

// --------------------------------------------------------------------
// process anouncements
// --------------------------------------------------------------------

void
PL_proc_eval(Tuple *tuple, int line, const char* file) {

  if(!tuple || !tuple->allActuals()) {
    cerr << "ERROR proc_eval tuple must be present and must be all actuals "<<
      "at line " << line << " in file " << file << endl;
    return;
  }
  tuple->opType(Tuple::EVAL);
  tuple->group(zero_gid);
  Tuple *reply = PL_execute_request(TUPLE_CREATIONS, line, file, tuple);
//  Tuple::destroy(tuple);
  assert(reply == NULL);
} 

bool
PL_arg_rdp(Tuple *tuple, int line, const char* file) {

   Tuple *reply = PL_execute_request(ARG_RDP, line, file,  tuple, NOBLOCK);
   if(reply)  {
      tuple->bindFormals(*reply);
      Tuple::destroy(reply);
      Tuple::destroy(tuple);
      return true;
   }
   Tuple::destroy(tuple);
   return false;
}

void
PL_proc_start(int line, const char* file) {

   Tuple *reply = PL_execute_request(PROC_START, line, file);
   assert(reply == NULL);
}

void
PL_proc_end(int line, const char* file) {

   Tuple *reply = PL_execute_request(PROC_END, line ,file);
   assert(reply == NULL);
}

// --------------------------------------------------------------------
// group manipulation: PL_create_group, PL_destroy_group
// --------------------------------------------------------------------

const gid
PL_create_group(const char *desc, int line, const char* file) {

   int len = ::strlen(desc) + 1;
   Tuple *tuple = Tuple::create(1, len * PL_CHAR_SZ);
   tuple->setActual(0,TupleField::PLchar, desc, len);
   gid retValue;
   PL_execute_request(CREATE_GROUP, line, file, tuple, NOBLOCK,retValue);
   // the no block is just put in there so as to be able to use this
   // function, it is bad, but will fix it later
   Tuple::destroy(tuple);
   return retValue;
}

void
PL_destroy_group(gid& g, int line, const char* file) {
  if(g == zero_gid)
    cerr << "PLinda user error trying to destory an already destroyed group" <<
      " at line " << line << " in file " << file << endl << flush;
  g = zero_gid;
//   PL_execute_request(DESTROY_GROUP, line, file, NULL, NOBLOCK,g);
}

// --------------------------------------------------------------------
// Transactions: PL_xstart, PL_xabort, PL_xcommit
// --------------------------------------------------------------------

void 
PL_xstart(int , const char*) {
  // no fault tolerance is supported.
  if(ft_mode == Header::NO_FT) 
    return; 
  // make sure that nested xstart calls do not take place.
  if(inTransaction) {
    die(E_ALREADY_TRANS);
  }
  needToStartTransaction = true;
  inTransaction = true;
}

void
PL_xcommit(Tuple* log, int line, const char* file) {
#ifndef NDEBUG
  if(log && !log->allActuals()) {
    cerr << "ERROR log tuple must be all actuals at " << line << " in file "
      << file << endl << flush;
  }
#endif
  // no fault tolerance is supported.
  if(ft_mode == Header::NO_FT)  {
     return;
 }
  // make sure the transaction is active
  if(!inTransaction) {
    die(E_NO_TRANS);
  }
  Tuple *reply = NULL;
  if(log) {
     log->opType(Tuple::XCOMMIT);
     log->group(zero_gid);
  }
  reply = PL_execute_request(XCOMMIT, line, file, log);
  inTransaction = false;
  assert(reply == NULL);
  if(private_log != 0) {
      Tuple::destroy(private_log);
  }
  private_log = log;  
}

bool
PL_xrecover(Tuple *tuple, int line, const char* file) {
  if(ft_mode == Header::NO_FT) 
    return false;
  if(restart_flag == 0) 
    return false; 
  if(tuple == 0)
    return true;
  Tuple *reply = PL_execute_request(XRECOVER , line, file, NULL, NOBLOCK);
  if(!reply){
     return false; // no transaction has ever committed
  }
  if(*reply == *tuple)
    tuple->bindFormals(*reply);
  else {
    cerr << "ERROR: xrecovery tuple does not match the pattern of the log tuple\n";
    return false;
 }
  if(ft_mode != Header::PRIVATE_FT) {
     // for global snapshot may need the log tuple
    if(private_log != NULL) {
      cerr << "ERROR: should only be xrecovering in the start of a program\n";
      return false;
    }
     private_log = reply;
  } else if(reply)
    Tuple::destroy(reply);
  Tuple::destroy(tuple);
  return true;
}

// --------------------------------------------------------------------
// Tuple Space: 
//    PL_out
//    PL_in, PL_inp, PL_rd, PL_rdp, 
//    PL_physinp, PL_physrdp, 
// --------------------------------------------------------------------

void
PL_out(gid& g, 
       Tuple* tuple, 
       int line, 
       const char* file) {

#ifndef NDEBUG
 if(!tuple->allActuals()) {
   cerr << "ERROR: trying to out a tuple that is not all actuals on " <<
     line << " in file " << file << endl << flush;
   return;
 }
#endif   
 tuple->opType(Tuple::OUT);
 tuple->group(g);
 Tuple *reply = PL_execute_request(TUPLE_CREATIONS, line, file, tuple, 
				   NOBLOCK,g);
 // The NOBLOCK is totally ignored by everybody, just put it there
 // so don't have to make another execute_request
// Tuple::destroy(tuple);
 assert(reply == NULL);
}

void
PL_in(gid& g, 
      Tuple *tuple,
      int line, 
      const char* file) {
   Tuple *reply = PL_execute_request(IN, line, file, tuple, BLOCK, g);
   assert(reply);
   tuple->bindFormals(*reply);
   Tuple::destroy(reply);
   Tuple::destroy(tuple);
}

bool
PL_inp(gid& g, Tuple *tuple,int line, const char* file) {
   Tuple *reply = PL_execute_request(IN, line, file, tuple, NOBLOCK,g);
   if(reply) {
      tuple->bindFormals(*reply);
      Tuple::destroy(reply);
      Tuple::destroy(tuple);
      return true;
  }
   Tuple::destroy(tuple);
   return false;
}

void
PL_rd(gid& g, Tuple *tuple, int line, const char* file) {
   Tuple *reply = PL_execute_request(RD, line, file, tuple,BLOCK,g);
   assert(reply);
   tuple->bindFormals(*reply);
   Tuple::destroy(reply);
   Tuple::destroy(tuple);
}

bool
PL_rdp(gid& g, Tuple *tuple, int line,  const char* file) {
   Tuple *reply = PL_execute_request(RD, line, file, tuple,NOBLOCK,g);
   if(reply) {
     tuple->bindFormals(*reply);
     Tuple::destroy(reply);
     Tuple::destroy(tuple);
     return true;
  }
   Tuple::destroy(tuple);
   return false;
}


// ---------------------------------------------------------------------
// Utility routines 
// ---------------------------------------------------------------------

Tuple *flattenTuples(DLList<Tuple*> &outList)
{

   const int numTuples = outList.length();
   if(numTuples == 0)
     return NULL;
   {   
      int lengths[numTuples];
      Pix p;
      int i;
      int totLength = 0;
      for(i = 0,p = outList.first(); p; outList.next(p),i++) {
	 Tuple *temp = outList(p);
	 assert(temp && temp->valid());
	 lengths[i] = temp->length();
	 totLength += lengths[i];
      }
      char *buf = new char[totLength];
      char *cur = buf;
      for(p = outList.first(); p; outList.next(p)) {
	 Tuple *temp = outList(p);
	 assert(temp && temp->valid());
	 memcpy(cur, temp, temp->length());
	 cur += temp->length();
	 if(temp->opType() != Tuple::XCOMMIT)
	   Tuple::destroy(temp);
      }
      outList.clear();
      Tuple *result = Tuple::create(3, totLength + numTuples * sizeof(int));
      result->setActual(0,TupleField::PLint, numTuples);
      result->setActual(1,TupleField::PLint, lengths, numTuples);
      result->setActual(2,TupleField::PLchar,buf,totLength);
      delete[] buf;
      return result;
   }
}


Tuple *PL_execute_request(ClientRequest req, 
			  int line, const char* file,Tuple *tuple,
			  long synchrony_type,
			  gid& g) 
			 
{		      
   static  DLList<Tuple*> outList;
   Tuple *replyTuple = NULL;
   Header replyHeader;
   Header header;

   if(req!= PROC_START && req != PROC_END &&
      req != XRECOVER  && req != XCOMMIT) {
      assert(tuple);
      assert(tuple->valid());
   } else if(req != XCOMMIT)
     assert(tuple == NULL);

   if(req == TUPLE_CREATIONS && inTransaction) {
      assert(tuple);
      assert((tuple->opType() == Tuple::EVAL  && tuple->group() == zero_gid)||
	     (tuple->opType() == Tuple::OUT  && tuple->group() != zero_gid));
      outList.append(tuple);
      return NULL;
   }

   if(req == XCOMMIT) {
      if(tuple)
	outList.append(tuple);
      tuple =  flattenTuples(outList);
      assert(outList.length() == 0);
   }

   const int tupleLength = tuple ? tuple->length() : 0;

   header.clientRequest(req);
   header.transientId(my_temp_id);
   header.fileName((char*)file);
   header.lineNum(line);
   header.synchronyType(synchrony_type);
   header.g(g);
   header.tupleLength(tupleLength);

   if(needToStartTransaction == true) {
      header.xstart(1);
      needToStartTransaction = false;
   } else
     header.xstart(0);

   if(server_agent.send(header,tuple) == -1) {
      die(E_SEND_FAIL);
   }
   if(req == PROC_END)
     return NULL;
   // wait for a reply; 
   // meanwhile, we may respond to the LOG_REQ request from the server.
   
   PL_receive_reply(replyHeader, replyTuple);
   assert((replyHeader.tupleLength() == 0 && replyTuple == NULL) ||
	  replyTuple && replyHeader.tupleLength() == replyTuple->length());
   if(req == PROC_START) {
      // fill up some local stuff, I know this is bad to do it here,
      // but it saves returning a useless Header to all the functions
      // except PROC_START
      restart_flag = replyHeader.restartFlag();
      ft_mode = replyHeader.ftMode();
      assert(replyTuple == NULL);
   } else if(req == CREATE_GROUP) {
      g = replyHeader.g();
   }

   return replyTuple;
}

void PL_receive_reply(Header &replyHeader, Tuple *&replyTuple) 
{
   while(1) {
      replyHeader.reset();
      replyTuple = NULL;
      // receive a reply
      if(server_agent.receive(replyHeader,replyTuple) == -1) {
	 die(E_RECEIVE_FAIL);
      }
#ifndef NDEBUG
      if(!replyHeader.status()) {
	 cerr << "In the client got bad news from the server " <<
	   replyHeader.status().message() << endl << flush;
	 die(replyHeader.status());
      }
#endif
      assert(replyHeader.type() == Header::SEND_CLIENT_MESSAGE);
      if(replyHeader.clientRequest() == LOG_REQ) {
	 assert(replyTuple == 0 && replyHeader.tupleLength() == 0);
	 int logLength = private_log ? private_log->length() : 0;
	 Header header;
	 header.clientRequest(LOG_FLUSH);
	 header.transientId(my_temp_id);
	 header.tupleLength(logLength);
	 if(server_agent.send(header, private_log) == -1) {
	    die(E_SEND_FAIL);
	 }
      } else 
	 break;
   } // while
}
