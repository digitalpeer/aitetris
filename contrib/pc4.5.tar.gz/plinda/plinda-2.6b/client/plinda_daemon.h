// This may look like C code, but it is really -*- C++ -*-
//
// File:        plinda_daemon.h
// Description: This file contains definitions for daemons.
// Created:      
// Author:      Karp Joo Jeong
// Mail:        jeong@cs.nyu.edu

#ifndef _PLINDA_DAEMON_H_
#define _PLINDA_DAEMON_H_

// NOTE: the plinda_daemon.C and the server share this file.

const int BUSY_NOTICE = 1;
const int IDLE_NOTICE = 2;
const int ALIVE_NOTICE = 3;

const int CREATE_WORKER = 4;
const int KILL_WORKER = 5;
const int REGISTER = 6;
const int SET_INTERVAL = 7;
const int TEST_FAILURE = 8;
const int TERMINATE = 9;

#endif // _PLINDA_DAEMON_H_

